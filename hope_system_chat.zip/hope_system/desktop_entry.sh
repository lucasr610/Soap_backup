#!/usr/bin/env bash
# Desktop entry script for the clean Nordri engine.
#
# This script serves as a simple wrapper to run the SOP pipeline from
# the command line.  Provide a path to a text file containing the
# procedure description and optionally an industry identifier.
# The resulting SOP will be printed as formatted JSON.

set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <input_file> [industry]"
  exit 1
fi

INPUT_FILE="$1"
INDUSTRY="${2:-General}"

python3 - <<'PYCODE' "$INPUT_FILE" "$INDUSTRY"
import json
import sys
from nordri.backend.sop_pipeline import generate_sop

file_path = sys.argv[1]
industry = sys.argv[2]
with open(file_path, 'r', encoding='utf-8') as f:
    raw = f.read()
result = generate_sop(raw, industry=industry)
print(json.dumps(result, indent=2))
PYCODE