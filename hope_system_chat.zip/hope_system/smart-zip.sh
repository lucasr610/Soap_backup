#!/usr/bin/env bash
set -euo pipefail

NAME="${1:-$(basename "$PWD")}"
OUT="${2:-$NAME-$(date +%Y%m%d-%H%M).zip}"

# Safety: don’t let someone zip $HOME or /
if [[ "$PWD" == "$HOME" || "$PWD" == "/" ]]; then
  [[ "${FORCE:-0}" == "1" ]] || { echo "Refusing to archive $PWD (use FORCE=1 to override)"; exit 1; }
fi

if [[ -d .git ]] && command -v git >/dev/null 2>&1; then
  echo "→ git repo detected; using git archive"
  git archive --format=zip -o "$OUT" HEAD
  echo "✅ $OUT"
  exit 0
fi

EXCLUDES=(
  '*/node_modules/*' 'node_modules/*'
  '*/.pnpm/*' '.pnpm/*'
  '*/.cache/*' '.cache/*'
  '*/.turbo/*' '.turbo/*'
  '*/.next/*' '.next/*'
  '*/dist/*' 'dist/*'
  '*/build/*' 'build/*' '*/out/*' 'out/*' '*/coverage/*' 'coverage/*'
  '*/target/*' 'target/*' '*/storybook-static/*' 'storybook-static/*'
  '*/__pycache__/*' '__pycache__/*' '*/.pytest_cache/*' '.pytest_cache/*'
  '*/.mypy_cache/*' '.mypy_cache/*' '*/.ruff_cache/*' '.ruff_cache/*'
  '*/.venv/*' '.venv/*' '*/venv/*' 'venv/*'
  '*/.idea/*' '.idea/*' '*/.vscode/*' '.vscode/*'
  '*/.git/*' '.git/*'
  '*.log' '*.tmp' '*.swp' '.DS_Store'
)

# Secrets are excluded by default; KEEP_SECRETS=1 to include them
if [[ "${KEEP_SECRETS:-0}" != "1" ]]; then
  EXCLUDES+=('.env' '*.env' '*.pem' '*.key')
fi

# Build tar args
tar_args=()
for pat in "${EXCLUDES[@]}"; do
  tar_args+=(--exclude="$pat")
done

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "→ Staging clean files (excluding junk)…"
tar "${tar_args[@]}" -cf - . | (cd "$TMP" && tar -xf -)

echo "→ Zipping → $OUT"
( cd "$TMP" && zip -rq "../$OUT" . )

echo "✅ Done: $OUT"
