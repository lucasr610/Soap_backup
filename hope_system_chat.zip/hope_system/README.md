# Nordri Diagnostic & Repair SOP Platform

This repository contains a proof‑of‑concept **Nordri** platform for industrial troubleshooting, diagnostics, and standard operating procedure (SOP) generation with regulatory compliance checks.  It is written in TypeScript and uses Fastify for the API layer, MongoDB with X.509 certificate authentication for data storage, BullMQ for asynchronous job queues, Qdrant for vector search, and supports multiple large language model providers.  The original Oracle‑named proof of concept has been fully renamed and its default data directories now live under `~/.nordri`.

The platform now integrates the complete **Reg‑Ops Suite**.  All trade primitives and deterministic tasks from the suite (e.g. HVAC, electrical, plumbing, hydraulics, pumps, compressors, welding, food safety, fleet maintenance, communications/low‑voltage, mechanical drives, refrigeration, boilers/steam, conveyors, and more) are included under `src/isc/primitives` and `src/isc/tasks`.  A new **Trainer Agent** exposes level‑based curricula for each trade, and the sample preventive maintenance manual can be ingested via the document parser and vector store.

## Features

* **Secure Mongo connection** – The server automatically detects whether a client certificate is available and uses the `MONGODB‑X509` authentication mechanism when possible【253097293810405†L524-L533】.  Otherwise it falls back to SCRAM credentials.  The default database name has been updated to `nordri`, and X.509 certificates should be stored under `~/.nordri/mongo`.
* **Encrypted secrets vault** – A simple AES‑256‑GCM vault stores key/value secrets on disk with optional encryption key rotation.  Secrets are stored in `~/.nordri/secrets.json.enc` and the encryption key is provided via the `NORDRI_KMS_KEY` environment variable.
* **Real‑time telemetry** – CPU and memory usage are streamed to the client via WebSockets and Server‑Sent Events.
* **Vector store and retrieval‑augmented generation** – Documents can be indexed and searched using Qdrant.  Embeddings are generated via OpenAI or Gemini (a stub is provided for offline use).  The default Qdrant collection name is now `nordri`.
* **Standard operating procedure generator** – A pipeline of agents (Watson → Mother → Father → Arbiter) turns job orders into structured SOPs with compliance checks and conflict detection.  If a YAML task definition exists under `src/isc/tasks/<trade>/<task>.yaml`, the generator constructs the SOP directly from that deterministic specification (prechecks, steps, QA checks, closeout).  Otherwise it falls back to retrieval‑augmented generation from the vector store.
* **Decision tree troubleshooting** – Upload industrial service catalogs (ISC) as JSON or YAML to drive a state machine.  The master troubleshooter can suggest baseline trees for common trades such as HVAC, electrical, plumbing, industrial machinery, food safety and RV systems.  Sample procedures for these trades are provided under `src/isc/procedures`.

* **Integrated trade curricula** – Trade primitives and hierarchical tasks from the Reg‑Ops Suite are available under `src/isc/primitives` and `src/isc/tasks`.  The Trainer Agent exposes curricula via `/api/agents/trainer/run` by passing a trade and level (1–5), enabling progressive learning material for all supported trades.

* **Preventive maintenance knowledge** – A new `maintenance` trade has been added to capture preventative maintenance best practices for industrial machinery.  The `preventive_maintenance_machinery.yaml` task under `src/isc/tasks/maintenance` codifies a comprehensive procedure including visual inspection, operational checks, lubrication, adjustments, component replacement, cleaning and testing【33888485659506†L172-L220】.

* **Expanded trade tasks** – The knowledge base has been dramatically expanded with deterministic tasks for several additional domains:
  * **Food safety:** New tasks implement the Clean, Separate, Cook and Chill principles promoted by food safety authorities.  They include washing hands and cleaning surfaces, preventing cross‑contamination by using separate cutting boards and containers, cooking foods to safe internal temperatures, and refrigerating or thawing foods correctly【780715794462541†L55-L103】【780715794462541†L155-L179】.
  * **Electrical panels:** A maintenance procedure for electrical panels covers de‑energizing the board, wearing PPE, visually inspecting for damage, cleaning the panel, tightening connections, performing insulation resistance and functional tests, replacing faulty components and restoring power【401211202944317†L44-L124】.
  * **Pumps:** A comprehensive preventive maintenance routine for centrifugal pumps combines daily visual and operational checks, lubrication, monthly impeller and alignment inspections, quarterly electrical and vibration analysis, and annual disassembly, inspection, rebalancing and performance testing【617083092334056†L162-L174】【617083092334056†L182-L234】.
  * **Boilers and steam systems:** Boiler maintenance tasks cover annual inspections of fireside surfaces, refractory and safety valves, as well as periodic tasks such as cleaning filters, checking oil levels and temperatures, flushing low water cut‑offs, performing blowdowns, monitoring make‑up water and maintaining logs【927375783247114†L145-L160】【927375783247114†L170-L205】.
  * **Recreational vehicles:** An RV winterization procedure guides users through draining and flushing water tanks and appliances, blowing out water lines with compressed air, bypassing the water heater, introducing RV‑safe antifreeze, cleaning the interior, controlling humidity, removing and storing the battery, covering vents, elevating the vehicle on blocks, installing skirting and covers, and considering storage options【788693427336476†L119-L176】【788693427336476†L223-L299】.
  * **Safety inspections:** To support workplace safety and regulatory compliance, new tasks were added for ladder safety inspections, forklift daily pre‑use inspections, fire extinguisher monthly inspections, lockout‑tagout procedures and fall protection harness inspections.  The ladder inspection task instructs workers to verify that manufacturer labels and tags are legible, inspect the ladder’s feet for stability, check side rails and steps for damage and debris, confirm rung locks and spreaders are engaged, and tag and remove defective ladders【892766811387182†L321-L350】.  The forklift pre‑use inspection task covers visual and operational checks such as examining structural components, checking fluid levels, verifying gauge readings, testing lights and alarms, operating the controls and noting any deficiencies【205853797275842†L228-L254】.  The fire extinguisher inspection task details verifying maintenance tags, confirming the pressure gauge or weight is within range, ensuring the extinguisher is accessible, inspecting tamper seals and the extinguisher’s physical condition, and recording the inspection【87910558852028†L100-L130】.  The lockout‑tagout procedure outlines notifying affected employees, identifying energy sources, shutting down and isolating equipment, applying locks and tags, dissipating stored energy, verifying isolation and restoring equipment after maintenance【714396450300670†L253-L329】.  The harness inspection task describes examining the manufacturer’s tag, inspecting hardware for deformities, inspecting webbing for loose stitching, cuts or chemical damage, removing harnesses from service if defects are found and documenting the inspection【622092497389018†L111-L162】.
* **Background job scheduler and DVFS throttle** – Jobs are scheduled via BullMQ.  The DVFS agent monitors CPU load and throttles concurrency to avoid overload.

## Running

1. Install dependencies:

   ```bash
   cd oracle-system
   npm install
   ```

2. Provide environment variables for MongoDB and model providers.  See `.env.example` for guidance.

3. Create the local data directories:

   ```bash
   mkdir -p ~/.nordri/isc/procedures
   mkdir -p ~/.nordri/mongo
   ```

4. Build and start the server:

   ```bash
   npm run build
   node dist/server.js
   ```

5. Visit `http://localhost:5000/health` for a health check.

## Notes

* The code is organised into several modules under `src/`, including `agents`, `services`, `routes` and `security`.  See the comments in each file for more details.
* Example industrial and trade procedure trees are included in `src/isc/procedures`.  Additional examples for food safety and RV systems have been added to demonstrate how to extend the platform.

### Expanding the knowledge base

The `scripts/expandKnowledge.ts` script demonstrates how to ingest deterministic trade tasks into the vector search index.  It recursively reads all YAML task files under `src/isc/tasks/`, flattens their contents into plain text, generates mock 1536‑dimensional embeddings, and calls the Qdrant client to upsert them into the default `nordri` collection.  In a production environment you should replace the mock `generateEmbedding` function with a call to an embedding API such as OpenAI’s text‑embedding‑3‑large or Gemini’s embedding service, and run the script via `ts-node` or after compiling it with `tsc`.  Once indexed, these tasks will contribute to retrieval‑augmented generation in the SOP builder and other agents.
