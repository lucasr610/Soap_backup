import dotenv from "dotenv";
dotenv.config();
import fs from "fs";
import path from "path";
import yaml from "yaml";
import crypto from "crypto";
import { QdrantClient } from "@qdrant/js-client-rest";
import OpenAI from "openai";
const ROOT = "src/isc"; // where we scan for files
const QDRANT_COLLECTION = "nordri";
const EMBED_MODEL = "text-embedding-3-small";
const EMBED_DIMS = 1536; // dims for text-embedding-3-small
const BATCH = 64;
// RFC4122 v5-style UUID from a string (deterministic)
function uuidFromString(name) {
    // namespace = DNS (6ba7b810-9dad-11d1-80b4-00c04fd430c8)
    const ns = Buffer.from("6ba7b8109dad11d180b400c04fd430c8", "hex");
    const hash = crypto.createHash("sha1").update(ns).update(name).digest();
    const bytes = Buffer.from(hash.slice(0, 16));
    bytes[6] = (bytes[6] & 0x0f) | 0x50; // version 5
    bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant RFC4122
    const hex = bytes.toString("hex");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function listFiles(dir, exts = [".yaml", ".yml", ".md", ".txt"]) {
    if (!fs.existsSync(dir))
        return [];
    const out = [];
    const stack = [dir];
    while (stack.length) {
        const cur = stack.pop();
        for (const ent of fs.readdirSync(cur, { withFileTypes: true })) {
            const p = path.join(cur, ent.name);
            if (ent.isDirectory())
                stack.push(p);
            else if (exts.includes(path.extname(ent.name).toLowerCase()))
                out.push(p);
        }
    }
    return out.sort();
}
function fileToText(filePath) {
    const raw = fs.readFileSync(filePath, "utf8");
    const ext = path.extname(filePath).toLowerCase();
    try {
        if (ext === ".yaml" || ext === ".yml") {
            const doc = yaml.parse(raw);
            return typeof doc === "string" ? doc : JSON.stringify(doc, null, 2);
        }
        return raw; // md/txt
    }
    catch {
        return raw;
    }
}
function chunkText(s, size = 1200, overlap = 150) {
    const clean = s.replace(/\s+\n/g, "\n").trim();
    if (clean.length <= size)
        return [clean];
    const chunks = [];
    let i = 0;
    while (i < clean.length) {
        const end = Math.min(clean.length, i + size);
        chunks.push(clean.slice(i, end));
        if (end === clean.length)
            break;
        i = end - overlap;
    }
    return chunks;
}
async function ensureCollection(qdrant) {
    const list = await qdrant.getCollections();
    const exists = (list.collections || []).some((c) => c.name === QDRANT_COLLECTION);
    if (!exists) {
        await qdrant.createCollection(QDRANT_COLLECTION, {
            vectors: { size: EMBED_DIMS, distance: "Cosine" },
        });
    }
}
async function embed(openai, input) {
    const resp = await openai.embeddings.create({ model: EMBED_MODEL, input });
    return resp.data[0].embedding;
}
async function main() {
    const openaiKey = process.env.OPENAI_API_KEY || "";
    if (!openaiKey) {
        console.error("❌ OPENAI_API_KEY is missing");
        process.exit(1);
    }
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const qdrant = new QdrantClient({
        url: process.env.QDRANT_URL || process.env.VECTOR_STORE_URL || "http://localhost:6333",
        apiKey: process.env.QDRANT_API_KEY, // ok if undefined for local/no-auth
    });
    await ensureCollection(qdrant);
    const files = listFiles(ROOT);
    if (!files.length) {
        console.log(`No files found under ${ROOT}. Nothing to index.`);
        return;
    }
    console.log(`Indexing ${files.length} files into '${QDRANT_COLLECTION}' ...`);
    let buffered = [];
    let total = 0;
    for (const file of files) {
        const body = fileToText(file);
        const chunks = chunkText(body);
        for (let i = 0; i < chunks.length; i++) {
            const text = chunks[i];
            const id = uuidFromString(`${file}#${i}`);
            const vector = await embed(openai, text);
            buffered.push({
                id, vector,
                payload: {
                    path: file,
                    chunk: i,
                    total_chunks: chunks.length,
                    text
                },
            });
            if (buffered.length >= BATCH) {
                await qdrant.upsert(QDRANT_COLLECTION, { points: buffered, wait: true });
                total += buffered.length;
                console.log(`  upserted ${total} points...`);
                buffered = [];
            }
        }
    }
    if (buffered.length) {
        await qdrant.upsert(QDRANT_COLLECTION, { points: buffered, wait: true });
        total += buffered.length;
    }
    console.log(`✅ ingest complete. total points: ${total}`);
}
main().catch((err) => {
    console.error(err);
    process.exit(1);
});
//# sourceMappingURL=expandKnowledge.js.map