const { MongoClient } = require('mongodb');

const clusterUrl = 'ai-sop-dev.nezgetk.mongodb.net';
const pemPath = encodeURIComponent('/home/user/.nordri/mongo/client.pem');
const uri =
  `mongodb+srv://${clusterUrl}/?authSource=$external&authMechanism=MONGODB-X509` +
  `&tls=true&tlsCertificateKeyFile=${pemPath}&retryWrites=true&w=majority&appName=ai-sop-dev`;

// Optional: add a CA bundle if your cluster uses a non‑public CA.
const client = new MongoClient(uri, {
  tlsCAFile: '/home/user/.nordri/mongo/ca.pem'
});

async function main() {
  await client.connect();
  console.log('Connected successfully');
}
main().catch(console.dir);
