#!/usr/bin/env node
/*
 * Utility script to fix CommonJS import extensions after transpiling TypeScript
 * to ESM.  Scans the `dist` directory for `.js` files, updating import
 * statements to include the `.js` extension when importing local modules.  It
 * also renames `.js` files to `.mjs` for environments requiring ESM.  Run
 * this script after `npm run build` to ensure compatibility.
 */
import fs from 'fs/promises';
import path from 'path';

async function fixFile(filePath) {
  let content = await fs.readFile(filePath, 'utf-8');
  // Replace `from './module'` with `from './module.js'` when no extension
  content = content.replace(/from \"(\.\/[^\"']+)(?<!\.js)\"/g, (match, p1) => {
    return `from "${p1}.js"`;
  });
  await fs.writeFile(filePath, content, 'utf-8');
  const newPath = filePath.replace(/\.js$/, '.mjs');
  if (newPath !== filePath) {
    await fs.rename(filePath, newPath);
  }
}

async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      await walk(fullPath);
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      await fixFile(fullPath);
    }
  }
}

const distDir = path.resolve('dist');
walk(distDir).catch((err) => {
  console.error(err);
});