#!/usr/bin/env bash
# High‑level launch script for the Nordri platform.  This orchestrates
# launching the backend server, background jobs and optionally a local LLM
# inference service.  Modify paths and commands according to your
# environment.

set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

echo "[Nordri] Launching backend"
"$SCRIPT_DIR/nordri-start.sh" &
SERVER_PID=$!

echo "[Nordri] (optional) Launching local LLM service"
# Example: spin up a llama.cpp server on port 8000
# Uncomment and adjust the following lines if you have a local model
#LLAMA_MODEL_PATH="$HOME/models/llama-3-8b-instruct.Q4_K_M.gguf"
#llama.cpp/server --model "$LLAMA_MODEL_PATH" --port 8000 &
#LLM_PID=$!

trap 'echo "[Nordri] Stopping services"; kill $SERVER_PID ${LLM_PID:-} || true' INT TERM

wait $SERVER_PID
echo "[Nordri] Backend terminated"