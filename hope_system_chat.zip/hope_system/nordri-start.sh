#!/usr/bin/env bash
set -euo pipefail

# Load .env if present
if [ -f .env ]; then
  set -o allexport
  source .env
  set +o allexport
fi

echo "[Nordri] Ensuring data directories exist"
mkdir -p "$HOME/.nordri/isc/procedures" "$HOME/.nordri/isc/tasks" "$HOME/.nordri/logs"

echo "[Nordri] Building TypeScript sources"
npm run build

echo "[Nordri] Starting server"
if [ -f dist/server.js ]; then
  node dist/server.js
elif [ -f src/server.ts ]; then
  npx ts-node src/server.ts
elif [ -f server.ts ]; then
  npx ts-node server.ts
else
  echo "Could not find dist/server.js or src/server.ts or server.ts" >&2
  exit 1
fi
