import React, { useRef, useState } from 'react';
import ChatBubble from './ChatBubble';

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * Chat component that maintains a list of messages and handles
 * sending text and file messages to the backend.  Messages are
 * rendered in chronological order.  When sending a file the
 * component first shows an "Uploaded file" placeholder and then
 * displays the assistant's response once ready.
 */
export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  /**
   * Send a plain text message.  The message is added to the local
   * state and then posted to the /chat endpoint.  The returned
   * steps array is joined with newlines and appended as the
   * assistant's response.
   */
  const sendMessage = async () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    // Append user message
    const next = [...messages, { role: 'user' as const, content: trimmed }];
    setMessages(next);
    setInput('');
    try {
      const res = await fetch('/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: trimmed }),
      });
      const data = await res.json();
      const resp = Array.isArray(data.response) ? data.response.join('\n') : String(data.response);
      setMessages([...next, { role: 'assistant', content: resp }]);
    } catch (err) {
      setMessages([...next, { role: 'assistant', content: 'Error contacting server.' }]);
    }
  };

  /**
   * Handle file selection.  The file is uploaded via FormData to
   * /chat.  Once the backend responds the assistant's answer is
   * appended.  This simple handler only uploads the first file.
   */
  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Append a placeholder message indicating upload
    const next = [...messages, { role: 'user', content: `Uploaded file: ${file.name}` }];
    setMessages(next);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await fetch('/chat', { method: 'POST', body: formData });
      const data = await res.json();
      const resp = Array.isArray(data.response) ? data.response.join('\n') : String(data.response);
      setMessages([...next, { role: 'assistant', content: resp }]);
    } catch (err) {
      setMessages([...next, { role: 'assistant', content: 'Error uploading file.' }]);
    }
  };

  return (
    <div className="flex h-screen flex-col p-4">
      <div className="flex-1 overflow-y-auto">
        {messages.map((m, idx) => (
          <ChatBubble key={idx} role={m.role} content={m.content} />
        ))}
      </div>
      <div className="mt-2 flex items-center space-x-2">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="rounded bg-gray-200 px-3 py-2 text-sm hover:bg-gray-300"
        >
          Upload
        </button>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFile}
        />
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              sendMessage();
            }
          }}
          className="flex-1 rounded border px-3 py-2 text-sm"
          placeholder="Type a message..."
        />
        <button
          type="button"
          onClick={sendMessage}
          className="rounded bg-blue-500 px-4 py-2 text-sm text-white hover:bg-blue-600"
        >
          Send
        </button>
      </div>
    </div>
  );
}