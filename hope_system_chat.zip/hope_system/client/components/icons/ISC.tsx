import React from 'react';

export function ISC({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 1024 1024" aria-hidden="true">
      <defs>
        <filter id="miniGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="1.6" result="b1"/>
          <feMerge>
            <feMergeNode in="b1"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <rect width="1024" height="1024" fill="#000"/>
      <g filter="url(#miniGlow)" transform="translate(64, 320) scale(0.85)">
        <rect x="80" y="0" width="36" height="360" rx="8" fill="#00FF7F"/>
        <path d="M310,60 C310,10 360,-20 430,-20 C515,-20 570,10 570,70
                 C570,120 535,145 465,160 L420,170
                 C355,184 320,205 320,245
                 C320,295 370,325 445,325
                 C510,325 560,300 575,265"
              fill="none" stroke="#00FF7F" strokeWidth="34" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M760,90 C715,35 650,5 575,5
                 C455,5 370,90 370,210
                 C370,330 455,415 575,415
                 C650,415 715,385 760,330"
              fill="none" stroke="#00FF7F" strokeWidth="34" strokeLinecap="round" strokeLinejoin="round"/>
      </g>
      <circle cx="512" cy="512" r="430" fill="none" stroke="#00FF7F" strokeOpacity="0.2" strokeWidth="4"/>
    </svg>
  );
}
