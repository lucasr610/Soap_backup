import React from 'react';

export type ChatBubbleProps = {
  role: 'user' | 'assistant';
  content: string;
};

/**
 * Simple chat bubble component.  Renders the message on the left or
 * right depending on the role.  Line breaks in the content are
 * preserved.  Colours mimic a chat client: blue for the user and
 * light gray for the assistant.
 */
export default function ChatBubble({ role, content }: ChatBubbleProps) {
  const isUser = role === 'user';
  const bubbleClass = isUser ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800';
  const lines = content.split(/\n/g);
  return (
    <div className={`my-2 flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-md whitespace-pre-wrap rounded-lg px-4 py-3 text-sm shadow ${bubbleClass}`}
      >
        {lines.map((line, idx) => (
          <p key={idx} className="mb-1 last:mb-0">
            {line}
          </p>
        ))}
      </div>
    </div>
  );
}