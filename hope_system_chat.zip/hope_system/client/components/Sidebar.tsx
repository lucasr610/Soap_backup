import Link from 'next/link';
import { ISC } from './icons/ISC';

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <ISC size={28} />
        <span className="brand-text">Dashboard</span>
      </div>

      <nav style={{ padding: '0 .5rem' }}>
        <Link href="/dashboard" className="navlink">
          <ISC size={18} />
          <span style={{ color: '#bbf7d0' }}>Dashboard</span>
        </Link>
        {/* add more nav items here */}
      </nav>
    </aside>
  );
}
