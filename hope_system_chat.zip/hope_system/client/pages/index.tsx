import Chat from '../components/Chat';

/**
 * The default landing page renders the chat interface.  Users can
 * interact with the Nordri back‑end by typing messages or uploading
 * manuals directly from this page.  Additional navigation can be
 * added later (e.g. a sidebar) but this simple example focuses on
 * conversational interactions.
 */
export default function Home() {
  return <Chat />;
}