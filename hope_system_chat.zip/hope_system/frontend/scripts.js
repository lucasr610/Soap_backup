// frontend/scripts.js
(() => {
  // Determine the API base URL dynamically. If the page defines
  // `window.NORDRI_API` (e.g. via an inline script before this file), use it.
  // Otherwise fall back to the current page's protocol/hostname with the
  // default backend port 5000. This prevents hard‑coded ports from breaking
  // when the backend runs on a different port.
  const API = window.NORDRI_API || `${window.location.protocol}//${window.location.hostname}:5000`;

  /* ---------------------------- tiny helpers ---------------------------- */
  const $ = (id) => document.getElementById(id);
  const setPre = (el, data) => { if (el) el.textContent = typeof data === 'string' ? data : JSON.stringify(data, null, 2); };
  const tryParseJSON = (s, fallback = {}) => { try { return s ? JSON.parse(s) : fallback; } catch { return fallback; } };

  /* --------------------------- ECG animation --------------------------- */
  function initECG() {
    const canvas = $('ecg');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let rafId;
    const dpr = window.devicePixelRatio || 1;

    function resize() {
      const cssW = canvas.clientWidth || 900;
      const cssH = canvas.clientHeight || 220;
      canvas.width = Math.floor(cssW * dpr);
      canvas.height = Math.floor(cssH * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener('resize', resize);

    const state = {
      x: 0,
      baseline: () => (canvas.height / dpr) * 0.55,
      lastBeat: performance.now(),
      bpm: 72, // visual only
    };

    function nextPoint(t) {
      const w = canvas.width / dpr, h = canvas.height / dpr;
      const base = state.baseline();
      const noise = (Math.random() - 0.5) * 4; // small jitter

      // Heartbeat spike ~ every (60/bpm) seconds
      const beatInterval = (60 / state.bpm) * 1000;
      let y = base + noise;

      if (t - state.lastBeat >= beatInterval) {
        // quick QRS complex shape across a few pixels
        const phase = (state.x % w);
        if (phase < 4) y = base + 2;      // small up
        else if (phase < 8) y = base - 40; // sharp down
        else if (phase < 12) y = base + 28; // rebound up
        else if (phase < 18) y = base + 0;  // settle
        if (phase >= 18) state.lastBeat = t;
      }
      return Math.max(8, Math.min(h - 8, y));
    }

    function drawGrid() {
      const w = canvas.width / dpr, h = canvas.height / dpr;
      ctx.save();
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(0,255,213,0.08)';
      const step = 24;
      for (let x = 0; x < w; x += step) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
      }
      for (let y = 0; y < h; y += step) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }
      ctx.restore();
    }

    function tick(t) {
      const w = canvas.width / dpr, h = canvas.height / dpr;

      // Scroll effect: draw over a translucent rect
      ctx.fillStyle = 'rgba(6,18,27,0.35)';
      ctx.fillRect(0, 0, w, h);
      drawGrid();

      // Advance x; wrap around for continuous sweep
      state.x = (state.x + 2) % w;
      const y = nextPoint(t);

      // Trail fade for sweep cursor
      ctx.save();
      const grad = ctx.createLinearGradient(state.x - 30, 0, state.x, 0);
      grad.addColorStop(0, 'rgba(0,255,213,0)');
      grad.addColorStop(1, 'rgba(0,255,213,0.35)');
      ctx.fillStyle = grad;
      ctx.fillRect(state.x - 30, 0, 30, h);
      ctx.restore();

      // Draw the point as part of a polyline (keep a short tail)
      if (!tick.history) tick.history = new Array(300).fill([0, state.baseline()]);
      tick.history.push([state.x, y]);
      if (tick.history.length > w) tick.history.shift();

      ctx.save();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#00ffd5';
      ctx.beginPath();
      const start = Math.max(0, tick.history.length - 400);
      for (let i = start; i < tick.history.length; i++) {
        const [px, py] = tick.history[i];
        if (i === start) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.restore();

      rafId = requestAnimationFrame(tick);
    }

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }

  /* ------------------------------ Telemetry ------------------------------ */
  async function refreshTelemetry() {
    const status = $('telemetryStatus');
    const out = $('telemetryJson');
    try {
      status && (status.style.background = '#ffc107'); // amber = loading
      const [healthRes, metricsRes] = await Promise.all([
        fetch(`${API}/telemetry/health`),
        fetch(`${API}/telemetry/metrics`),
      ]);
      const health = await healthRes.json();
      const metrics = await metricsRes.json();
      setPre(out, { health, metrics });
      status && (status.style.background = '#57ff89'); // green = ok
    } catch (e) {
      setPre(out, { error: String(e) });
      status && (status.style.background = '#ff4d6d'); // red = error
    }
  }

  /* --------------------------------- RAG --------------------------------- */
  async function doRagSearch() {
    const q = $('ragQuery')?.value?.trim();
    const limit = parseInt(($('ragLimit')?.value || '5'), 10);
    if (!q) return setPre($('ragResults'), { error: 'Enter a query' });
    try {
      const res = await fetch(`${API}/rag/query`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, limit }),
      });
      const data = await res.json();
      setPre($('ragResults'), data);
    } catch (e) {
      setPre($('ragResults'), { error: String(e) });
    }
  }

  async function doRagIndex() {
    const id = $('ragId')?.value?.trim();
    const text = $('ragText')?.value?.trim();
    if (!id || !text) return;
    try {
      const res = await fetch(`${API}/rag/index`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documents: [{ id, text }] }),
      });
      const data = await res.json();
      setPre($('ragResults'), data);
    } catch (e) {
      setPre($('ragResults'), { error: String(e) });
    }
  }

  /* -------------------------------- Agents ------------------------------- */
  async function loadAgents() {
    const sel = $('agentSelect');
    if (!sel) return;
    sel.innerHTML = '';
    try {
      const res = await fetch(`${API}/agents`);
      const data = await res.json();
      (data.agents || []).forEach((a) => {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = `${a.name} (${a.id})`;
        sel.appendChild(opt);
      });
    } catch (e) {
      setPre($('agentOut'), { error: String(e) });
    }
  }

  async function runAgent() {
    const sel = $('agentSelect');
    const id = sel?.value;
    if (!id) return;
    const input = tryParseJSON($('agentInput')?.value, {});
    try {
      const res = await fetch(`${API}/agents/${encodeURIComponent(id)}/run`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      const data = await res.json();
      setPre($('agentOut'), data);
    } catch (e) {
      setPre($('agentOut'), { error: String(e) });
    }
  }

  /* ---------------------------------- SOP --------------------------------- */
  async function generateSOP() {
    const task = $('sopTask')?.value?.trim();
    const jobOrder = $('sopJobOrder')?.value?.trim();
    if (!task || !jobOrder) {
      return setPre($('sopOut'), { error: 'Task and Job Order required.' });
    }
    try {
      const res = await fetch(`${API}/sop/generate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, jobOrder }),
      });
      const data = await res.json();
      // Show formatted lines and the structured sections
      const pretty = (data.sopFormatted || data.sop || []).join('\n');
      const combined = [
        '--- SOP (Formatted) ---',
        pretty,
        '',
        '--- SOP (Structured) ---',
        JSON.stringify(data.sopStructured ?? {}, null, 2),
        '',
        '--- Checks ---',
        JSON.stringify({ safety: data.safety, logic: data.logic, conflicts: data.conflicts }, null, 2),
      ].join('\n');
      setPre($('sopOut'), combined);
    } catch (e) {
      setPre($('sopOut'), { error: String(e) });
    }
  }

  async function exportSOP(format) {
    const task = $('sopTask')?.value?.trim();
    const jobOrder = $('sopJobOrder')?.value?.trim();
    if (!task || !jobOrder) return;

    try {
      const res = await fetch(`${API}/sop/export`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, jobOrder, format }),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`Export failed (${res.status}): ${text}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sop.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      setPre($('sopOut'), { error: String(e) });
    }
  }

  /* ------------------------------- bindings ------------------------------ */
  document.addEventListener('DOMContentLoaded', () => {
    // ECG + initial telemetry
    initECG();
    refreshTelemetry();

    // Telemetry
    $('btnRefresh')?.addEventListener('click', refreshTelemetry);

    // RAG
    $('btnSearch')?.addEventListener('click', doRagSearch);
    $('btnIndex')?.addEventListener('click', doRagIndex);

    // Agents
    $('btnLoadAgents')?.addEventListener('click', loadAgents);
    $('btnRunAgent')?.addEventListener('click', runAgent);

    // SOP
    $('btnGenerate')?.addEventListener('click', generateSOP);
    $('btnExportPdf')?.addEventListener('click', () => exportSOP('pdf'));
    $('btnExportCsv')?.addEventListener('click', () => exportSOP('csv'));
    $('btnExportDocx')?.addEventListener('click', () => exportSOP('docx'));

    // Secrets page bindings.  If the secrets page is loaded (detected by
    // the presence of the secretsStatus element), fetch the list of
    // stored keys and wire up the save button.  Fields left blank are
    // ignored when saving.
    if ($('secretsStatus')) {
      loadSecrets();
    }
    $('btnSaveSecrets')?.addEventListener('click', saveSecrets);
  });

  /* ------------------------------ Secrets API ----------------------------- */
  // Fetch the list of stored keys from the /secrets endpoint.  This
  // avoids revealing secret values; only the key names are returned.
  async function loadSecrets() {
    const out = $('secretsStatus');
    try {
      const res = await fetch(`${API}/secrets`);
      const data = await res.json();
      setPre(out, { storedKeys: data.keys });
    } catch (e) {
      setPre(out, { error: String(e) });
    }
  }

  // Collect values from secret input fields and POST each non‑empty
  // entry to the /secrets endpoint.  Responses are collated and
  // displayed in the status pre.  After saving, the current keys
  // are reloaded so the user can verify that entries exist.
  async function saveSecrets() {
    const statusEl = $('secretsStatus');
    const pairs = [
      { key: 'OPENAI_API_KEY', value: $('secretOpenAI')?.value?.trim() },
      { key: 'QDRANT_URL', value: $('secretQdrantUrl')?.value?.trim() },
      { key: 'QDRANT_API_KEY', value: $('secretQdrantKey')?.value?.trim() },
      { key: 'MONGO_URI', value: $('secretMongoUri')?.value?.trim() },
      { key: 'GEMINI_API_KEY', value: $('secretGemini')?.value?.trim() },
    ];
    const results = [];
    for (const pair of pairs) {
      if (pair.value) {
        try {
          const res = await fetch(`${API}/secrets`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: pair.key, value: pair.value }),
          });
          const data = await res.json();
          results.push({ key: pair.key, ok: data.ok || false });
        } catch (e) {
          results.push({ key: pair.key, error: String(e) });
        }
      }
    }
    setPre(statusEl, results);
    // refresh the list of stored keys after saving
    loadSecrets();
  }
})();

