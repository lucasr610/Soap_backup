// dashboard.js
// Client‑side logic for the Nordri dashboard.  This script provides
// simple interactivity to call the backend APIs for telemetry, RAG search
// and indexing, running agents and generating SOPs.  All requests target
// the local backend on http://localhost:5000.

(function () {
  const apiBase = 'http://localhost:5000';

  // Utility to update a <pre> element with pretty JSON
  function setPre(id, data) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    }
  }

  // Telemetry: fetch and display system metrics
  async function refreshTelemetry() {
    try {
      const res = await fetch(`${apiBase}/telemetry/metrics`);
      const data = await res.json();
      setPre('telemetryOutput', data);
    } catch (err) {
      setPre('telemetryOutput', { error: err.message });
    }
  }

  // RAG search
  async function performRagQuery(event) {
    event.preventDefault();
    const query = (document.getElementById('ragQuery').value || '').trim();
    const limit = parseInt(document.getElementById('ragLimit').value, 10) || 5;
    if (!query) {
      setPre('ragResults', { error: 'Query is required.' });
      return;
    }
    try {
      const res = await fetch(`${apiBase}/rag/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit }),
      });
      const data = await res.json();
      setPre('ragResults', data);
    } catch (err) {
      setPre('ragResults', { error: err.message });
    }
  }

  // RAG indexing
  async function performRagIndex(event) {
    event.preventDefault();
    const id = (document.getElementById('docId').value || '').trim();
    const text = (document.getElementById('docText').value || '').trim();
    if (!id || !text) {
      alert('Both ID and text are required to index.');
      return;
    }
    try {
      const res = await fetch(`${apiBase}/rag/index`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documents: [{ id, text }] }),
      });
      const data = await res.json();
      alert(`Indexed ${data.upserted} document(s).`);
      // Clear the form
      document.getElementById('docId').value = '';
      document.getElementById('docText').value = '';
    } catch (err) {
      alert('Error indexing document: ' + err.message);
    }
  }

  // Load agents list
  async function loadAgentsList() {
    try {
      const res = await fetch(`${apiBase}/agents`);
      const data = await res.json();
      const select = document.getElementById('agentSelect');
      select.innerHTML = '';
      (data.agents || []).forEach((agent) => {
        const opt = document.createElement('option');
        opt.value = agent.id;
        opt.textContent = `${agent.id} – ${agent.name}`;
        select.appendChild(opt);
      });
    } catch (err) {
      setPre('agentOutput', { error: 'Failed to load agents: ' + err.message });
    }
  }

  // Run selected agent
  async function runSelectedAgent() {
    const select = document.getElementById('agentSelect');
    const agentId = select.value;
    const inputStr = document.getElementById('agentInput').value || '{}';
    let input;
    try {
      input = JSON.parse(inputStr);
    } catch (err) {
      setPre('agentOutput', { error: 'Invalid JSON input.' });
      return;
    }
    try {
      const res = await fetch(`${apiBase}/agents/${encodeURIComponent(agentId)}/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      const data = await res.json();
      setPre('agentOutput', data);
    } catch (err) {
      setPre('agentOutput', { error: err.message });
    }
  }

  // Generate SOP
  async function generateSop(event) {
    event.preventDefault();
    const task = (document.getElementById('sopTask').value || '').trim();
    const job = (document.getElementById('sopJob').value || '').trim();
    if (!task || !job) {
      setPre('sopOutput', { error: 'Task and Job Order are required.' });
      return;
    }
    try {
      const res = await fetch(`${apiBase}/sop/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, jobOrder: job }),
      });
      const data = await res.json();
      setPre('sopOutput', data);
    } catch (err) {
      setPre('sopOutput', { error: err.message });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Telemetry
    document.getElementById('refreshTelemetry').addEventListener('click', refreshTelemetry);
    refreshTelemetry();

    // RAG
    document.getElementById('ragQueryForm').addEventListener('submit', performRagQuery);
    document.getElementById('ragIndexForm').addEventListener('submit', performRagIndex);

    // Agents
    document.getElementById('loadAgents').addEventListener('click', loadAgentsList);
    document.getElementById('runAgent').addEventListener('click', runSelectedAgent);
    // Load automatically on page load
    loadAgentsList();

    // SOP
    document.getElementById('sopForm').addEventListener('submit', generateSop);
  });
})();