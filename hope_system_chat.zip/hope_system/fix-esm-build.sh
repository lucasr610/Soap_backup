#!/usr/bin/env bash
# This script applies post‑build fixes to ensure the compiled JavaScript
# modules are valid ES modules.  It calls `fix-import-extensions.mjs` to
# convert `.js` to `.mjs` and adjust import statements, then optionally
# copies declaration files.  Run this after `npm run build`.

set -euo pipefail

node ./fix-import-extensions.mjs
echo "[fix-esm-build] Updated import extensions and renamed .js to .mjs"

# Copy type declarations
if [ -d dist/types ]; then
  cp -R dist/types/*.d.ts dist/
fi