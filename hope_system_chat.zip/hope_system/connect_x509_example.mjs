// connect_x509_example.mjs
import { MongoClient } from 'mongodb';
import 'dotenv/config';

const client = new MongoClient(process.env.MONGO_URI, {
  tls: true,
  tlsCertificateKeyFile: process.env.MONGO_X509_CERT,
  // tlsCAFile: process.env.MONGO_CA, // only if you actually have one
  authMechanism: 'MONGODB-X509',
  authSource: '$external'
});

async function main() {
  await client.connect();
  console.log('Connected successfully');
  const db = client.db(process.env.MONGO_DB || 'nordri');
  await db.command({ ping: 1 });
  console.log('Ping OK');
  await client.close();
}
main().catch((e) => { console.error('Mongo connect error:', e); process.exit(1); });
