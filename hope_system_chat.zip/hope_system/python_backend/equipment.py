# === departments/equipment.py ===
# Equipment Care Planning Department module
# Builds maintenance care plan based on parts list and critical flags

import os
import json
import datetime
import re
from typing import Dict, Any, Optional

# Assuming app_config and logger_factory are in the parent directory as per your structure
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app_config import AppConfig
from logger_factory import setup_logger
from security_manager import SecurityManager
from access_control import AccessControlManager

class EquipmentCarePlanningDepartment:
    """
    The Equipment Care Planning Department is responsible for generating maintenance
    care plans based on parts lists and critical flags provided in the project data.
    It communicates directly with the ProcessingDepartment for data input and output.
    """
    def __init__(
        self,
        processing,
        security_manager: SecurityManager,
        access_control_manager: AccessControlManager
        ):
        
        """
        Initializes the EquipmentCarePlanningDepartment.

        Args:
            processing_department_communicator (Any): An instance of the ProcessingDepartment.
            security_manager (SecurityManager): The security manager instance for user subscription checks.
            access_control_manager (AccessControlManager): The access control manager for permission checks.
        """
        self.name = "EquipmentCarePlanningDepartment"
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, 'ecp_data')
        self.inbox = os.path.join(self.base, 'ecp_inbox')
        self.outbox = os.path.join(self.base, 'ecp_outbox')
        os.makedirs(self.inbox, exist_ok=True)
        os.makedirs(self.outbox, exist_ok=True)
        self.logger = setup_logger(self.name, 'equipment_care_planning.log')
        self.processing = processing
        self.security = security_manager
        self.access_control = access_control_manager
        self.logger.info(f"{self.name} initialized.")

    def _find_parts_document_in_full_data(self, full_data: Dict, username: str) -> Optional[Dict]:
        """
        Searches for a parts document within the comprehensive full_data provided
        by the ProcessingDepartment. It prioritizes JSON content that contains
        a 'parts_list' key.

        Args:
            full_data (Dict): The comprehensive translated data from ProcessingDepartment.
            username (str): The ID of the user submitting the data.

        Returns:
            Optional[Dict]: The extracted parts document dictionary if found, otherwise None.
        """
        if not isinstance(full_data, dict):
            self.logger.error("Full data is not a dictionary. Cannot find parts document.")
            return None

        # Check for 'extracted_json_content' which is where parsed JSON files reside
        extracted_json_content = full_data.get("extracted_json_content", {})
        if not isinstance(extracted_json_content, dict):
            self.logger.error("extracted_json_content is not a dictionary.")
            return None

        # Iterate through all extracted JSON files to find one that looks like a parts document
        for filename, content in extracted_json_content.items():
            if isinstance(content, dict) and "parts_list" in content and isinstance(content["parts_list"], list):
                self.logger.info(f"Identified '{filename}' as the parts document.")
                return content
        
        # Fallback: Check if 'parts_document' was directly added to full_data (less likely with new flow)
        if "parts_document" in full_data and isinstance(full_data["parts_document"], dict):
            self.logger.info("Identified 'parts_document' directly in full_data.")
            return full_data["parts_document"]

        self.logger.warning("No identifiable parts document found in full_data.")
        return None

    def receive_command_from_processing(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives commands and full project data from the ProcessingDepartment.
        This is the primary entry point for new project data or re-evaluation requests.

        Args:
            sender (str): The name of the sending department (expected: "ProcessingDepartment").
            cmd_type (str): The type of command (expected: "initial_data" or "re_evaluation_data").
            data (Dict): The payload containing project_id and full_data.
            username (str): The ID of the user submitting the data.

        Returns:
            bool: True if the command was processed successfully, False otherwise.
        """
        project_id = data.get("project_id")
        full_data = data.get("full_data")
        username = data.get("username")

        self.logger.info(f"Received command '{cmd_type}' from {sender} for project_id: {project_id}")

        if not project_id or not full_data:
            self.logger.error(f"Missing project_id or full_data in command '{cmd_type}'.")
            self._send_error(project_id, "invalid_input_data", f"Missing project_id or full_data for command: {cmd_type}.", username)
            return False
            
        if not self.security.is_subscription_valid(username):
            self.logger.warning(f"DENIED: {username} - expired subscription")
            self._send_error(project_id, "subscription_expired", f"User '{username}' subscription has expired.", username)
            return False

        if not self.access_control.check_access(username, "write"):
            self.logger.warning(f"DENIED: {username} - lacks permission for 'write'")
            self._send_error(project_id, "access_denied", f"User '{username}' lacks 'write' permission.", username)
            return False

        # Attempt to find and extract the parts document from the comprehensive full_data
        parts_doc = self._find_parts_document_in_full_data(full_data)

        if not parts_doc:
            self.logger.error(f"Could not find a valid parts document in full_data for project {project_id}.")
            self._send_error(project_id, "missing_parts_document", "No valid parts document found in the provided data.", username)
            return False

        # Generate the care plan using the extracted parts document
        generated_plan = self._generate_plan(project_id, parts_doc, username)

        if generated_plan:
            # If plan generation is successful, send an "Accept" report back to ProcessingDepartment
            self.processing.receive_report_from_department(
                self.name,
                "Accept",
                {
                    "project_id": project_id,
                    "report_details": {"care_plan": generated_plan}, # Wrap the plan in 'care_plan' key
                    "missing_information": None,
                    "username": username
                },
                username
            )
            self.logger.info(f"Successfully processed and sent 'Accept' report for project {project_id}.")
            return True
        else:
            self.logger.error(f"Failed to generate plan for project {project_id}.")
            # _send_error would have already been called by _generate_plan if it failed
            return False

    def receive_error_feedback(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives error feedback from the ProcessingDepartment, indicating a retry
        is needed with potentially updated data.

        Args:
            sender (str): The name of the sending department (expected: "ProcessingDepartment").
            cmd_type (str): The type of command (expected: "error_feedback").
            data (Dict): The payload containing project_id, missing_info, and updated full_data.
            username (str): The ID of the user submitting the data.

        Returns:
            bool: True if re-evaluation was successful, False otherwise.
        """
        project_id = data.get("project_id")
        missing_info = data.get("missing_info")
        full_data = data.get("full_data")
        username = data.get("username")

        self.logger.warning(f"Received error feedback from {sender} for project_id: {project_id}. Missing info: {missing_info}. Attempting re-evaluation.")

        if not project_id or not full_data:
            self.logger.error(f"Missing project_id or full_data in error feedback command.")
            self._send_error(project_id, "invalid_feedback_data", "Missing project_id or full_data in error feedback.", username)
            return False

        # Attempt to re-find and extract the parts document from the updated full_data
        parts_doc = self._find_parts_document_in_full_data(full_data)

        if not parts_doc:
            self.logger.error(f"Could not find a valid parts document in updated full_data for project {project_id} during re-evaluation.")
            self._send_error(project_id, "missing_parts_document_on_retry", "No valid parts document found in updated data during retry.", username)
            return False

        # Re-attempt plan generation with the potentially corrected/updated parts document
        generated_plan = self._generate_plan(project_id, parts_doc)

        if generated_plan:
            # If re-evaluation is successful, send an "Accept" report back to ProcessingDepartment
            self.processing.receive_report_from_department(
                self.name,
                "Accept",
                {
                    "project_id": project_id,
                    "report_details": {"care_plan": generated_plan},
                    "missing_information": None,
                    "username" : username
                },
                username,
            )
            self.logger.info(f"Successfully re-evaluated and sent 'Accept' report for project {project_id}.")
            return True
        else:
            self.logger.error(f"Failed to re-generate plan for project {project_id} after error feedback.")
            # _send_error would have already been called by _generate_plan if it failed
            return False

    def _generate_plan(self, project_id: str, parts_doc: Dict, username: str) -> Optional[Dict]:
        """
        Generates the equipment care plan based on the provided parts document.
        This method includes crucial data verification steps.

        Args:
            project_id (str): The ID of the current project.
            parts_doc (Dict): The dictionary containing parts information.
            username (str): The ID of the user submitting the data.

        Returns:
            Optional[Dict]: The generated care plan dictionary if successful, None otherwise.
        """
        self.logger.info(f"Generating care plan for project {project_id}")

        # --- CRITICAL DATA VERIFICATION ---
        if not isinstance(parts_doc, dict):
            self.logger.error(f"Invalid parts_doc type for project {project_id}: Expected dict, got {type(parts_doc)}.")
            self._send_error(project_id, "invalid_parts_doc_format", "Parts document is not a valid dictionary.", username)
            return None

        parts_list = parts_doc.get("parts_list")
        if not isinstance(parts_list, list) or not parts_list:
            self.logger.error(f"Missing or empty 'parts_list' in parts_doc for project {project_id}. Cannot build care plan.")
            self._send_error(project_id, "missing_or_empty_parts_list", "The parts document does not contain a valid or non-empty 'parts_list'.", username)
            return None

        # Verify each item in parts_list has essential keys for safety
        for i, part in enumerate(parts_list):
            if not isinstance(part, dict):
                self.logger.error(f"Invalid part entry at index {i} for project {project_id}: Expected dict, got {type(part)}.")
                self._send_error(project_id, "invalid_part_entry_format", f"Part entry at index {i} is not a valid dictionary.", username)
                return None
            if "component" not in part or not part["component"]:
                self.logger.error(f"Missing 'component' in part entry at index {i} for project {project_id}.")
                self._send_error(project_id, "missing_part_component", f"Part entry at index {i} is missing 'component' information.", username)
                return None
            if "type" not in part or not part["type"]:
                self.logger.error(f"Missing 'type' in part entry at index {i} for project {project_id}.")
                self._send_error(project_id, "missing_part_type", f"Part entry at index {i} is missing 'type' information.", username)
                return None
        # --- END CRITICAL DATA VERIFICATION ---

        plan = {
            "project_id": project_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "service_type": "equipment_care_plan",
            "maintenance_plan": [],
            "notices": [],
            "username": username,
        }

        # Generate specific recommendations based on the verified parts list
        for part in parts_list:
            component_name = part.get("component", "Unknown Component")
            component_type = part.get("type", "Unknown Type")
            # Example of a more detailed, safety-focused recommendation
            recommendation = f"Inspect {component_name} ({component_type}) for wear, corrosion, and proper function. Verify all fasteners and connections are secure. Recommended frequency: Monthly."
            plan["maintenance_plan"].append({
                "component": component_name,
                "type": component_type,
                "recommendation": recommendation
            })

        critical_flags = parts_doc.get("critical_flags", [])
        if critical_flags:
            plan["notices"].append("ATTENTION: Critical flags identified for this equipment. Review immediately:")
            plan["notices"].extend(critical_flags)
            self.logger.warning(f"Critical flags present for project {project_id}: {critical_flags}")

        if not plan["maintenance_plan"]:
            plan["notices"].append("WARNING: No specific maintenance plan could be generated due to insufficient parts data. Manual review required.")
            self.logger.warning(f"No maintenance plan generated for project {project_id} due to lack of parts data after verification.")

        plan_filename = f"care_plan_{project_id}.json"
        plan_filepath = os.path.join(self.outbox, plan_filename)
        try:
            with open(plan_filepath, 'w') as f:
                json.dump(plan, f, indent=4)
            self.logger.info(f"Generated care plan saved to {plan_filepath}")
            return plan # Return the generated plan for the 'Accept' report
        except Exception as e:
            self.logger.error(f"Error saving care plan for project {project_id}: {e}")
            self._send_error(project_id, "plan_save_failure", f"Failed to save generated care plan: {e}", username)
            return None

    def _send_error(self, project_id: str, error_code: str, details: str, username: str):
        """
        Sends an error report to the ProcessingDepartment's centralized error reception.

        Args:
            project_id (str): The ID of the project associated with the error.
            error_code (str): A specific code identifying the type of error.
            details (str): A detailed message describing the error.
            username (str): The ID of the user submitting the data.
        """
        payload = {
            "department": self.name,
            "project_id": project_id,
            "error_type": error_code,
            "details": details,
            "timestamp": datetime.datetime.now().isoformat()
        }
        self.logger.error(f"Reporting error to ProcessingDepartment for project {project_id}: {error_code} - {details}")
        try:
            # Call receive_report_from_department with report_type "Error"
            self.processing.receive_report_from_department(
                self.name,
                "Error",
                {
                    "project_id": project_id,
                    "report_details": payload,
                    "missing_information": details,
                    "username": username
                },
                username,
            )
        except Exception as e:
            self.logger.critical(f"FATAL: Could not send error report to ProcessingDepartment for project {project_id}: {e}")

