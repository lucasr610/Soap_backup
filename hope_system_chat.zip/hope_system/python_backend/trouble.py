# === departments/trouble.py ===
# Troubleshooting Department module
# Analyzes care plan and parts output for technical issues, builds diagnosis path

import os
import json
import datetime
from typing import Dict, Any, Optional

from app_config import AppConfig
from logger_factory import setup_logger
from security_manager import SecurityManager
from access_control import AccessControlManager


class TroubleshootingDepartment:
    def __init__(
        self,
        processing,
        security_manager: SecurityManager,
        access_control_manager: AccessControlManager
        ):
        
        self.name = "TroubleshootingDepartment"
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, 'trouble_data')
        self.inbox = os.path.join(self.base, 'trouble_inbox')
        self.outbox = os.path.join(self.base, 'trouble_outbox')
        os.makedirs(self.inbox, exist_ok=True)
        os.makedirs(self.outbox, exist_ok=True)
        self.logger = setup_logger(self.name, 'troubleshooting_department.log')
        # This reference is set later by secure_api.py
        self.processing = processing
        self.security_manager = security_manager
        self.access_control_manager = access_control_manager

    def receive_command_from_processing(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives commands from the ProcessingDepartment.
        Expected cmd_type: "initial_data" or "re_evaluation_data"
        """
        if sender != "ProcessingDepartment" or cmd_type not in ["initial_data", "re_evaluation", "re_evaluation_data"]:
            self.logger.error(f"Unsupported command '{cmd_type}' or sender '{sender}'. Expected 'ProcessingDepartment' and 'initial_data' or 're_evaluation_data'.")
            # Report an error back to ProcessingDepartment if the command is unexpected
            self._send_error(data.get("project_id", "N/A"), "unsupported_command", {"received_sender": sender, "received_cmd_type": cmd_type}, username)
            return False

        project_id = data.get("project_id")
        full_data = data.get("full_data")
        username = data.get("username")

        if not project_id or not full_data:
            self.logger.error(f"Missing project_id or full_data in command from ProcessingDepartment for sender {sender}, cmd_type {cmd_type}.")
            self._send_error(project_id, "missing_data_in_command", {"details": "project_id or full_data missing"}, username)
            return False

        self.logger.info(f"Received command '{cmd_type}' from {sender} for project {project_id}.")

        # Extract only the relevant data needed by TroubleshootingDepartment        
        care_plan = full_data.get("equipment_care_plan", {})
        manual_content_combined = full_data.get("manual_content_combined", "")

        # The _troubleshoot method will now perform more rigorous data verification
        return self._troubleshoot(project_id, care_plan, manual_content_combined, username)
        
    def _load_json_file(self, path: str, username: str) -> Dict[str, Any]:
        with open(path, "r") as f:
            return json.load(f)

    def _troubleshoot(self, project_id: str, care_plan: Dict, manual_content: str, username: str) -> bool:
        self.logger.info(f"Initiating troubleshooting for project {project_id}")

        diagnosis = {
            "project_id": project_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "service_type": "technical_diagnosis",
            "flags": [],
            "recommendations": [],
            "trace_path": [],
            "troubleshooting_guide_content": ""
        }

        # --- Enhanced Data Verification ---
        validation_errors = []

        # 1. Verify presence of essential data
        if not care_plan and not manual_content:
            validation_errors.append("No care plan or manual content provided for troubleshooting.")
            self.logger.warning(f"Validation: No core data for project {project_id}.")

        # 2. Validate care_plan structure and content
        if care_plan:
            if not isinstance(care_plan, dict):
                validation_errors.append("Care plan is not a dictionary.")
                self.logger.error(f"Validation: Care plan for {project_id} is not a dictionary.")
            elif "maintenance_plan" not in care_plan:
                validation_errors.append("Care plan missing 'maintenance_plan' key.")
                self.logger.warning(f"Validation: Care plan for {project_id} missing 'maintenance_plan'.")
            elif not isinstance(care_plan["maintenance_plan"], list):
                validation_errors.append("'maintenance_plan' in care plan is not a list.")
                self.logger.warning(f"Validation: 'maintenance_plan' for {project_id} is not a list.")
            elif not care_plan["maintenance_plan"]:
                self.logger.info(f"Validation: 'maintenance_plan' for {project_id} is empty.")
            else:
                # Further check if maintenance_plan contains actual steps
                if not any("component" in step and "action" in step for step in care_plan["maintenance_plan"]):
                    validation_errors.append("Maintenance plan contains no valid steps (missing 'component' or 'action').")
                    self.logger.warning(f"Validation: Maintenance plan for {project_id} has no valid steps.")
                self.logger.info(f"Validation: Care plan structure for {project_id} appears valid.")
        else:
            self.logger.info(f"Validation: No care plan provided for project {project_id}. Skipping detailed care plan validation.")


        # 3. Validate manual_content_combined presence and basic quality
        if manual_content:
            if not isinstance(manual_content, str):
                validation_errors.append("Manual content is not a string.")
                self.logger.error(f"Validation: Manual content for {project_id} is not a string.")
            elif len(manual_content.strip()) < 50: # Check for minimum length to avoid empty/trivial strings
                validation_errors.append("Manual content is too short or empty (less than 50 characters).")
                self.logger.warning(f"Validation: Manual content for {project_id} is too short.")
            else:
                self.logger.info(f"Validation: Manual content for {project_id} appears substantial.")
        else:
            self.logger.info(f"Validation: No manual content provided for project {project_id}. Skipping detailed manual content validation.")


        # If validation errors exist, report them back to ProcessingDepartment
        if validation_errors:
            self.logger.error(f"Data validation failed for project {project_id}. Errors: {'; '.join(validation_errors)}")
            # Report input validation errors back to ProcessingDepartment. Note that username is mandatory and
            # is passed immediately after the report details to satisfy the updated signature.
            self._send_report_to_processing(
                project_id,
                "Error",
                {"message": "Input data validation failed for troubleshooting.", "validation_errors": validation_errors},
                username,
                {"missing_info": validation_errors},
            )
            return False
        # --- End Enhanced Data Verification ---

        # Proceed with troubleshooting logic only if data is validated
        self.logger.info(f"Data validated for project {project_id}. Proceeding with troubleshooting analysis.")

        # Example troubleshooting logic based on care plan and manual content
        if care_plan:
            for step in care_plan.get("maintenance_plan", []):
                comp = step.get("component")
                if comp and "hose" in comp.lower():
                    diagnosis["flags"].append("Potential hose integrity issue")
                    diagnosis["recommendations"].append("Check for hose abrasion or leaks")
                    diagnosis["trace_path"].append(f"Inspect {comp} visually and via pressure test")

        if "overheating" in manual_content.lower():
            diagnosis["flags"].append("Overheating mentioned in manual")
            diagnosis["recommendations"].append("Review system cooling and ventilation.")
            diagnosis["trace_path"].append("Check cooling fan operation and heat sinks.")

        if not diagnosis["trace_path"] and not diagnosis["flags"]:
            diagnosis["recommendations"].append("No focused troubleshooting required based on available data.")
            diagnosis["troubleshooting_guide_content"] = "No specific issues identified. General maintenance procedures should be followed."
        else:
            diagnosis["troubleshooting_guide_content"] = (
                "Based on the analysis, here are the troubleshooting steps:\n" +
                "\n".join([f"- {rec}" for rec in diagnosis["recommendations"]]) +
                "\n\nDetailed Inspection Path:\n" +
                "\n".join([f"- {path}" for path in diagnosis["trace_path"]])
            )

        path = os.path.join(self.outbox, f"trouble_output_{project_id}.json")
        try:
            with open(path, 'w') as f:
                json.dump(diagnosis, f, indent=4)
            self.logger.info(f"Troubleshooting diagnosis saved to {path}")
        except Exception as e:
            self.logger.error(f"Failed to write troubleshooting file: {e}")
            # When file writing fails, notify ProcessingDepartment with the username immediately following
            # the report details to comply with the required parameter order.
            self._send_report_to_processing(
                project_id,
                "Error",
                {"message": f"Failed to save diagnosis file: {str(e)}"},
                username,
                {"missing_info": ["file_write_permission_or_path_issue"]},
            )
            return False

        # Send a successful troubleshooting report. Username must be provided as the fourth argument.
        self._send_report_to_processing(
            project_id,
            "Accept",
            {"troubleshooting_guide_content": diagnosis["troubleshooting_guide_content"], "diagnosis_summary": diagnosis, "username": username},
            username
        )
        return True

    def _send_report_to_processing(self, project_id: str, report_type: str, report_details: Dict, username: str, missing_information: Optional[Dict] = None) -> bool:
        """
        Sends an 'Accept' or 'Error' report back to the ProcessingDepartment.
        """
        if self.processing:
            try:
                self.processing.receive_report_from_department(
                    self.name,
                    "report",
                    {
                        "project_id": project_id,
                        "report_type": report_type,
                        "report_details": report_details,
                        "missing_information": missing_information or {},
                        "username": username,
                    },
                    username=username,
                )
                self.logger.info(f"Sent '{report_type}' report to ProcessingDepartment for project {project_id}.")
                return True
            except Exception as e:
                self.logger.error(f"Failed to send report to ProcessingDepartment for project {project_id}: {e}")
                self._send_error(project_id, "report_send_failure", {"details": str(e)}, username)
                return False
        return False

    def _send_error(self, project_id: str, err_type: str, details: Dict, username: str):
        """
        Sends errors to the centralized error reception in ProcessingDepartment.
        """
        payload = {
            "department": self.name,
            "project_id": project_id,
            "error_type": err_type,
            "details": details,
            "timestamp": datetime.datetime.now().isoformat(),
            "message": f"TroubleshootingDepartment encountered an error: {err_type}",
            "username": username
        }
        if self.processing:
            try:
                self.processing.receive_department_error(self.name, payload)
                self.logger.error(f"Sent centralized error to ProcessingDepartment for project {project_id}.")
            except Exception as e:
                self.logger.critical(f"FATAL: Could not send centralized error to ProcessingDepartment for {project_id}: {e}")
        else:
            self.logger.critical(f"FATAL: ProcessingDepartment not initialized. Cannot send error for project {project_id}.")

    def receive_error_feedback(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives error feedback from the ProcessingDepartment and re-attempts processing.
        """
        project_id = data.get("project_id")
        missing_info = data.get("missing_info")
        full_data = data.get("full_data")
        username = data.get("username")

        self.logger.warning(f"Received error feedback from {sender} for project {project_id}. Missing info: {missing_info}. Re-attempting troubleshooting.")

        if not project_id or not full_data:
            self.logger.error(f"Missing project_id or full_data in error feedback from ProcessingDepartment for sender {sender}, cmd_type {cmd_type}.")
            self._send_error(project_id, "missing_data_in_error_feedback", {"details": "project_id or full_data missing"}, username)
            return False

        # Re-extract relevant data from the updated full_data
        care_plan = full_data.get("equipment_care_plan", {})
        manual_content_combined = full_data.get("manual_content_combined", "")

        # Re-attempt troubleshooting with the potentially updated data
        # Reattempt troubleshooting with username mandatory. Pass username explicitly as the final argument.
        return self._troubleshoot(project_id, care_plan, manual_content_combined, username)
