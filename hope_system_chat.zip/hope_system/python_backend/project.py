# File: departments/project.py
import datetime
import json
import os
from typing import Dict, List, Optional, Any

from app_config import AppConfig
from logger_factory import setup_logger
from file_utils import safe_copy_file, safe_copy_files, safe_archive_project

import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from storage_manager import StorageManager # Import the StorageManager
from security_manager import SecurityManager
from access_control import AccessControlManager

class ProjectManagerDepartment:
    def __init__(
        self,
        next_handler=None,
        storage_manager=None,
        security_manager: Optional[SecurityManager] = None,
        access_control_manager: Optional[AccessControlManager] = None
        ):
        """
        Initializes the ProjectManagerDepartment.

        Args:
            next_handler (Optional[Any]): The next department in the processing chain,
                                          expected to be an instance of ProcessingDepartment.
            storage_manager (Optional[StorageManager]): An instance of StorageManager for file operations.
            security_manager (Optional[SecurityManager]): An instance of SecurityManager for user authentication and subscription checks.
            access_control_manager (Optional[AccessControlManager]): An instance of AccessControlManager for permission checks.
        """
        self.name = "ProjectManagerDepartment"
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, "pm_data")
        self.input_dir = os.path.join(self.base, "pm_mrr_inbox")
        self.output_dir = os.path.join(self.base, "pm_mrr_outbox") # This might become less relevant with new flow
        self.archive_dir = os.path.join(self.base, "pm_mrr_archive")

        # New directories for final document handling based on user actions
        self.oracle_data_root = os.path.join(AppConfig.BASE_DATA_DIR, "oracle_data")
        self.editor_recommendations_dir = os.path.join(self.oracle_data_root, "editor_recommendations")
        self.editor_new_dir = os.path.join(self.oracle_data_root, "editor_new")

        os.makedirs(self.input_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.archive_dir, exist_ok=True)
        os.makedirs(self.editor_recommendations_dir, exist_ok=True)
        os.makedirs(self.editor_new_dir, exist_ok=True)

        self.logger = setup_logger(self.name, "project_manager_department.log")
        self.next_handler = next_handler  # Expected to be ProcessingDepartment
        self.storage = storage_manager # Store the StorageManager instance
        self.security = security_manager
        self.access_control = access_control_manager
        
        self.logger.info(f"{self.name} initialized. Next handler: {self.next_handler.name if self.next_handler else 'None'}")
        self.logger.info(f"Security managers configured: {self.security is not None and self.access_control is not None}")

    
    def _enforce_access(self, username: str, required_permission: str) -> bool:
        """
        Enforces security protocols by checking subscription validity and user permissions.

        Args:
            username (str): The unique identifier of the user.
            required_permission (str): The specific permission required for the action.

        Returns:
            bool: True if the user is authorized.

        Raises:
            PermissionError: If the user is not authorized.
        """
        if not self.security:
            self.logger.error("SecurityManager not initialized. Cannot enforce security.")
            raise PermissionError("Security system not available.")
        
        if not self.access_control:
            self.logger.error("AccessControlManager not initialized. Cannot enforce security.")
            raise PermissionError("Access control system not available.")

        # Use the provided username throughout instead of an undefined variable 'user_id'.
        if not self.security.is_subscription_valid(username):
            self.logger.warning(f"Unauthorized access attempt by user {username}: invalid subscription.")
            raise PermissionError("User subscription is not valid.")

        if not self.access_control.check_access(username, required_permission):
            self.logger.warning(f"Unauthorized access attempt by user {username}: missing permission '{required_permission}'.")
            raise PermissionError(f"User is not authorized to perform action: '{required_permission}'.")
        
        return True

    def collect_mrr_data(
        self,
        username: str,
        project_id: str,
        mrr_path: Optional[str] = None,
        supporting_files: Optional[List[str]] = None,
        notes: Optional[str] = None,
        asset_id: Optional[str] = None,
        model_number: Optional[str] = None,
        serial_number: Optional[str] = None,
    ) -> bool:
        """
        Collects MRR data and supporting files, prepares a raw_input_data dictionary,
        and hands it off to the ProcessingDepartment.

        Args:
            project_id (str): Unique identifier for the project.
            username (str): The ID of the user submitting the data.
            mrr_path (Optional[str]): Path to an existing MRR JSON file.
            supporting_files (Optional[List[str]]): List of paths to additional files (manuals, images, etc.).
            notes (Optional[str]): Initial notes/complaint from the user.
            asset_id (Optional[str]): Asset ID, if provided.
            model_number (Optional[str]): Model number, if provided.
            serial_number (Optional[str]): Serial number, if provided.

        Returns:
            bool: True if data was successfully handed off, False otherwise.
        """

        self._enforce_access(username, "project_submit")
        self.logger.info(f"Authorized access for user {username} to submit new project {project_id}.")
        
        self.logger.info(f"Collecting data for project {project_id}")
        project_temp_dir = os.path.join(self.input_dir, project_id)
        os.makedirs(project_temp_dir, exist_ok=True)

        collected_file_paths = []
        mrr_data_content = {} # To store MRR data read from file or generated

        # 1. Handle MRR file if provided
        if mrr_path:
            try:
                # Copy MRR file to project's temporary directory
                copied_mrr_path = safe_copy_file(mrr_path, project_temp_dir)
                collected_file_paths.append(copied_mrr_path)
                with open(copied_mrr_path, 'r') as f:
                    mrr_data_content = json.load(f)
                self.logger.info(f"Copied and loaded MRR file: {copied_mrr_path}")
            except FileNotFoundError:
                self.logger.warning(f"MRR file missing: {mrr_path}. Proceeding without it.")
            except json.JSONDecodeError as e:
                self.logger.error(f"Invalid JSON in MRR file {mrr_path}: {e}. Generating fallback MRR.")
                mrr_data_content = {} # Reset to generate fallback
            except Exception as e:
                self.logger.error(f"Error processing MRR file {mrr_path}: {e}. Generating fallback MRR.")
                mrr_data_content = {} # Reset to generate fallback

        # 2. Generate fallback MRR data if no valid MRR file was provided or loaded
        if not mrr_data_content:
            mrr_data_content = {
                "project_id": project_id,
                "asset_id": asset_id or project_id,
                "model_number": model_number,
                "serial_number": serial_number,
                "initial_complaint": notes or "Unknown",
                "notes": [notes] if notes else [],
                "timestamp": datetime.datetime.now().isoformat(),
                "username": username,
            }
            self.logger.info(f"Generated fallback MRR data for project {project_id}.")

        # 3. Handle supporting files
        if supporting_files:
            copied_support_files = safe_copy_files(supporting_files, project_temp_dir)
            collected_file_paths.extend(copied_support_files)
            self.logger.info(f"Copied supporting files: {copied_support_files}")

        # 4. Handle notes
        if notes:
            notes_path = os.path.join(project_temp_dir, f"{project_id}_user_notes.txt")
            with open(notes_path, 'w') as f:
                f.write(notes)
            collected_file_paths.append(notes_path)
            self.logger.info(f"Saved user notes to {notes_path}")

        if not collected_file_paths and not mrr_data_content:
            self.logger.error("No input files or MRR data provided for initial collection.")
            return False

        # Prepare the raw_input_data dictionary for ProcessingDepartment
        raw_input_data = {
            "project_id": project_id,
            "username": username,
            "mrr_data": mrr_data_content,
            "asset_specs": { # Placeholder for asset specs, can be expanded
                "model_number": model_number,
                "serial_number": serial_number,
                "asset_id": asset_id
            },
            "notes": notes,
            "file_paths": collected_file_paths, # Paths to the temporary copies
            "input_path_original": project_temp_dir # The temporary directory where files are stored
        }

        if self.next_handler:
            try:
                # Hand off to ProcessingDepartment's receive_initial_project_data
                success = self.next_handler.receive_initial_project_data(project_id, raw_input_data, username)
                if success:
                    self.logger.info(f"Successfully handed off initial data to ProcessingDepartment for project {project_id}.")
                    # Archive the project directory only after successful handoff
                    safe_archive_project(project_temp_dir, self.archive_dir, project_id, username)
                else:
                    self.logger.error(f"ProcessingDepartment failed to receive initial data for project {project_id}.")
                return success
            except Exception as e:
                self.logger.critical(f"FATAL: Error during handoff to ProcessingDepartment for project {project_id}: {e}")
                return False
        else:
            self.logger.error("No ProcessingDepartment (next_handler) configured.")
            return False

    def receive_final_document(self, project_id: str, pdf_ready_json: Dict[str, Any], username: str):
        """
        Receives the final "PDF-ready JSON" from the ProcessingDepartment.
        This method will trigger PDF generation and initial saving via StorageManager.
        Subsequent saving based on user feedback is handled by handle_user_document_feedback.

        Args:
            project_id (str): The ID of the completed project.
            pdf_ready_json (Dict[str, Any]): The aggregated and cleaned JSON data ready for PDF generation.
            username (str): The ID of the user submitting the data.
        """
        self.logger.info(f"Received final PDF-ready JSON for project {project_id}.")

        if not self.storage:
            self.logger.error("StorageManager not configured. Cannot save final document.")
            # Potentially send an error back to ProcessingDepartment
            if self.next_handler and hasattr(self.next_handler, '_send_error_to_project'):
                self.next_handler._send_error_to_project(project_id, "storage_not_configured", "StorageManager instance is missing.", username)
            return

        # Define the output filename for the PDF
        document_id = pdf_ready_json.get("document_id", f"DOC-{project_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}")
        
        try:
            # Use StorageManager to write the JSON and generate the PDF
            # The 'write' method should handle the PDF generation internally
            self.storage.write(project_id, document_id, pdf_ready_json, username)
            self.logger.info(f"Final PDF for project {project_id} generated and saved via StorageManager at {self.storage.base_path}/{project_id}/{document_id}.json and .pdf")

            # At this point, the document is generated and stored in its primary location.
            # The UI will then retrieve it and present it to the user.
            # User feedback (completion or problem) will come via secure_api.py
            # which will call handle_user_document_feedback.

        except Exception as e:
            self.logger.error(f"Error generating or saving final document for project {project_id}: {e}")
            # Send an error back to ProcessingDepartment
            if self.next_handler and hasattr(self.next_handler, '_send_error_to_project'):
                self.next_handler._send_error_to_project(project_id, "final_doc_generation_failure", str(e), username)


    def handle_user_document_feedback(self, project_id: str, document_id: str, feedback_type: str, username: str, new_mrr_data: Optional[Dict[str, Any]] = None):
        """
        This method is called by secure_api.py when the UI provides user feedback
        (e.g., "completed" or "problem") on a generated document.

        Args:
            project_id (str): The ID of the project.
            document_id (str): The ID of the specific document version being reviewed.
            feedback_type (str): Type of feedback, either "completed" or "problem".
            new_mrr_data (Optional[Dict[str, Any]]): New or corrected MRR data if feedback_type is "problem".
            username (str): The ID of the user submitting the data.
        """
        self.logger.info(f"Received user feedback '{feedback_type}' for project {project_id}, document {document_id}.")

        if feedback_type == "completed":
            self.logger.info(f"User confirmed completion for project {project_id}. Finalizing document saving.")
            # Retrieve the pdf_ready_json to pass to _handle_document_saving
            # This would typically involve reading the JSON from storage, or it could be passed
            # along with the feedback if the API design supports it.
            # For this example, we'll assume we can reconstruct/find the path.
            # In a real system, you might fetch the JSON from self.storage.read(project_id, document_id)
            # For now, we'll pass a dummy dict for doc_data, as _handle_document_saving primarily uses document_id
            # and project_id to locate the PDF.
            self._handle_document_saving(project_id, document_id)
            self.logger.info(f"Document for project {project_id} finalized based on user completion.")
            # Conceptually, send a message to the user's account about completed project
            # This would be handled by a separate notification system/API.

        elif feedback_type == "problem":
            self.logger.warning(f"User reported a problem for project {project_id}. Initiating re-evaluation.")
            if new_mrr_data:
                self.receive_modified_mrr_from_ui(project_id, new_mrr_data, username)
            else:
                self.logger.error(f"User reported problem for {project_id} but no new_mrr_data provided for re-evaluation.")
                # Send error back to ProcessingDepartment
                if self.next_handler and hasattr(self.next_handler, '_send_error_to_project'):
                    self.next_handler._send_error_to_project(project_id, "user_problem_no_data", "User reported problem but no new MRR data was provided.", username)
        else:
            self.logger.error(f"Unknown feedback type '{feedback_type}' received for project {project_id}.")
            # Send error back to ProcessingDepartment
            if self.next_handler and hasattr(self.next_handler, '_send_error_to_project'):
                self.next_handler._send_error_to_project(project_id, "unknown_feedback_type", f"Unknown feedback type: {feedback_type}", username)


    def _handle_document_saving(self, project_id: str, document_id: str, username: str):
        """
        Manages saving the final PDF document based on originality and user confirmation.
        This method assumes the PDF has already been generated and saved by StorageManager.write.

        Args:
            project_id (str): The ID of the project.
            document_id (str): The unique ID of the document version.
            username (str): The ID of the user submitting the data.
        """
        self.logger.info(f"Handling document saving for project {project_id}, document ID: {document_id}")

        # Construct paths for the final PDF generated by StorageManager
        # Assuming StorageManager saves to self.storage.base_path / project_id / document_id.pdf
        if not self.storage:
            self.logger.error("StorageManager not configured. Cannot handle document saving.")
            return

        storage_pdf_path = os.path.join(self.storage.base_path, project_id, f"{document_id}.pdf")
        storage_json_path = os.path.join(self.storage.base_path, project_id, f"{document_id}.json")

        # Check if the document (PDF and JSON) already exists in the main storage
        is_original = not (os.path.exists(storage_pdf_path) and os.path.exists(storage_json_path))
        
        if is_original:
            self.logger.info(f"Document {document_id} for project {project_id} is considered original. Saving to editor_new.")
            # Save a copy to editor_new_dir
            try:
                if os.path.exists(storage_pdf_path):
                    safe_copy_file(storage_pdf_path, self.editor_new_dir)
                    self.logger.info(f"Copied {document_id}.pdf to {self.editor_new_dir}")
                else:
                    self.logger.warning(f"Original PDF not found at {storage_pdf_path} for copying to editor_new.")
            except Exception as e:
                self.logger.error(f"Failed to copy {document_id}.pdf to {self.editor_new_dir}: {e}")
        else:
            self.logger.info(f"Document {document_id} for project {project_id} is not original (already exists).")

        # Always save a copy to editor_recommendations_dir
        try:
            if os.path.exists(storage_pdf_path):
                safe_copy_file(storage_pdf_path, self.editor_recommendations_dir)
                self.logger.info(f"Copied {document_id}.pdf to {self.editor_recommendations_dir}")
            else:
                self.logger.warning(f"Original PDF not found at {storage_pdf_path} for copying to editor_recommendations.")
        except Exception as e:
            self.logger.error(f"Failed to copy {document_id}.pdf to {self.editor_recommendations_dir}: {e}")

    def receive_processing_status_update(self, sender: str, status_type: str, payload: Dict[str, Any], username: str):
        """
        Receives status updates (warnings or errors) from the ProcessingDepartment.
        This method logs the status and conceptually informs the UI (via API).

        Args:
            sender (str): The name of the department sending the update (e.g., "ProcessingDepartment").
            status_type (str): Type of status ("warning" or "error").
            payload (Dict[str, Any]): Dictionary containing details like project_id, message, error_type, etc.
            username (str): The ID of the user submitting the data.
        """
        project_id = payload.get("project_id", "N/A")
        message = payload.get("message", "No message provided.")
        error_type = payload.get("error_type", "N/A")

        if status_type == "warning":
            self.logger.warning(f"Received warning from {sender} for project {project_id}: {message}")
            # This warning would be relayed to the UI via secure_api.py
            # The UI would then prompt the user for more information (e.g., modified MRR).
        elif status_type == "error":
            self.logger.error(f"Received critical error from {sender} for project {project_id}: {message} (Type: {error_type})")
            # This error would be relayed to the UI via secure_api.py
            # The UI would display a critical error notification.
        else:
            self.logger.info(f"Received unknown status update from {sender} for project {project_id}: {status_type} - {message}")

    def receive_modified_mrr_from_ui(self, project_id: str, new_mrr_data: Dict[str, Any], username: (str)):
        """
        This method is called by secure_api.py when the UI provides a modified MRR
        due to a problem or a need for more details.

        Args:
            project_id (str): The ID of the project to re-evaluate.
            new_mrr_data (Dict[str, Any]): The new or corrected MRR data from the UI.
            username (str): The ID of the user submitting the data.
        """
        self.logger.info(f"Received modified MRR from UI for project {project_id}. Initiating re-evaluation.")
        if self.next_handler:
            try:
                # Send the command to ProcessingDepartment to re-evaluate
                self.next_handler.receive_command_from_project_for_re_evaluation(
                    self.name,
                    "modified_mrr",
                    {"project_id": project_id, "new_mrr_data": new_mrr_data},
                    username,
                )
                self.logger.info(f"Successfully sent modified MRR to ProcessingDepartment for project {project_id}.")
            except Exception as e:
                self.logger.error(f"Error sending modified MRR to ProcessingDepartment for project {project_id}: {e}")
                # Potentially send an error back to UI via secure_api.py
                if self.next_handler and hasattr(self.next_handler, '_send_error_to_project'):
                    self.next_handler._send_error_to_project(project_id, "modified_mrr_handoff_failure", str(e))
        else:
            self.logger.error("No ProcessingDepartment (next_handler) configured to receive modified MRR.")

