"""
data_parser.py
--------------
Robust file-to-JSON/text parser used by ProcessingDepartment.
- Supports: pdf, docx, xlsx, csv, jpg/png/tiff, heic, msg/eml, json, txt
- Uses OCR for images/PDFs where needed (Tesseract + Pillow)
- Soft-fail behavior: never raises to caller; returns None on total failure and logs error in result["errors"]
- Returns: Tuple[str, Any] -> (mime_type, content)
    * For "application/json": `content` is a dict with a richer schema (see SCHEMA below)
    * For "text/plain": `content` is a string (used by existing pipeline for manual_content_combined)
    
SCHEMA (application/json content):
{
  "schema_version": "1.0",
  "filename": "<name>",
  "file_type": "<detected human type>",
  "meta": {
    "mime": "<mime>",
    "size_bytes": int,
    "created_at": "...",     # best-effort
    "modified_at": "...",    # best-effort
  },
  "extracted_text": "<full plain text if available>",
  "combined_text": "<alias of extracted_text for convenience>",
  "structured": {...},       # type-specific structured data (e.g., workbook sheets, email headers)
  "warnings": [ ... ],       # non-fatal issues
  "errors":   [ ... ]        # fatal or skipped steps
}

NOTES
- For Excel/CSV we emit application/json with "structured" data (rows) AND "combined_text".
- For DOCX we emit application/json with extracted text (and "manual_text" alias for compatibility).
- For PDF:
  1) Try text extraction; if empty, try OCR (per page images if needed).
  2) Result: application/json with "extracted_text" and "manual_text" for compatibility.
- For images (jpg/png/tiff/heic): OCR -> application/json with "extracted_text".
- For MSG/EML: Produce structured headers/body/attachments; also "combined_text".
- For TXT: returns ("text/plain", text) for compatibility with existing pipeline.
- For JSON: returns ("application/json", parsed) untouched, but we add a warning entry if not a dict.

You may call:
    DataParser().parse_file(path)      # existing flow
    DataParser().parse_stream(file_bytes, filename="name.ext")  # optional in-memory support
"""
from __future__ import annotations

import os
import io
import json
import csv
import mimetypes
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

# Optional deps – guard imports so missing libs don't crash the parser.
try:
    # PDF text extraction (fast)
    from pdfminer.high_level import extract_text as pdfminer_extract_text  # type: ignore
except Exception:
    pdfminer_extract_text = None

try:
    # Alternative PDF (fallback)
    import PyPDF2  # type: ignore
except Exception:
    PyPDF2 = None

try:
    # Word
    import docx  # python-docx  # type: ignore
except Exception:
    docx = None

try:
    # Excel
    import openpyxl  # type: ignore
except Exception:
    openpyxl = None

try:
    # OCR stack
    from PIL import Image  # type: ignore
except Exception:
    Image = None

try:
    import pytesseract  # type: ignore
except Exception:
    pytesseract = None

try:
    # HEIC support
    import pillow_heif  # type: ignore
    if Image and hasattr(pillow_heif, "register_heif_opener"):
        pillow_heif.register_heif_opener()
except Exception:
    pillow_heif = None

try:
    # Outlook .msg
    import extract_msg  # type: ignore
except Exception:
    extract_msg = None

# EML via stdlib
import email
from email import policy
from email.parser import BytesParser


def _now_iso() -> str:
    return datetime.now().isoformat()


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as f:
        return f.read()


def _stat_meta(path: str) -> Dict[str, Any]:
    meta: Dict[str, Any] = {}
    try:
        st = os.stat(path)
        meta["size_bytes"] = st.st_size
        meta["created_at"] = datetime.fromtimestamp(getattr(st, "st_ctime", st.st_mtime)).isoformat()
        meta["modified_at"] = datetime.fromtimestamp(st.st_mtime).isoformat()
    except Exception:
        pass
    return meta


def _guess_mime(filename: str, default: str = "application/octet-stream") -> str:
    mime, _ = mimetypes.guess_type(filename)
    return mime or default


class DataParser:
    SCHEMA_VERSION = "1.0"

    def __init__(self):
        pass

    # ========== PUBLIC API ==========
    def parse_file(self, path: str) -> Optional[Tuple[str, Any]]:
        """
        Parse a file from disk. Returns (mime, content) or None on hard failure.
        """
        try:
            filename = os.path.basename(path)
            if not os.path.exists(path):
                return None

            mime = _guess_mime(filename)
            ext = os.path.splitext(filename)[1].lower()

            # Dispatch by extension first (more reliable for some types)
            if ext in {".json"}:
                return self._parse_json_file(path, filename, mime)

            if ext in {".txt", ".log"}:
                text = _read_bytes(path).decode(errors="replace")
                return "text/plain", text

            if ext in {".docx"}:
                return self._parse_docx(path, filename)

            if ext in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
                return self._parse_excel(path, filename)

            if ext in {".csv"}:
                return self._parse_csv(path, filename)

            if ext in {".pdf"}:
                return self._parse_pdf(path, filename)

            if ext in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".heic", ".heif"}:
                return self._parse_image(path, filename, ext)

            if ext in {".eml"}:
                return self._parse_eml(path, filename)

            if ext in {".msg"}:
                return self._parse_msg(path, filename)

            # Fallback by MIME
            if mime == "application/pdf":
                return self._parse_pdf(path, filename)
            if mime and mime.startswith("image/"):
                return self._parse_image(path, filename, ext)

            # Unknown -> treat as binary; return None
            return None
        except Exception:
            # Hard failure: return None to respect soft-fail contract used by ProcessingDepartment
            return None

    def parse_stream(self, data: bytes, filename: str) -> Optional[Tuple[str, Any]]:
        """
        Optional in-memory parsing. Saves to a temp BytesIO where needed.
        """
        try:
            mime = _guess_mime(filename)
            ext = os.path.splitext(filename)[1].lower()

            # Use temp file on disk for libraries that require a path
            tmp_path = None
            try:
                # Prefer disk because some libs (pdfminer/openpyxl) need a path
                import tempfile
                fd, tmp_path = tempfile.mkstemp(suffix=ext or ".bin")
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
                return self.parse_file(tmp_path)
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
        except Exception:
            return None

    # ========== TYPE HANDLERS ==========

    def _base_json_envelope(self, filename: str, mime: str, human_type: str, path: Optional[str] = None) -> Dict[str, Any]:
        env: Dict[str, Any] = {
            "schema_version": self.SCHEMA_VERSION,
            "filename": filename,
            "file_type": human_type,
            "meta": {"mime": mime},
            "extracted_text": "",
            "combined_text": "",
            "structured": {},
            "warnings": [],
            "errors": [],
        }
        if path:
            env["meta"].update(_stat_meta(path))
        return env

    def _parse_json_file(self, path: str, filename: str, mime: str) -> Tuple[str, Any]:
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                data = json.load(f)
            if isinstance(data, dict):
                # Make sure manual_text alias exists if there is textual content
                if "extracted_text" in data and "manual_text" not in data:
                    data["manual_text"] = data.get("extracted_text", "")
                return "application/json", data
            else:
                env = self._base_json_envelope(filename, mime, "JSON", path)
                env["warnings"].append("Root JSON was not an object; wrapped as envelope.")
                env["structured"]["value"] = data
                return "application/json", env
        except Exception as e:
            # On error, return None so Processing skips this file gracefully
            return None  # type: ignore

    def _parse_docx(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        env = self._base_json_envelope(filename, mime, "DOCX", path)
        if not docx:
            env["errors"].append("python-docx not installed")
            return "application/json", env
        try:
            doc = docx.Document(path)
            paras = [p.text for p in doc.paragraphs]
            text = "\n".join([p for p in paras if p])
            env["extracted_text"] = text
            env["combined_text"] = text
            env["structured"]["paragraph_count"] = len(paras)
            # Back-compat: let Processing treat this like a manual
            env["manual_text"] = text
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"DOCX parse error: {e}")
            return "application/json", env

    def _parse_excel(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        env = self._base_json_envelope(filename, mime, "Excel", path)
        if not openpyxl:
            env["errors"].append("openpyxl not installed")
            return "application/json", env
        try:
            wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
            sheets: Dict[str, List[List[Any]]] = {}
            for ws in wb.worksheets:
                rows: List[List[Any]] = []
                for r in ws.iter_rows(values_only=True):
                    rows.append(list(r))
                sheets[ws.title] = rows
            env["structured"]["sheets"] = sheets
            # Turn rows into a simple combined text for search
            lines: List[str] = []
            for sname, rows in sheets.items():
                lines.append(f"# Sheet: {sname}")
                for r in rows:
                    line = " | ".join("" if v is None else str(v) for v in r)
                    lines.append(line)
            text = "\n".join(lines)
            env["extracted_text"] = text
            env["combined_text"] = text
            env["manual_text"] = text  # optional: allow manuals from excel too
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"Excel parse error: {e}")
            return "application/json", env

    def _parse_csv(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "text/csv"
        env = self._base_json_envelope(filename, mime, "CSV", path)
        try:
            rows: List[List[str]] = []
            with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
                reader = csv.reader(f)
                for row in reader:
                    rows.append(row)
            env["structured"]["rows"] = rows
            text_lines = [" | ".join(r) for r in rows]
            text = "\n".join(text_lines)
            env["extracted_text"] = text
            env["combined_text"] = text
            env["manual_text"] = text
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"CSV parse error: {e}")
            return "application/json", env

    def _parse_pdf(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "application/pdf"
        env = self._base_json_envelope(filename, mime, "PDF", path)

        text = ""
        # 1) Try pdfminer
        try:
            if pdfminer_extract_text:
                text = pdfminer_extract_text(path) or ""
        except Exception as e:
            env["warnings"].append(f"pdfminer failed: {e}")

        # 2) Fallback PyPDF2 (text)
        if not text and PyPDF2:
            try:
                with open(path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    pieces: List[str] = []
                    for page in reader.pages:
                        try:
                            t = page.extract_text() or ""
                        except Exception:
                            t = ""
                        if t:
                            pieces.append(t)
                    text = "\n".join(pieces)
            except Exception as e:
                env["warnings"].append(f"PyPDF2 text extract failed: {e}")

        # 3) OCR if still empty
        if not text:
            if Image and pytesseract:
                try:
                    # Convert each page to image for OCR using pdf2image if available; otherwise fallback to single preview
                    # We avoid requiring pdf2image/poppler here. Instead, do a naive raster via PIL (works for some PDFs).
                    # If that's not possible, record a warning and skip OCR.
                    from PIL import Image as PILImage  # type: ignore
                    try:
                        # Attempt to open as an image sequence (works for some single-page PDFs with embedded previews)
                        pil_img = PILImage.open(path)
                        ocr_text_parts: List[str] = []
                        try:
                            while True:
                                ocr_text_parts.append(pytesseract.image_to_string(pil_img))
                                pil_img.seek(pil_img.tell() + 1)
                        except EOFError:
                            pass
                        text = "\n".join(ocr_text_parts).strip()
                    except Exception:
                        env["warnings"].append("OCR fallback requires pdf2image/poppler for multi-page PDFs.")
                except Exception as e:
                    env["warnings"].append(f"OCR attempt failed: {e}")
            else:
                env["warnings"].append("OCR not available (Pillow/pytesseract missing).")

        env["extracted_text"] = text
        env["combined_text"] = text
        env["manual_text"] = text  # keep alias for Processing
        return "application/json", env

    def _parse_image(self, path: str, filename: str, ext: str) -> Optional[Tuple[str, Any]]:
        mime = _guess_mime(filename, "image/*")
        env = self._base_json_envelope(filename, mime, "Image", path)
        if not Image:
            env["errors"].append("Pillow not installed")
            return "application/json", env
        try:
            img = Image.open(path)
            text = ""
            if pytesseract:
                try:
                    text = pytesseract.image_to_string(img)
                except Exception as e:
                    env["warnings"].append(f"OCR failed: {e}")
            else:
                env["warnings"].append("pytesseract not installed; OCR skipped.")
            env["extracted_text"] = text
            env["combined_text"] = text
            env["manual_text"] = text
            # Basic EXIF
            try:
                exif = getattr(img, "_getexif", lambda: None)()
                if exif:
                    env["structured"]["exif"] = {str(k): str(v) for k, v in exif.items()}
            except Exception:
                pass
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"Image parse error: {e}")
            return "application/json", env

    def _parse_eml(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "message/rfc822"
        env = self._base_json_envelope(filename, mime, "EML", path)
        try:
            with open(path, "rb") as f:
                msg = BytesParser(policy=policy.default).parse(f)
            headers = {k: str(v) for k, v in msg.items()}
            body_text_parts: List[str] = []

            if msg.is_multipart():
                for part in msg.walk():
                    ctype = part.get_content_type()
                    if ctype == "text/plain":
                        body_text_parts.append(part.get_content())
            else:
                if msg.get_content_type() == "text/plain":
                    body_text_parts.append(msg.get_content())

            body_text = "\n".join(body_text_parts).strip()
            env["structured"]["headers"] = headers
            env["structured"]["subject"] = headers.get("Subject")
            env["structured"]["from"] = headers.get("From")
            env["structured"]["to"] = headers.get("To")
            env["extracted_text"] = body_text
            env["combined_text"] = body_text
            env["manual_text"] = body_text
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"EML parse error: {e}")
            return "application/json", env

    def _parse_msg(self, path: str, filename: str) -> Optional[Tuple[str, Any]]:
        mime = "application/vnd.ms-outlook"
        env = self._base_json_envelope(filename, mime, "MSG", path)
        if not extract_msg:
            env["errors"].append("extract_msg not installed")
            return "application/json", env
        try:
            msg = extract_msg.Message(path)
            subject = getattr(msg, "subject", None)
            sender = getattr(msg, "sender", None)
            to = getattr(msg, "to", None)
            date = getattr(msg, "date", None)
            body = getattr(msg, "body", "") or ""

            env["structured"]["headers"] = {
                "Subject": subject, "From": sender, "To": to, "Date": str(date)
            }
            env["extracted_text"] = body
            env["combined_text"] = body
            env["manual_text"] = body
            return "application/json", env
        except Exception as e:
            env["errors"].append(f"MSG parse error: {e}")
            return "application/json", env
