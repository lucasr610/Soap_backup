# === ~/oracle_archive/oracle_back/oracle_dept/parts.py ===
# Parts Department module
# Identifies and correlates relevant parts to the asset, flags critical needs
# THIS CODE IS DESIGNED TO PROCESS REAL DATA AS PART OF A CRITICAL SAFETY SYSTEM.

import os
import json
import datetime
import sys
import re 
from typing import Dict, List, Optional, Any

# Ensure AppConfig and logger_factory are correctly accessible based on your project structure
# This path setup is crucial for your modules to find each other.
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app_config import AppConfig
from logger_factory import setup_logger
from security_manager import SecurityManager
from access_control import AccessControlManager


class PartsDepartment:
    def __init__(
        self,
        processing,
        security_manager: SecurityManager,
        access_control_manager: AccessControlManager
        ):
        """
        Initializes the PartsDepartment.
        It requires a direct reference to the ProcessingDepartment for communication.
        
        This constructor has been updated to accept security and access control managers.
        """
        self.name = "PartsDepartment"
        # Base directory for PartsDepartment's data, ensuring it's within your oracle_data archive.
        # AppConfig.BASE_DATA_DIR should point to '~/oracle_archive/oracle_data'
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, 'parts_data')
        self.inbox = os.path.join(self.base, 'parts_inbox')
        self.outbox = os.path.join(self.base, 'parts_outbox')

        # Ensure necessary directories exist for data storage and output.
        os.makedirs(self.inbox, exist_ok=True)
        os.makedirs(self.outbox, exist_ok=True)

        # Setup department-specific logger for traceability.
        self.logger = setup_logger(self.name, 'parts_department.log')

        # Store the reference to the central ProcessingDepartment.
        # This is how all reports and re-evaluation requests are communicated.
        self.processing = processing
        self.logger.info(f"{self.name} initialized and ready to receive commands from ProcessingDepartment.")
        
        # --- NEW CODE: Store references to security and access control managers ---
        self.security_manager = security_manager
        self.access_control_manager = access_control_manager


    def receive_command_from_processing(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        PRIMARY ENTRY POINT for data coming from the ProcessingDepartment.
        This method explicitly verifies the sender and the presence of critical data.
        It serves as the 'registration' point for incoming project data.

        Args:
            sender (str): The name of the sending department (must be "ProcessingDepartment").
            cmd_type (str): The type of command (e.g., "initial_data", "re_evaluation_data").
            data (Dict): The comprehensive 'full_data' dictionary containing all translated project information.

        Returns:
            bool: True if the command was successfully received and processing initiated, False otherwise.
        """
        project_id = data.get("project_id")
        full_data = data.get("full_data")
        username = data.get("username", username)

        # --- SECURITY AND DATA INTEGRITY CHECKS ---
        if sender != "ProcessingDepartment":
            self.logger.critical(f"SECURITY ALERT: Unauthorized sender '{sender}' attempted to send command to PartsDepartment for project_id: {project_id}. Command Type: {cmd_type}. This incident will be reported.")
            # In a real system, this might trigger an immediate security alert or shutdown.
            return False

        if not project_id:
            self.logger.error(f"DATA INTEGRITY ERROR: Received command from {sender} with missing 'project_id'. Cannot process. Command Type: {cmd_type}. Data keys received: {list(data.keys())}")
            # Cannot send an error report back without a project_id, so log critically.
            return False

        if not full_data:
            self.logger.error(f"DATA INTEGRITY ERROR: Received command for project_id: {project_id} from {sender} with empty or missing 'full_data'. This is critical. Command Type: {cmd_type}.")
            self._send_error(project_id, "empty_full_data_received", {"message": "Received empty or missing 'full_data' dictionary. Cannot proceed with analysis."}, username)
            return False

        # --- EXPLICIT DATA REGISTRATION AND CONFIRMATION ---
        self.logger.info(f"--- DATA RECEIVED AND REGISTERED ---")
        self.logger.info(f"PartsDepartment has RECEIVED command '{cmd_type}' for project_id: {project_id} from {sender}, initiated by user: {username}.")
        self.logger.info(f"Confirmed 'full_data' presence. Top-level keys in received data: {list(full_data.keys())}")
        self.logger.info(f"Size of received 'full_data' (approx): {sys.getsizeof(json.dumps(full_data))} bytes.")
        # This logging confirms the data has arrived and is not empty.

        # Route the command based on its type.
        if cmd_type in ["initial_data", "re_evaluation", "re_evaluation_data"]:
            self.logger.info(f"Initiating primary processing for project_id: {project_id} with command type: '{cmd_type}'.")
            return self._process(project_id, full_data, username)
        else:
            self.logger.error(f"UNSUPPORTED COMMAND TYPE: PartsDepartment received unknown command '{cmd_type}' for project_id: {project_id}.")
            self._send_error(project_id, "unsupported_command_type", {"command_type": cmd_type})
            return False

    def receive_error_feedback(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives error feedback from the ProcessingDepartment.
        This means a previous report from PartsDepartment resulted in an 'Error'
        and ProcessingDepartment is requesting a re-evaluation with potentially updated data.

        Args:
            sender (str): The name of the sending department (must be "ProcessingDepartment").
            cmd_type (str): The type of command (must be "error_feedback").
            data (Dict): Contains 'project_id', 'missing_info', and the 'full_data' for re-evaluation.

        Returns:
            bool: True if re-evaluation initiated, False otherwise.
        """
        project_id = data.get("project_id")
        missing_info = data.get("missing_info")
        full_data = data.get("full_data")
        username = data.get("username", username)

        if sender != "ProcessingDepartment" or cmd_type != "error_feedback":
            self.logger.critical(f"SECURITY ALERT: Invalid error feedback received from '{sender}' with cmd_type '{cmd_type}'. Project ID: {project_id}.")
            return False # Critical error, cannot rely on sender.

        if not project_id or not full_data:
            self.logger.error(f"DATA INTEGRITY ERROR: Received incomplete error feedback for project_id: {project_id}. Missing project_id or 'full_data'.")
            return False
            
        # --- NEW CODE: Add security and access control checks here ---
        if not username or not self.security_manager.is_subscription_valid(username) or not self.access_control_manager.check_access(username, "parts_analyze"):
            self.logger.critical(f"SECURITY ALERT: Re-evaluation request for project {project_id} failed security checks for user '{username}'.")
            # Do not send an error back, as the original request may be the problem. Just log and abort.
            return False

        self.logger.warning(f"--- RE-EVALUATION TRIGGERED ---")
        self.logger.warning(f"PartsDepartment received error feedback for project_id: {project_id}. Missing info reported: '{missing_info}'.")
        self.logger.warning(f"Re-attempting processing with updated 'full_data'. Full_data keys: {list(full_data.keys())}")

        # Re-attempt processing with the potentially updated/clarified full_data.
        # This ensures the retry mechanism uses the latest, corrected information.
        return self._process(project_id, full_data, username)


    def _process(self, project_id: str, full_data: Dict, username: str) -> bool:
        """
        Core processing logic for the PartsDepartment.
        This method actively extracts and utilizes the REAL CONTENT from the 'full_data' dictionary,
        which was translated from the original uploaded files by the ProcessingDepartment.

        Args:
            project_id (str): The unique identifier for the current project.
            full_data (Dict): The comprehensive, standardized dictionary containing all
                              translated data from the raw input files (manuals, specs, etc.).

        Returns:
            bool: True if parts analysis was successful and a report was sent, False otherwise.
        """
        self.logger.info(f"PartsDepartment: Starting detailed analysis for project_id: {project_id}.")
        self.logger.debug(f"Beginning to extract and analyze REAL DATA from 'full_data' for project {project_id}.")

        # --- REAL DATA EXTRACTION ---
        # These fields contain the actual content extracted by ProcessingDepartment from your files.
        mrr_data = full_data.get("mrr_data", {})
        asset_specs = full_data.get("asset_specs", {})
        manual_content_combined = full_data.get("manual_content_combined", "") # This is the actual text from manuals
        extracted_json_content = full_data.get("extracted_json_content", {})   # This is actual parsed JSON from files
        extracted_text_content = full_data.get("extracted_text_content", {})   # This is actual text from .txt files
        file_paths_metadata = full_data.get("extracted_files_metadata", [])    # Metadata about original files

        # --- LOGGING REAL DATA CONTENT FOR VERIFICATION ---
        self.logger.debug(f"REAL DATA CHECK - MRR Data keys: {list(mrr_data.keys()) if mrr_data else 'None'}")
        self.logger.debug(f"REAL DATA CHECK - Asset Specifications keys: {list(asset_specs.keys()) if asset_specs else 'None'}")
        self.logger.debug(f"REAL DATA CHECK - Combined Manual Content Length: {len(manual_content_combined)} characters.")
        if len(manual_content_combined) > 0:
            self.logger.debug(f"REAL DATA CHECK - Sample of Manual Content: '{manual_content_combined[:200]}...'") # Log a snippet
        self.logger.debug(f"REAL DATA CHECK - Extracted JSON Files (filenames): {list(extracted_json_content.keys())}")
        self.logger.debug(f"REAL DATA CHECK - Extracted Text Files (filenames): {list(extracted_text_content.keys())}")
        self.logger.debug(f"REAL DATA CHECK - Original File Metadata Count: {len(file_paths_metadata)}")


        output = {
            "project_id": project_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "service_type": "parts_analysis_report",
            "parts_list": [],
            "bill_of_materials": [],
            "parts_diagrams": [],
            "critical_flags": [],
            "analysis_notes": []
        }

        # --- CONCRETE PARTS ANALYSIS LOGIC (USING REAL DATA) ---
        # This section now genuinely attempts to extract information from the received 'full_data'.
        # This is where your actual parsing and analysis algorithms would be implemented.

        # 1. Analyze Asset Specifications for known parts/requirements
        if asset_specs:
            self.logger.info(f"Analyzing REAL asset specifications for parts in project {project_id}.")
            if asset_specs.get("engine_type", "").lower() == "turbine":
                output["parts_list"].append({"component": "Turbine Blade Set", "quantity": "N/A", "source": "Asset Specs"})
                output["analysis_notes"].append("Identified turbine blades based on engine type from asset specifications.")
            if asset_specs.get("hydraulic_system", False) is True:
                output["parts_list"].append({"component": "Hydraulic Pump", "quantity": 1, "source": "Asset Specs"})
                output["parts_list"].append({"component": "Hydraulic Filter", "quantity": 1, "source": "Asset Specs"})
                output["analysis_notes"].append("Identified hydraulic components based on system presence in asset specifications.")
            if asset_specs.get("max_operating_pressure_psi", 0) > 500:
                output["critical_flags"].append({"flag": "High Pressure System", "notes": "Verify pressure seals and fittings. Special tooling may be required."})
                output["analysis_notes"].append("Flagged as high pressure system based on operating pressure in asset specifications.")

        # 2. Search Combined Manual Content (REAL TEXT) for parts keywords
        if manual_content_combined:
            self.logger.info(f"Searching REAL combined manual content for parts keywords in project {project_id}.")
            manual_lower = manual_content_combined.lower()
            if "bearing" in manual_lower:
                output["parts_list"].append({"component": "Bearing", "quantity": "N/A", "source": "Manual Content"})
                output["analysis_notes"].append("Found 'bearing' keyword in actual manual content.")
            if "gasket" in manual_lower:
                output["parts_list"].append({"component": "Gasket", "quantity": "N/A", "source": "Manual Content"})
                output["analysis_notes"].append("Found 'gasket' keyword in actual manual content.")
            if "lubricant" in manual_lower or "oil" in manual_lower:
                output["parts_list"].append({"component": "Lubricant/Oil", "quantity": "N/A", "source": "Manual Content"})
                output["analysis_notes"].append("Found 'lubricant' or 'oil' keyword in actual manual content.")
                
            # Patterns that capture: name + optional PN + quantity (order can vary)
            line_patterns = [
                # e.g., "Part No. ABC-123 — Bearing, Qty 2" or "PN: 123-456 | Gasket | Qty: 4"
                re.compile(
                    r'(?:part\s*(?:no\.?|number|#)\s*[:\-]?\s*(?P<pn>[A-Z0-9][A-Z0-9\-\._/]+))?'
                    r'.{0,30}?'
                    r'(?P<name>(?:bearing|gasket|seal|filter|pump|blade|valve|hose|belt|o[- ]?ring|lubricant|oil)[A-Za-z0-9 \-_/\.]{0,50})'
                    r'.{0,50}?'
                    r'(?:qty|quantity)\s*[:\-]?\s*(?P<qty>\d{1,4})',
                    re.IGNORECASE
                ),
                # e.g., "Gasket — PN 7F-2211 — Qty 3"
                re.compile(
                    r'(?P<name>[A-Za-z][A-Za-z0-9 \-_/\.]{2,60})\s*[,|\-–—]\s*'
                    r'(?:pn|part\s*(?:no\.?|number|#))\s*[:\-]?\s*(?P<pn>[A-Z0-9][A-Z0-9\-\._/]+)\s*[,|\-–—]\s*'
                    r'(?:qty|quantity)\s*[:\-]?\s*(?P<qty>\d{1,4})',
                    re.IGNORECASE
                ),
            ]

            # Scan manual line-by-line for matches
            for raw_line in manual_content_combined.splitlines():
                line = raw_line.strip()
                if not line:
                    continue

                for pat in line_patterns:
                    m = pat.search(line)
                    if not m:
                        continue

                    component = (m.group('name') or '').strip(" \t-—,")
                    part_number = (m.groupdict().get('pn') or '').strip()
                    qty_txt = (m.groupdict().get('qty') or '').strip()
                    quantity = int(qty_txt) if qty_txt.isdigit() else None

                    if component:
                        output["parts_list"].append({
                            "component": component,
                            "part_number": part_number or None,
                            "quantity": quantity,
                            "source": "Manual Content (parsed)"
                        })
                        output["analysis_notes"].append(
                            f"Parsed manual line into part: {component}"
                            f"{' (PN ' + part_number + ')' if part_number else ''}"
                            f"{' Qty ' + qty_txt if qty_txt else ''}."
                        )
                        break  # Avoid double-counting the same line by multiple patterns

        # 3. Process parts information from any extracted JSON files (REAL JSON DATA)
        for filename, content in extracted_json_content.items():
            self.logger.info(f"Analyzing REAL JSON content from file: {filename} for parts in project {project_id}.")

            if not isinstance(content, dict):
                output["analysis_notes"].append(
                    f"Warning: JSON root in {filename} is {type(content).__name__}, expected dict."
                )
                continue

            # --- Collect parts/BOM blocks under common keys ---
            parts_blocks = []

            # Prior behavior: explicit parts_information
            if "parts_information" in content:
                parts_blocks.append(("parts_information", content["parts_information"]))

            # New: Bill of Materials (BOM)
            for bom_key in ("bill_of_materials", "bom"):
                if bom_key in content:
                    parts_blocks.append((bom_key, content[bom_key]))

            # New: Parts Lists (singular & plural)
            for pl_key in ("parts_list", "parts_lists"):
                if pl_key in content:
                    parts_blocks.append((pl_key, content[pl_key]))

            # Normalize & route items from collected blocks
            for block_key, block_value in parts_blocks:
                if isinstance(block_value, list):
                    for item in block_value:
                        if isinstance(item, dict):
                            normalized = {
                                "component": item.get("component") or item.get("part_name") or item.get("description"),
                                "part_number": item.get("part_number") or item.get("pn") or item.get("sku"),
                                "quantity": item.get("quantity") or item.get("qty"),
                                "uom": item.get("uom") or item.get("unit"),
                                "notes": item.get("notes") or item.get("comment"),
                                "source": f"JSON File: {filename} ({block_key})"
                            }
                            # Preserve useful extras if present
                            for extra_key in ("manufacturer", "vendor", "price", "currency", "lead_time_days"):
                                if extra_key in item:
                                    normalized[extra_key] = item[extra_key]

                            # Decide destination list
                            target = (
                                "bill_of_materials"
                                if block_key in ("bill_of_materials", "bom")
                                else "parts_list"
                            )

                            if not normalized.get("component"):
                                normalized["notes"] = (normalized.get("notes") or "") + " [Missing component name]"

                            output[target].append(normalized)
                            output["analysis_notes"].append(
                                f"Added item from {block_key} in {filename}: {normalized.get('component') or 'Unnamed item'}."
                            )
                        else:
                            output["analysis_notes"].append(
                                f"Warning: Non-dict item in {block_key} list in {filename}: {repr(item)[:120]}"
                            )
                else:
                    output["analysis_notes"].append(
                        f"Warning: '{block_key}' in {filename} is {type(block_value).__name__}, expected list."
                    )

            # --- Parts diagrams extraction ---
            if "parts_diagrams" in content:
                diagrams = content["parts_diagrams"]
                if isinstance(diagrams, list):
                    for d in diagrams:
                        if isinstance(d, dict):
                            diagram_entry = {
                                "id": d.get("id") or d.get("diagram_id"),
                                "title": d.get("title") or d.get("name"),
                                "file": d.get("file") or d.get("filepath") or d.get("image"),
                                "page": d.get("page"),
                                "url": d.get("url"),
                                "source": f"JSON File: {filename} (parts_diagrams)"
                            }
                            output["parts_diagrams"].append(diagram_entry)
                            output["analysis_notes"].append(
                                f"Registered parts diagram '{diagram_entry.get('title') or diagram_entry.get('id') or 'Untitled'}' from {filename}."
                            )
                        else:
                            output["analysis_notes"].append(
                                f"Warning: Non-dict diagram item in {filename}: {repr(d)[:120]}"
                            )
                else:
                    output["analysis_notes"].append(
                        f"Warning: 'parts_diagrams' in {filename} is {type(diagrams).__name__}, expected list."
                    )

        # --- NEW: Deduplicate and normalize parts across lists ---
        def _norm_name(name: Optional[str]) -> Optional[str]:
            if not name or not isinstance(name, str):
                return None
            cleaned = " ".join(name.lower().strip().replace("_", " ").replace("-", " ").split())
            return cleaned

        def _dedupe_parts(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            seen = {}
            result = []
            for it in items:
                comp = _norm_name(it.get("component"))
                pn = (it.get("part_number") or "").strip() if isinstance(it.get("part_number"), str) else it.get("part_number")
                key = ("pn", pn.upper()) if pn else ("name", comp)

                if key not in seen:
                    seen[key] = len(result)
                    result.append(dict(it))
                else:
                    idx = seen[key]
                    existing = result[idx]
                    q1, q2 = existing.get("quantity"), it.get("quantity")
                    if isinstance(q1, int) and isinstance(q2, int):
                        existing["quantity"] = q1 + q2
                    elif q1 is None and isinstance(q2, int):
                        existing["quantity"] = q2
                    n1 = existing.get("notes")
                    n2 = it.get("notes")
                    notes_set = {n.strip() for n in ([n1] if isinstance(n1, str) else []) if n} | \
                                {n.strip() for n in ([n2] if isinstance(n2, str) else []) if n}
                    if notes_set:
                        existing["notes"] = "; ".join(sorted(notes_set))
                    for k in ("uom", "manufacturer", "vendor", "price", "currency", "lead_time_days"):
                        if not existing.get(k) and it.get(k) is not None:
                            existing[k] = it[k]
                    srcs = set()
                    for s in (existing.get("source"), it.get("source")):
                        if isinstance(s, str) and s:
                            srcs.add(s)
                    existing["source"] = " | ".join(sorted(srcs)) if srcs else existing.get("source")

            return result

        # Apply dedupe to both parts lists
        output["parts_list"] = _dedupe_parts(output.get("parts_list", []))
        output["bill_of_materials"] = _dedupe_parts(output.get("bill_of_materials", []))

        # --- CRITICAL CHECK: If no parts were identified after all REAL data analysis ---
        if not output["parts_list"]:
            self.logger.error(f"CRITICAL FAILURE: No parts identified for project_id: {project_id} after analyzing all available REAL data. This requires immediate attention.")
            output["analysis_notes"].append("CRITICAL: No specific parts identified based on available data. Manual review is MANDATORY. This may indicate insufficient input data or analysis failure.")
            # Send an 'Error' report to ProcessingDepartment, indicating a critical lack of parts data.
            self._send_error(project_id, "no_parts_identified_critical", {"message": "No parts could be identified from the provided real data. Manual review needed to prevent safety risks."}, username)
            return False # Indicate failure to the ProcessingDepartment

        self.logger.info(f"Parts analysis completed successfully for {project_id}. Identified {len(output['parts_list'])} parts and {len(output['critical_flags'])} critical flags.")

        # Save the output report to the outbox. This is the PartsDepartment's tangible output.
        output_filepath = os.path.join(self.outbox, f"parts_report_{project_id}.json")
        try:
            with open(output_filepath, 'w') as f:
                json.dump(output, f, indent=2)
            self.logger.info(f"Saved REAL parts report to {output_filepath}")
        except Exception as e:
            self.logger.critical(f"FILE WRITE ERROR: Failed to save REAL parts report for {project_id}: {e}. This is a critical data persistence failure.")
            self._send_error(project_id, "file_save_failure_critical", str(e), username)
            return False

        # Send an "Accept" report back to the ProcessingDepartment, including the generated report.
        self._send_accept(project_id, output, username)
        return True

    def _send_accept(self, project_id: str, report_details: Dict, username: str):
        """
        Sends an 'Accept' report back to the ProcessingDepartment.
        This confirms successful processing of real data.
        """
        self.logger.info(f"PartsDepartment: Sending 'Accept' report for project {project_id} to ProcessingDepartment.")
        self.processing.receive_report_from_department(
            self.name,
            "report",
            {
                "project_id": project_id,
                "report_type": "Accept",
                "report_details": report_details,
                "missing_information": None,
                "username": username
            },
            username,
        )

    def _send_error(self, project_id: str, error_code: str, details: Dict, username: str):
        """
        Sends an 'Error' report back to the ProcessingDepartment.
        This signals a problem during the processing of real data.
        """
        full_error_details = {
            "error_code": error_code,
            "department": self.name,
            "timestamp": datetime.datetime.now().isoformat(),
            "project_id": project_id,
            "details": details,
            "username": username
        }        
        # Log the error locally for immediate visibility and debugging.
        self.logger.error(f"PartsDepartment: Reporting 'Error' for project {project_id}. Code: {error_code}, Details: {details}. This indicates a problem with real data processing.")

        # Send the error report to the centralized ProcessingDepartment.
        # This is crucial for triggering retries or escalating to ProjectManagerDepartment.
        self.processing.receive_report_from_department(
            self.name,
            "report",
            {
                "project_id": project_id,
                "report_type": "Error",
                "report_details": full_error_details,
                "missing_information": error_code,
                "username": username
            },
            username,
        )
