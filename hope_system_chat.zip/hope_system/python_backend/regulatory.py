# === departments/regulatory.py ===
# Regulations Department module
# Validates compliance and safety standards from diagnosis data

import os
import json
import datetime
import re
from typing import Dict, Any

from app_config import AppConfig
from logger_factory import setup_logger

class RegulationsDepartment:
    def __init__(
        self,
        processing,
        security_manager: Any,
        access_control_manager: Any
        ):
        
        self.name = "RegulationsDepartment"
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, 'regulatory_data')
        self.inbox = os.path.join(self.base, 'regulatory_inbox')
        self.outbox = os.path.join(self.base, 'regulatory_outbox')
        os.makedirs(self.inbox, exist_ok=True)
        os.makedirs(self.outbox, exist_ok=True)
        self.logger = setup_logger(self.name, 'regulations_department.log')
        self.processing = processing
        
        # As per the new architecture, the security and access control managers are passed in
        self.security_manager = security_manager
        self.access_control_manager = access_control_manager

    def receive_command_from_processing(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives aggregated data from the ProcessingDepartment for regulatory validation.
        """
        if sender != "ProcessingDepartment" or cmd_type != "aggregated_data":
            self.logger.error(f"Unsupported command or sender for RegulationsDepartment. Sender: {sender}, Cmd Type: {cmd_type}")
            # Report error back to ProcessingDepartment if the command is unexpected
            self._send_error("N/A", "unsupported_command", {"sender": sender, "cmd_type": cmd_type})
            return False

        project_id = data.get("project_id")
        data_for_validation = data.get("data_for_validation")
        username = data.get("username")

        if not project_id or not data_for_validation:
            self.logger.error(f"Missing project_id or data_for_validation in command from ProcessingDepartment. Data: {data}")
            self._send_error(project_id, "missing_data_for_validation", {"received_data": data}, username)
            return False

        self.logger.info(f"Received aggregated data from ProcessingDepartment for project {project_id}. Initiating validation.")
        # Pass username as a keyword argument to satisfy Python's keyword-only constraint
        return self._validate(project_id=project_id, aggregated_data=data_for_validation, username=username)

    def _validate(self, project_id: str, aggregated_data: Dict, username: str) -> bool:
        """
        Runs regulatory validation based on the aggregated data received from ProcessingDepartment.
        This method now expects 'aggregated_data' which contains outputs from previous departments.
        """
        self.logger.info(f"Running regulatory validation for project {project_id}")
        if not aggregated_data:
            self._send_error(project_id, "missing_aggregated_data", {}, username)
            return False

        validation = {
            "project_id": project_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "service_type": "regulatory_compliance",
            "compliance_passed": True,
            "compliance_flags": [],
            "notes": [],
            "compliance_summary": {} # New field to hold a summary for ProcessingDepartment
        }

        # Extract relevant information from aggregated_data for validation
        # This includes outputs from Manufacturers, Parts, Equipment, and Troubleshooting
        troubleshooting_output = aggregated_data.get("troubleshooting_output")
        manual_content_combined = aggregated_data.get("initial_mrr_asset_specs", {}).get("manual_content_combined", "")
        manufacturers_output = aggregated_data.get("manufacturers_output", {})
        parts_output = aggregated_data.get("parts_output", {})
        equipment_output = aggregated_data.get("equipment_output", {})

        # --- Safety Compliance Checks based on Aggregated Data ---

        # 1. Validate against Troubleshooting Department's diagnosis document flags
        if troubleshooting_output and troubleshooting_output.get("diagnosis_document"):
            diag_doc = troubleshooting_output["diagnosis_document"]
            for flag in diag_doc.get("flags", []):
                flag_lower = flag.lower()
                if "hose integrity" in flag_lower or "hose damage" in flag_lower:
                    validation["compliance_passed"] = False
                    validation["compliance_flags"].append("Hose integrity risk detected. Mitigation required before certification approval.")
                if "electrical fault" in flag_lower or "wiring issue" in flag_lower:
                    validation["compliance_passed"] = False
                    validation["compliance_flags"].append("Electrical system fault detected. Immediate inspection and mitigation are mandatory.")
                if "pressure anomaly" in flag_lower:
                    validation["compliance_passed"] = False
                    validation["compliance_flags"].append("Pressure system anomaly detected. Verify pressure relief mechanisms and operational limits.")
        else:
            validation["notes"].append("No comprehensive diagnosis document from Troubleshooting Department for specific flag checks.")
            # Depending on strictness, this could be a compliance flag too:
            # validation["compliance_passed"] = False
            # validation["compliance_flags"].append("Missing critical diagnosis document for full regulatory assessment.")

        # 2. Validate against combined manual content for critical safety procedures
        if manual_content_combined:
            manual_lower = manual_content_combined.lower()
            if "high voltage" in manual_lower and "safety lockout tagout" not in manual_lower and "loto" not in manual_lower:
                validation["compliance_passed"] = False
                validation["compliance_flags"].append("Manual mentions high voltage but lacks explicit 'Lockout/Tagout (LOTO)' procedures. Significant safety risk detected.")
            if "confined space entry" in manual_lower and "permit-required" not in manual_lower:
                validation["compliance_passed"] = False
                validation["compliance_flags"].append("Manual describes confined space entry without explicitly stating 'permit-required confined space' protocols. Non-compliance risk.")
        else:
            validation["notes"].append("No combined manual content available for detailed safety procedure verification.")

        # 3. Validate against Manufacturer's specifications (e.g., operating limits)
        if manufacturers_output and manufacturers_output.get("relative_specifications"):
            specs = manufacturers_output["relative_specifications"]
            if specs.get("max_operating_pressure") and specs["max_operating_pressure"] > 1000: # Example threshold
                validation["notes"].append(f"High pressure system detected (Max: {specs['max_operating_pressure']} PSI). Ensure all pressure safety valves are certified.")
            # Add more specific checks based on manufacturer data
        else:
            validation["notes"].append("No manufacturer specifications available for detailed regulatory checks.")

        # 4. Validate against Parts Department's required parts (e.g., certified components)
        if parts_output and parts_output.get("parts_required"):
            for part in parts_output["parts_required"]:
                if "safety valve" in part.get("name", "").lower() and not part.get("certified"):
                    validation["compliance_passed"] = False
                    validation["compliance_flags"].append(f"Uncertified safety valve '{part.get('name', 'N/A')}' listed as required. All safety-critical parts must be certified.")
        else:
            validation["notes"].append("No parts list available for regulatory component verification.")

        # 5. Validate against Equipment Care Planning Department's SOP (e.g., missing critical steps)
        if equipment_output and equipment_output.get("sop_content"):
            sop_lower = equipment_output["sop_content"].lower()
            if "emergency shutdown" not in sop_lower:
                validation["compliance_passed"] = False
                validation["compliance_flags"].append("SOP content does not explicitly detail 'Emergency Shutdown Procedures'. Critical safety omission.")
        else:
            validation["notes"].append("No SOP content available for regulatory procedure verification.")


        # --- Final Compliance Summary ---
        if not validation["compliance_flags"]:
            validation["notes"].append("All regulatory safety checks passed without flags.")
            validation["compliance_summary"]["status"] = "Compliant"
            validation["compliance_summary"]["message"] = "All regulatory checks passed. Standard Operating Procedure (SOP) is recommended."
        else:
            validation["compliance_summary"]["status"] = "Non-Compliant"
            validation["compliance_summary"]["message"] = "Regulatory flags detected. A Troubleshooting Guide is recommended to address identified safety concerns."
            validation["compliance_summary"]["flags_identified"] = validation["compliance_flags"]


        # --- Save Regulatory Output ---
        path = os.path.join(self.outbox, f"regulatory_output_{project_id}.json")
        try:
            with open(path, 'w') as f:
                json.dump(validation, f, indent=4)
            self.logger.info(f"Saved regulatory validation output to {path}")
        except Exception as e:
            self.logger.error(f"Write failed for regulatory output {project_id}: {e}")
            self._send_error(project_id, "file_write_failure", {"path": path, "error": str(e)}, username)
            return False

        # Send an "Accept" report to ProcessingDepartment with the full validation results
        return self._send_accept_report(project_id, validation, username)

    def _send_accept_report(self, project_id: str, compliance_results: Dict, username: str) -> bool:
        """
        Sends an "Accept" report back to the ProcessingDepartment with compliance results.
        """
        self.logger.info(f"Sending 'Accept' report to ProcessingDepartment for project {project_id}.")
        if self.processing:
            try:
                self.processing.receive_report_from_department(
                    self.name,
                    "Accept",
                    {
                        "project_id": project_id,
                        "report_type": "Accept",
                        "report_details": compliance_results,
                        "missing_information": None,
                        "username": username,
                    }
                )
                return True
            except Exception as e:
                self.logger.error(f"Failed to send 'Accept' report to ProcessingDepartment for {project_id}: {e}")
                # Fallback to direct error reporting if report sending fails
                self._send_error(project_id, "report_send_failure", {"report_type": "Accept", "error": str(e)}, username)
                return False
        return False

    def _send_error(self, project_id: str, err_type: str, details: Dict, username: str):
        """
        Sends an error report to the centralized error reception in ProcessingDepartment.
        """
        payload = {
            "department": self.name,
            "project_id": project_id,
            "error_type": err_type,
            "details": details,
            "timestamp": datetime.datetime.now().isoformat()
        }
        if self.processing:
            try:
                self.processing.receive_department_error(self.name, payload)
            except Exception as e:
                self.logger.critical(f"FATAL: Could not send error to ProcessingDepartment for {project_id}: {e}")
        else:
            self.logger.critical(f"ProcessingDepartment not set up. Could not send error for {project_id}. Payload: {payload}")

    def receive_error_feedback(self, sender: str, cmd_type: str, data: Dict, username: str) -> bool:
        """
        Receives error feedback from the ProcessingDepartment and re-attempts validation.
        This method is called when ProcessingDepartment initiates a retry.
        """
        if sender != "ProcessingDepartment" or cmd_type != "error_feedback":
            self.logger.error(f"Unsupported error feedback command or sender for RegulationsDepartment. Sender: {sender}, Cmd Type: {cmd_type}")
            return False

        project_id = data.get("project_id")
        missing_info = data.get("missing_info", "No specific missing information provided.")
        full_data = data.get("full_data") # This would be the updated aggregated data
        username = data.get("username")

        self.logger.warning(f"Received error feedback for project {project_id} from ProcessingDepartment. Missing info: {missing_info}. Re-attempting validation.")

        if not project_id or not full_data:
            self.logger.error(f"Invalid error feedback data for project {project_id}: Missing project_id or full_data.")
            self._send_error(project_id, "invalid_error_feedback_data", {"received_data": data}, username)
            return False

        # Re-attempt the validation process with the potentially updated 'full_data'
        # For this example, we'll re-run the full validation with the provided data.
        # Pass username as a keyword argument to satisfy Python's keyword-only constraint
        return self._validate(project_id=project_id, aggregated_data=full_data, username=username)
