# ~/oracle_archive/oracle_back/oracle_dept/processing.py

import os
import json
from datetime import datetime
import mimetypes # For guessing file types
from collections import defaultdict
import sys
import re
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from logger_factory import setup_logger
from security_manager import IntegrityChecker
from access_control import AccessControlManager
from .data_parser import DataParser

# === Security Protocol ===
integrity_checker = IntegrityChecker()
if not integrity_checker.check_integrity():
    sys.exit("Integrity check failed for processing.py. Shutting down.")
# =========================

class ProcessingDepartment:
    def __init__(self,
                 manufacturers_dept,
                 parts_dept,
                 equipment_dept,
                 troubleshooting_dept,
                 regulations_dept,
                 project_manager_dept,
                 logger_factory,
                 access_control_manager: AccessControlManager):
        self.name = "ProcessingDepartment"
        self.base_dir = os.path.expanduser("~/oracle_archive/oracle_data/processing")
        self.inbox_dir = os.path.join(self.base_dir, "inbox")
        self.outbox_dir = os.path.join(self.base_dir, "outbox")
        self.temp_storage_dir = os.path.join(self.base_dir, "temp_storage")

        os.makedirs(self.inbox_dir, exist_ok=True)
        os.makedirs(self.outbox_dir, exist_ok=True)
        os.makedirs(self.temp_storage_dir, exist_ok=True)

        self.logger = setup_logger(self.name, f"{self.name.lower()}.log")

        # Store direct references to other departments
        self.manufacturers_dept = manufacturers_dept
        self.parts_dept = parts_dept
        self.equipment_dept = equipment_dept
        self.troubleshooting_dept = troubleshooting_dept
        self.regulations_dept = regulations_dept
        self.project_manager_dept = project_manager_dept
        self.access_control = access_control_manager
        self.data_parser = DataParser()

        # Initialize internal dictionary to maintain project states
        self.project_states = defaultdict(lambda: {
            "initial_translated_data": {},
            "department_reports": {
                "ManufacturersDepartment": None,
                "PartsDepartment": None,
                "EquipmentCarePlanningDepartment": None,
                "TroubleshootingDepartment": None
            },
            "error_retries": defaultdict(int),
            "accepted_outputs": {},
            "status": "initialized"
        })
        self.logger.info(f"{self.name} initialized.")
        # Enable fan-out so initial data actually goes to departments
        self.downstream_departments = [
        self.manufacturers_dept,
        self.parts_dept,
        self.equipment_dept,
        self.troubleshooting_dept,
        ]

        # External logger used for department error tracking
        self.external_db_logger = setup_logger(
        f"{self.name}.external", f"{self.name.lower()}_external.log"
        )


    def receive_initial_project_data(self, project_id: str, raw_input_data: dict, username: str) -> bool:
        """
        Receives raw project input data from ProjectManagerDepartment,
        translates it, and distributes it to initial processing departments.
        """

        # [CHG] Keep your ACL but return a clean status if blocked
        if not self.access_control.check_access(username, "initiate_processing"):
            self.logger.warning(
                f"Access denied for user '{username}' to initiate processing for project '{project_id}'."
            )
            self._send_status_update_to_project(
                project_id,
                "access_denied",
                f"User '{username}' not authorized to initiate processing."
            )
            return False

        self.logger.info(
            f"Received initial project data for project_id: {project_id} from user: {username}"
        )

        # [CHG] Defensive normalize and translate
        raw = raw_input_data or {}
        translated = self._translate_raw_data(project_id, raw, username) or {}

        # [CHG] Persist user context so ALL downstream depts can read it
        #      (departments that do ACL/logging expect one of these keys)
        translated["username"] = username                               # [CHG]
        translated["username"] = raw.get("username", username)            # [CHG]

        # [CHG] Store the translated snapshot with user context for later phases
        if project_id not in self.project_states:
            self.project_states[project_id] = {}                        # [CHG]
        self.project_states[project_id]["initial_translated_data"] = translated  # [CHG]

        # [CHG] Fan out to departments and INCLUDE `username` in the envelope
        envelope = {
            "project_id": project_id,
            "full_data": translated,
            "username": username,                                       # [CHG]
        }

        for dept in getattr(self, "downstream_departments", []):
            try:
                dept.receive_command_from_processing(self.name, "initial_data", envelope, username)
            except Exception as e:
                # [CHG] Contained error handling so one dept doesn't break the fan-out
                self.logger.exception(
                    f"Error fanning out initial_data to {getattr(dept, 'name', 'unknown')} "
                    f"for project {project_id}: {e}"
                )

        # [CHG] Optional: status callback indicating successful dispatch
        self._send_status_update_to_project(project_id, "processing_initiated", "Initial data dispatched.")  # [CHG]

        return True


    def _translate_raw_data(self, project_id: str, raw_data: dict, username: str) -> dict:
        """
        Converts various raw input file types into a standardized, comprehensive JSON structure.
        """
        self.logger.info(f"Translating raw data for project_id: {project_id}")
        translated_output = {
            "project_id": project_id,
            "mrr_data": raw_data.get("mrr_data", {}),
            "asset_specs": raw_data.get("asset_specs", {}),
            "notes": raw_data.get("notes", ""),
            "manual_content_combined": "",
            "extracted_files_metadata": [],
            "extracted_json_content": {},
            "extracted_text_content": {}
        }

        file_paths = raw_data.get("file_paths", [])
        if not file_paths:
            self.logger.warning(f"No file paths provided in raw_data for project_id: {project_id}")
            return translated_output

        combined_manual_parts = []

        for f_path in file_paths:
            full_path = os.path.abspath(f_path)
            
            # Use the DataParser to process the file and handle cases where it fails
            parsed_result = self.data_parser.parse_file(full_path)

            if not parsed_result:
                self.logger.warning(f"Failed to parse or file not found: {os.path.basename(full_path)}. Skipping this file.")
                continue

            file_type, content = parsed_result
            
            file_metadata = {
                "original_path": full_path,
                "filename": os.path.basename(full_path),
                "size": os.path.getsize(full_path),
                "type": file_type
            }
            translated_output["extracted_files_metadata"].append(file_metadata)

            # Now, integrate the parsed content into your dictionary structure
            if file_type == "application/json":
                translated_output["extracted_json_content"][file_metadata["filename"]] = content
                self.logger.info(f"Extracted JSON from {file_metadata['filename']}")
                if isinstance(content, dict) and "manual_text" in content:
                    combined_manual_parts.append(content["manual_text"])

            elif file_type == "text/plain":
                translated_output["extracted_text_content"][file_metadata["filename"]] = content
                combined_manual_parts.append(content)
                self.logger.info(f"Extracted text from {file_metadata['filename']}")
            
            elif file_type and (file_type.startswith("application/pdf") or file_type.startswith("image/")):
                # Placeholder for PDF and Image content extraction
                self.logger.warning(f"Full content extraction for {file_metadata['type']} files like {file_metadata['filename']} is a placeholder.")
                self.logger.warning("Integrate specialized libraries (e.g., PyPDF2, pdfminer.six for PDFs; Pillow, Tesseract for images) here for full content.")
                simulated_content = f"Content of {file_metadata['filename']} (type: {file_metadata['type']}) would be extracted here."
            else:
                self.logger.info(f"Skipping content extraction for unsupported file type: {file_metadata['type']} ({file_metadata['filename']})")

        translated_output["manual_content_combined"] = "\n\n".join(combined_manual_parts)

        self.logger.info(f"Finished translating raw data for project_id: {project_id}. Result size: {sys.getsizeof(json.dumps(translated_output))} bytes.")
        return translated_output

    def receive_report_from_department(self, sender: str, cmd_type: str, data: dict, username: str):
        """
        Central point for receiving all "Accept" and "Error" reports from downstream departments.
        """
        # This security check remains the same
        if not self.access_control.check_access(username, "receive_department_report"):
            self.logger.warning(f"Access denied for user '{username}' to receive department report from '{sender}'.")
            return

        project_id = data.get("project_id")
        report_type = data.get("report_type") # "Accept" or "Error"
        report_details = data.get("report_details")
        missing_information = data.get("missing_information")

        if not project_id or not report_type:
            self.logger.error(f"Invalid report received from {sender}: Missing project_id or report_type. Data: {data}")
            return

        self.logger.info(f"Received {report_type} report from {sender} for project_id: {project_id}")
        self.project_states[project_id]["department_reports"][sender] = {"type": report_type, "details": report_details, "missing_info": missing_information}

        if report_type == "Error":
            self.external_db_logger.error(f"Error from {sender} for project {project_id}: {missing_information}. Details: {report_details}")
            self.project_states[project_id]["error_retries"][sender] += 1
            current_retries = self.project_states[project_id]["error_retries"][sender]

            if current_retries <= 3:
                self.logger.warning(f"Retrying {sender} for project {project_id}. Retry count: {current_retries}")
                # Send error_feedback command back to originating department
                try:
                    target_dept = getattr(self, sender.lower().replace("department", "_dept"))
                    target_dept.receive_error_feedback(
                        self.name,
                        "error_feedback",
                        {
                            "project_id": project_id,
                            "missing_info": missing_information,
                            "full_data": self.project_states[project_id]["initial_translated_data"]
                        }
                    )
                except AttributeError:
                    self.logger.error(f"Cannot find department instance for {sender} to send error feedback.")
                except Exception as e:
                    self.logger.error(f"Error sending error feedback to {sender} for {project_id}: {e}")
            else:
                self.logger.error(f"Max retries exceeded for {sender} on project {project_id}.")
                self.project_states[project_id]["status"] = f"failed_on_{sender}"
                self._send_status_update_to_project(project_id, "error", f"Department {sender} failed after max retries.")

        elif report_type == "Accept":
            self.project_states[project_id]["accepted_outputs"][sender] = report_details
            self._check_for_completion(project_id, username)

    def _check_for_completion(self, project_id: str, username: str):
        """
        Checks if all expected departments have submitted a successful report.
        After the 4 core departments Accept, dispatch aggregated data to RegulationsDepartment.
        Once RegulationsDepartment Accepts, hand off the final report.
        """
        state = self.project_states[project_id]
        reports = state["department_reports"]
        accepted = state["accepted_outputs"]

        # Core deps that must finish first
        core_required = [
            "ManufacturersDepartment",
            "PartsDepartment",
            "EquipmentCarePlanningDepartment",
            "TroubleshootingDepartment",
        ]

        core_received = all(reports[d] is not None for d in core_required)
        core_accepted = core_received and all(reports[d]["type"] == "Accept" for d in core_required)

        # 1) If core accepted and Regulatory not yet dispatched, build aggregated JSON and send it
        if core_accepted and not state.get("regulatory_dispatched"):
            self.logger.info(f"Core departments accepted for project_id: {project_id}. Dispatching to RegulationsDepartment.")

            # Assemble aggregated_data in the schema RegulationsDepartment expects
            initial = state.get("initial_translated_data", {})  # from _translate_raw_data
            aggregated_data = {
                "troubleshooting_output": accepted.get("TroubleshootingDepartment", {}),
                "manufacturers_output": accepted.get("ManufacturersDepartment", {}),
                "parts_output": accepted.get("PartsDepartment", {}),
                "equipment_output": accepted.get("EquipmentCarePlanningDepartment", {}),
                # Map Processing’s manual content into the nested shape Regulatory checks
                "initial_mrr_asset_specs": {
                    "manual_content_combined": initial.get("manual_content_combined", "")
                },
            }

            envelope = {
                "project_id": project_id,
                "data_for_validation": aggregated_data,
                "username": username,
            }

            try:
                self.regulations_dept.receive_command_from_processing(
                    self.name, "aggregated_data", envelope, username
                )
                state["regulatory_dispatched"] = True
                self.logger.info(f"Dispatched aggregated_data to RegulationsDepartment for {project_id}.")
            except Exception as e:
                self.logger.error(f"Failed to dispatch to RegulationsDepartment for {project_id}: {e}")
            return  # Wait for Regulatory’s callback

        # 2) If Regulatory has accepted, finalize
        if state.get("regulatory_dispatched") and reports.get("RegulationsDepartment") and reports["RegulationsDepartment"]["type"] == "Accept":
            self.logger.info(f"Regulatory report accepted for project_id: {project_id}. Compiling final report.")
            final_report_data = {
                "project_id": project_id,
                "created_at": datetime.now().isoformat(),
                "reports": state["accepted_outputs"],  # includes RegulationsDepartment now
            }
            self.handoff_final_to_project(project_id, final_report_data, username)
            return

        # Otherwise keep waiting
        self.logger.info(f"Waiting for more reports for project_id: {project_id}.")
        self.logger.debug(f"Current reports: {self.project_states[project_id]['department_reports']}")

    def handoff_final_to_project(self, project_id: str, final_report: dict, username: str):
        """
        Hands off the final, compiled report to the ProjectManagerDepartment for final storage and archiving.
        """
        # Security check now sends a 'access_denied' status instead of an error
        if not self.access_control.check_access(username, "handoff_final_report"):
            self.logger.warning(f"Access denied for user '{username}' to handoff final report for project '{project_id}'.")
            self._send_status_update_to_project(project_id, "access_denied", f"User '{username}' not authorized to handoff final report.")
            return

        self.logger.info(f"Handoff final report to ProjectManagerDepartment for project {project_id}.")
        try:
            self.project_manager_dept.receive_processing_output(self.name, "final_report", final_report)
            self.project_states[project_id]["status"] = "completed"
            self.logger.info(f"Project {project_id} successfully completed and handed off.")
            # Clear state after completion
            if project_id in self.project_states:
                del self.project_states[project_id]
                self.logger.info(f"Cleared state for completed project {project_id}.")
        except Exception as e:
            self.logger.error(f"Failed to handoff final report to ProjectManagerDepartment for project {project_id}: {e}")
            self._send_status_update_to_project(project_id, "final_handoff_failure", str(e))

    def receive_command_from_project_for_re_evaluation(self, sender: str, cmd_type: str, payload: dict, username: str):
        """
        This method is called by ProjectManagerDepartment to re-evaluate a project.
        """
        # Security check now sends a 'access_denied' status instead of an error
        if not self.access_control.check_access(username, "re_evaluate_project"):
            self.logger.warning(f"Access denied for user '{username}' to re-evaluate project.")
            self._send_status_update_to_project(payload.get("project_id"), "access_denied", f"User '{username}' not authorized to re-evaluate projects.")
            return

        project_id = payload.get("project_id")
        new_mrr_data = payload.get("new_mrr_data")
        self.logger.info(f"Received re-evaluation command for project {project_id}. Updating MRR data.")

        if project_id not in self.project_states:
            self.logger.error(f"Project state for {project_id} not found. Cannot re-evaluate.")
            self._send_status_update_to_project(project_id, "re_evaluation_failure", "Project state not found.")
            return

        # Update the MRR data in the existing state
        self.project_states[project_id]["initial_translated_data"]["mrr_data"] = new_mrr_data
        self.project_states[project_id]["status"] = "re_evaluating"

        # Re-distribute to all departments for re-evaluation
        departments_to_distribute = [
            self.manufacturers_dept,
            self.parts_dept,
            self.equipment_dept,
            self.troubleshooting_dept
        ]

        # Reset reports and errors for a fresh run
        self.project_states[project_id]["department_reports"] = defaultdict(lambda: None)
        self.project_states[project_id]["error_retries"] = defaultdict(int)
        self.project_states[project_id]["accepted_outputs"] = {}

        for dept in departments_to_distribute:
            try:
                dept.receive_command_from_processing(
                    self.name,
                    "re_evaluation_data",
                    {
                        "project_id": project_id,
                        "full_data": self.project_states[project_id]["initial_translated_data"],
                        "username": username
                    },
                    username
                )
                
                self.logger.info(f"Re-distributed updated data to {dept.name} for project_id: {project_id}.")
            except Exception as e:
                self.logger.error(f"Failed to re-distribute updated data to {dept.name} for {project_id}: {e}")
                # Potentially send an error back to project manager here if a critical re-distribution fails

    def _send_status_update_to_project(self, project_id: str, status_type: str, details: str, username: str | None = None):
        """
        Send status updates to ProjectManagerDepartment.

        SECURITY: If no valid username is available (arg or state), terminate the process.
        """
        # Resolve username if omitted
        if not username:
            try:
                username = (
                    self.project_states.get(project_id, {})
                    .get("initial_translated_data", {})
                    .get("username")
                )
            except Exception:
                username = None

        if not username:
            # Hard failure per security policy
            self.logger.critical(
                f"SECURITY VIOLATION: Missing username for status '{status_type}' "
                f"on project '{project_id}'. Initiating shutdown."
            )
            import sys
            sys.exit("SECURITY VIOLATION: Username required for status updates.")

        self.logger.info(
            f"Sending status update '{status_type}' to ProjectManagerDepartment for project {project_id}: {details}"
        )
        try:
            self.project_manager_dept.receive_processing_status_update(
                self.name,
                status_type,
                {"project_id": project_id, "status_type": status_type, "details": details},
                username,
            )
        except Exception as e:
            self.logger.critical(
                f"FATAL: Could not send status update to ProjectManagerDepartment for project {project_id}: {e}"
            )

    def receive_department_error(self, sender: str, payload: dict, username: str):
        """
        This will be the centralized error reception point for all departments' send_error calls.
        """
        project_id = payload.get("project_id", "N/A")
        error_message = payload.get("message", "No message provided.")
        self.logger.error(f"Centralized Error from {sender} for project {project_id}: {error_message}. Full payload: {payload}", username)
        self.logger.logger_factory.error(f"Centralized Error - Sender: {sender}, Project ID: {project_id}, Payload: {payload}", username)
        # At this point, we could decide to halt the project or take other corrective actions.
