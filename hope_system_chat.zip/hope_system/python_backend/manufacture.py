# Refactored Oracle App Structure
# Path: mr-jack@mr-jack:~/oracle_archive/oracle_back/oracle_dept/

# === departments/project.py ===
# Project Manager Department module
# Handles MRR collection and initial data routing

# === departments/manufacture.py ===
# Manufacturers Department module
# Merges MRR + specs + manual data to form Project Understanding Document

import os
import json
import datetime
from typing import Dict, List, Optional, Any
import re
from datetime import datetime

import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app_config import AppConfig
from logger_factory import setup_logger
from security_manager import SecurityManager
from access_control import AccessControlManager
from oracle_dept.project import ProjectManagerDepartment
from oracle_dept.processing import ProcessingDepartment # Import ProcessingDepartment

class ManufacturersDepartment:
    """
    Processes project data, specifically focusing on manuals and asset specifications,
    to create a comprehensive understanding of the project. It now communicates directly
    with the ProcessingDepartment.
    """

    def __init__(
        self,
        processing,
        security_manager: SecurityManager,
        access_control_manager: AccessControlManager
        ):
        
        self.name = "ManufacturersDepartment"
        self.base = os.path.join(AppConfig.BASE_DATA_DIR, 'manufacturers_data')
        self.inbox = os.path.join(self.base, 'manufacturers_inbox')
        self.outbox = os.path.join(self.base, 'manufacturers_outbox')
        self.manual_dir = os.path.join(self.base, 'manufacturers_manual_temp')
        os.makedirs(self.inbox, exist_ok=True)
        os.makedirs(self.outbox, exist_ok=True)
        os.makedirs(self.manual_dir, exist_ok=True)
        self.logger = setup_logger(self.name, 'manufacturers_department.log')
        self.processing = processing
        self.security = security_manager
        self.access_control = access_control_manager
        self.logger.info(f"{self.name} initialized.")


    def receive_command_from_processing(self, sender: str, cmd_type: str, data: dict, username: str):
        """
        This method will now ONLY expect commands from the ProcessingDepartment.
        It receives the "full copy" of the translated data.

        Args:
            sender (str): The name of the department sending the command (should be ProcessingDepartment).
            cmd_type (str): The type of command (e.g., "process_initial_data", "re_process_data").
            data (dict): Contains project_id and full_data (the comprehensive translated data).
        """
        project_id = data.get("project_id")
        full_data = data.get("full_data")
        username = full_data.get("username")
        
        if not username:
            self.logger.error(f"Command from {sender} for project {project_id} missing username.")
            self._send_error(project_id, username, "Missing user information", "No username found in data.")
            return

        if not self.access_control.check_access(username, "write"):
            error_message = f"User '{username}' lacks 'write' permissions for ManufacturersDepartment."
            self.logger.warning(error_message)
            self._send_error(project_id, username, "Permission Denied", error_message)
            return

        if not project_id or not full_data:
            self.logger.error(f"Received incomplete command from {sender}. Missing project_id or full_data.")
            self._send_error(project_id, username, "Incomplete data received", "Missing project_id or full_data in command.")
            return

        self.logger.info(f"Received command '{cmd_type}' from {sender} for project {project_id}.")

        try:
            # Extract the specific mrr_data, asset_specs, and manual_content_combined
            # from this comprehensive full_data dictionary.
            mrr_data = full_data.get("mrr_data", {})
            asset_specs = full_data.get("asset_specs", {})
            manual_content_combined = full_data.get("manual_content_combined", "")

            # Simulate processing manuals and creating understanding data
            processed_understanding_data = self._process_manuals(
                project_id,
                mrr_data,
                asset_specs,
                manual_content_combined,
                username
            )

            if processed_understanding_data:
                self.logger.info(f"Successfully created processed data for project {project_id}.")
                self._handoff(project_id, processed_understanding_data, username)
            else:
                self.logger.error(f"Failed to create processed data for project {project_id}.")
                self._send_error(project_id, username, "Processed data creation failed", "Manual processing did not yield data.")

        except Exception as e:
            self.logger.error(f"Error processing data for project {project_id}: {e}")
            self._send_error(project_id, username, "Processing error", str(e))

    def _process_manuals(self, project_id: str, mrr_data: dict, asset_specs: dict, manual_content_combined: str, username: str):
        """
        Extract structured data from already-parsed JSON-like inputs (mrr_data, asset_specs)
        and produce a new JSON file containing specifications, capacities, and bolt patterns.
        Falls back to searching manual_content_combined text for any missed patterns.
        """

        self.logger.info(f"Manufacturers: extracting specs/capacities/bolt-patterns for project: {project_id}")

        # -------- helpers --------
        def _as_str(x) -> str:
            if x is None:
                return ""
            if isinstance(x, (int, float)):
                return str(x)
            if isinstance(x, (dict, list, tuple, set)):
                try:
                    return json.dumps(x, ensure_ascii=False)
                except Exception:
                    return str(x)
            return str(x)

        def _walk_json(obj, path=""):
            """Yield (path, key, value_str) for every leaf-like value."""
            if isinstance(obj, dict):
                for k, v in obj.items():
                    p = f"{path}.{k}" if path else k
                    yield from _walk_json(v, p)
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    p = f"{path}[{i}]"
                    yield from _walk_json(v, p)
            else:
                yield (path, path.split(".")[-1] if path else "", _as_str(obj))

        def _unique(seq):
            out, seen = [], set()
            for x in seq:
                if x not in seen:
                    out.append(x); seen.add(x)
            return out

        # -------- collect candidate strings from JSON --------
        sources = {
            "mrr": mrr_data or {},
            "asset_specs": asset_specs or {},
        }

        # Flatten all strings from JSON inputs
        flat_items = list(_walk_json(sources))

        # Also search the manual text as a fallback
        manual_text = manual_content_combined or ""
        if manual_text.strip():
            flat_items.append(("manual", "manual", manual_text))

        # -------- extraction rules --------
        # Bolt patterns (PCD/BCD/lug)
        bolt_regexes = [
            r"\b(\d)\s*[xX×]\s*(\d{3}\.?\d*)\s*mm\b",              # 5x114.3 mm
            r"\b(\d)\s*[xX×]\s*(\d(?:\.\d+)?)\s*(?:in|inch|\")\b",  # 5x4.5 in
            r"\b(?:PCD|BCD|bolt\s*circle)\s*[:\-]?\s*(\d{3}\.?\d*)\s*mm\b",
            r"\b(\d)\s*-\s*lug\b",                                  # 6-lug
        ]

        # Capacities (volume/weight/pressure/flow/power/load/etc.)
        capacity_regexes = [
            r"\b\d{1,4}(?:[.,]\d{1,3})?\s*(?:L|liters?|gal|gallons?)\b",
            r"\b\d{1,5}(?:[.,]\d{1,3})?\s*(?:kg|kilograms?|lb|pounds?|tons?)\b",
            r"\b\d{1,6}(?:[.,]\d{1,3})?\s*(?:A|Amps?|W|kW|MW|BTU\/?h?)\b",
            r"\b\d{1,6}(?:[.,]\d{1,3})?\s*(?:CFM|SCFM|PSI|bar)\b",
            r"\b(?:capacity|capacities|cap\.)[:\-]?\s*[^\n\r]{1,120}\b",
        ]

        # Specifications: collect kv-like pairs and spec-ish keys
        kv_line = re.compile(r"^\s*([A-Za-z][A-Za-z0-9 \-\/%°\(\)\.]+?)\s*[:\-–]\s*([^\s].{0,200})$")
        spec_key_hints = re.compile(r"(spec|dimension|size|voltage|power|speed|rpm|weight|material|model|serial|load|rating)", re.I)

        bolt_patterns: list[str] = []
        capacities: list[str] = []
        specs_raw: dict[str, str] = {}

        for path, key, value in flat_items:
            s = value

            # bolt patterns
            for pat in bolt_regexes:
                for m in re.finditer(pat, s, flags=re.IGNORECASE):
                    bolt_patterns.append(m.group(0).strip())

            # capacities
            for pat in capacity_regexes:
                for m in re.finditer(pat, s, flags=re.IGNORECASE | re.MULTILINE):
                    capacities.append(m.group(0).strip())

            # specs (kv style or spec-ish keys)
            # 1) try line-based kv on multi-line strings
            if "\n" in s:
                for line in s.splitlines():
                    m = kv_line.search(line)
                    if m:
                        k = m.group(1).strip().lower()
                        v = m.group(2).strip()
                        specs_raw.setdefault(k, v)
            # 2) pick up JSON keys that "look like" specs
            if key and spec_key_hints.search(key):
                # prefer shorter string values
                val = s.strip()
                if len(val) <= 200 and val:
                    specs_raw.setdefault(key.lower(), val)

        bolt_patterns = _unique([bp for bp in (x.replace("×", "x") for x in bolt_patterns)])
        capacities = _unique(capacities)

        # Canonicalize common keys
        canonical = {}
        aliases = {
            "voltage": ["voltage", "input voltage", "rated voltage"],
            "power":   ["power", "rated power", "motor power"],
            "speed":   ["speed", "rpm", "rated speed"],
            "weight":  ["weight", "net weight"],
            "dimensions": ["dimensions", "overall dimensions", "size", "dimension"],
            "model_number": ["model", "model number"],
            "serial_number": ["serial", "serial number"],
        }
        for std_key, keys in aliases.items():
            for k in keys:
                if k in specs_raw:
                    canonical[std_key] = specs_raw[k]
                    break

        # Build output JSON
        extracted = {
            "project_id": project_id,
            "department": "Manufacturers",
            "username": username,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "source_refs": {
                "has_mrr": bool(mrr_data),
                "has_asset_specs": bool(asset_specs),
                "has_manual_text": bool(manual_text.strip()),
            },
            "extracted": {
                "bolt_patterns": bolt_patterns,
                "capacities": capacities,
                "specs": {
                    "canonical": canonical,
                    "raw": specs_raw,
                },
            },
            "notes": {
                "parsing_engine": "json-scan+regex-v1",
                "confidence": "heuristic",
            },
        }

        # Persist a new JSON file for downstream modules
        try:
            os.makedirs(self.outbox, exist_ok=True)
            out_path = os.path.join(self.outbox, f"{project_id}_manufacturers_extracted.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(extracted, f, indent=2, ensure_ascii=False)
            self.logger.info(f"Manufacturers: wrote extracted JSON -> {out_path}")
        except Exception as e:
            self.logger.error(f"Manufacturers: failed to write extracted JSON: {e}")

        return extracted

    def _save_understanding(self, project_id: str, data: Dict, username: str) -> Optional[str]:
        path = os.path.join(self.outbox, f"manufacturers_output_{project_id}.json")
        try:
            with open(path, 'w') as f:
                json.dump(data, f, indent=4)
            return path
        except Exception as e:
            self.logger.error(f"Save failed: {e}")
            return None

    def _handoff(self, project_id: str, processed_understanding_data: dict, username: str) -> None:
        """
        Send an 'Accept' department report back to ProcessingDepartment.
        """
        self.logger.info(f"Handoff 'Accept' report to ProcessingDepartment for project: {project_id}")

        # NEW: Build the payload with report_type INSIDE data (where the receiver expects it).
        payload = {
            "project_id": project_id,
            "report_type": "Accept",                    # NEW
            "report_details": processed_understanding_data,
            "missing_information": []
        }

        try:
            self.processing.receive_report_from_department(
                sender=self.name,                       # CHANGED: was sender_name=...
                cmd_type="department_report",           # CHANGED: receiver expects a command type here
                data=payload,                           # CHANGED: pass the full payload via 'data'
                username=username
            )
            self.logger.info("Handoff to ProcessingDepartment completed successfully.")
        except Exception as e:
            self.logger.error(f"Failed to handoff to ProcessingDepartment: {e}")
            raise

    def _send_error(
        self,
        project_id: str,
        username: str,
        error_type: str,
        message: str,
        missing_information: list | None = None,
    ) -> None:
        """
        Send a centralized error report to ProcessingDepartment.
        """
        self.logger.error(
            f"[{self.name}] Error for project {project_id} (user={username}): {error_type} - {message}"
        )

        payload = {
            "project_id": project_id,
            "message": f"{error_type}: {message}",
            "missing_information": missing_information or [],
            "report_details": {},  # keep shape consistent; add any context you want here
        }

        try:
            # Use the dedicated centralized error receiver
            self.processing.receive_department_error(sender=self.name, payload=payload)
            self.logger.info("Sent centralized error report to ProcessingDepartment.")
        except Exception as e:
            self.logger.critical(
                f"FATAL: failed to send error report for project {project_id}: {e}"
            )
            raise


    def receive_error_feedback(self, sender: str, cmd_type: str, data: dict, username: str):
        """
        This method will be called by ProcessingDepartment if an "Error" report
        was previously sent and a retry is being initiated.

        Args:
            sender (str): The name of the sender (should be ProcessingDepartment).
            cmd_type (str): The type of command (e.g., "retry_processing").
            data (dict): Contains project_id, missing_info, and full_data.
        """
        project_id = data.get("project_id")
        missing_info = data.get("missing_info", [])
        full_data = data.get("full_data")
        username = data.get("username")

        if not project_id or not full_data:
            self.logger.error(f"Received incomplete error feedback from {sender}. Missing project_id or full_data.")
            return

        self.logger.info(f"Received error feedback for project {project_id} from {sender}. "
                         f"Missing info: {missing_info}. Re-attempting processing.")

        try:
            # Extract and use the specific mrr_data, asset_specs, and manual_content_combined
            mrr_data = full_data.get("mrr_data", {})
            asset_specs = full_data.get("asset_specs", {})
            manual_content_combined = full_data.get("manual_content_combined", "")

            processed_understanding_data = self._process_manuals(
                project_id,
                mrr_data,
                asset_specs,
                manual_content_combined,
                username
            )

            if processed_understanding_data:
                self.logger.info(f"Successfully re-processed and created processed data for project {project_id} after feedback.")
                self._handoff(project_id, processed_understanding_data, username)
            else:
                self.logger.error(f"Failed to re-process processed data for project {project_id} after feedback.")
                self._send_error(project_id, username, "Re-processing failed", "Manual re-processing did not yield data.", missing_info)

        except Exception as e:
            self.logger.error(f"Error during re-processing for project {project_id} after feedback: {e}")
            self._send_error(project_id, username, "Re-processing error", str(e), missing_info)
