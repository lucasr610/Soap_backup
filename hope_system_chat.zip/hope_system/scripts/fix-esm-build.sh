#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "[1/4] Cleaning dist"
rm -rf dist

echo "[2/4] Type-check & build"
npm run build

echo "[3/4] Show emitted entry and imports (grep)"
grep -E "from './routes|from \"./routes" dist/server.js || true

echo "[4/4] Start server"
node dist/server.js
