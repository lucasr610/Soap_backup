#!/usr/bin/env bash
set -Eeuo pipefail

QDRANT_URL="${QDRANT_URL:-${VECTOR_STORE_URL:-http://localhost:6333}}"

echo "[wait-qdrant] Waiting for $QDRANT_URL ..."
for i in {1..120}; do
  if [[ -n "${QDRANT_API_KEY:-}" ]]; then
    if curl -fsS -H "api-key: $QDRANT_API_KEY" "$QDRANT_URL/collections" >/dev/null; then
      echo "[wait-qdrant] Ready"
      exit 0
    fi
  else
    if curl -fsS "$QDRANT_URL/collections" >/dev/null; then
      echo "[wait-qdrant] Ready (no auth)"
      exit 0
    fi
  fi
  sleep 1
done

echo "[wait-qdrant] Timed out waiting for $QDRANT_URL" >&2
exit 1
