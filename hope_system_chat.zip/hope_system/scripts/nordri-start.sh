#!/usr/bin/env bash
set -Eeuo pipefail

# ---------- config ----------
FRONT_START="${PORT_START_FRONTEND:-3000}"
FRONT_TRIES=11   # 3000..3010
BACK_START="${PORT_START_BACKEND:-5000}"
BACK_TRIES=10    # 5000..5009
FRONT_DIR="${FRONT_DIR:-frontend}"
BACK_ENTRY="${BACK_ENTRY:-src/server.ts}"
NODE_CMD="${NODE_CMD:-bash scripts/dev-backend.sh}"

DO_BOOTSTRAP=0
HARD_KILL=0
OPEN_BROWSER=1

# ---------- helpers ----------
have() { command -v "$1" >/dev/null 2>&1; }
log()  { printf "%s %s\n" "[$(date +%H:%M:%S)]" "$*"; }
die()  { echo "ERROR: $*" >&2; exit 1; }

port_in_use() {
  local p="$1"
  if have ss;     then ss -lnt "( sport = :$p )" | grep -q ":$p"; return $?; fi
  if have lsof;   then lsof -PiTCP -sTCP:LISTEN -n | awk '{print $9}' | grep -q ":$p$"; return $?; fi
  if have netstat;then netstat -tln | awk '{print $4}' | grep -q ":$p$"; return $?; fi
  return 1
}
kill_port() {
  local p="$1"
  if have fuser; then fuser -k "${p}/tcp" || true; return; fi
  if have lsof;  then lsof -ti tcp:"$p" | xargs -r kill -9 || true; return; fi
}
find_free_port() {
  local start="$1" tries="$2"
  for ((i=0;i<tries;i++)); do
    local p=$((start+i))
    if ! port_in_use "$p"; then echo "$p"; return 0; fi
  done
  return 1
}
wait_url() {
  local url="$1" tries="${2:-40}"
  for ((i=1;i<=tries;i++)); do
    if curl -fsS "$url" >/dev/null 2>&1; then return 0; fi
    sleep 0.25
  done
  return 1
}

# ---------- args ----------
while (( "$#" )); do
  case "$1" in
    --kill)        HARD_KILL=1 ;;
    --no-browser)  OPEN_BROWSER=0 ;;
    --bootstrap)   DO_BOOTSTRAP=1 ;;
    --front-start=*) FRONT_START="${1#*=}" ;;
    --back-start=*)  BACK_START="${1#*=}" ;;
    *) die "Unknown arg: $1" ;;
  esac
  shift
done

# ---------- prereqs ----------
have node     || die "node not found"
have python3  || die "python3 not found"
have curl     || die "curl not found"
[ -f "$BACK_ENTRY" ] || die "Backend entry not found: $BACK_ENTRY"
[ -d "$FRONT_DIR" ]  || die "Frontend dir not found: $FRONT_DIR"

# ---------- bootstrap (deps/install) ----------
bootstrap() {
  if [ ! -d node_modules ] || [ ! -f node_modules/.install-ok ] || [ package.json -nt node_modules/.install-ok ]; then
    log "Installing npm dependencies…"
    npm install --no-audit --fund=false
    date +%s > node_modules/.install-ok
  else
    log "npm dependencies look up-to-date."
  fi

  if [ -f requirements.txt ]; then
    if [ ! -d .venv ]; then
      log "Creating Python venv (.venv)…"
      python3 -m venv .venv
    fi
    .venv/bin/pip install -r requirements.txt
    export PYTHON_BIN=".venv/bin/python3"
  else
    export PYTHON_BIN="$(command -v python3)"
  fi

  if [ ! -f tsconfig.json ]; then
    log "Generating minimal tsconfig.json"
    cat > tsconfig.json <<'JSON'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "resolveJsonModule": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "strict": false,
    "outDir": "dist"
  },
  "include": ["src/**/*"]
}
JSON
  fi
}

if (( DO_BOOTSTRAP )); then
  bootstrap
else
  if [ -f .venv/bin/python3 ]; then export PYTHON_BIN=".venv/bin/python3"; else export PYTHON_BIN="$(command -v python3)"; fi
fi

# ---------- free ports (optional) ----------
if (( HARD_KILL )); then
  log "Freeing ports ${FRONT_START}..$((FRONT_START+FRONT_TRIES-1)) and ${BACK_START}..$((BACK_START+BACK_TRIES-1))"
  for p in $(seq "$FRONT_START" $((FRONT_START+FRONT_TRIES-1))); do kill_port "$p"; done
  for p in $(seq "$BACK_START"  $((BACK_START+BACK_TRIES-1)));  do kill_port "$p"; done
fi

# ---------- choose ports ----------
FRONT_PORT="$(find_free_port "$FRONT_START" "$FRONT_TRIES")" || die "No free frontend port near $FRONT_START"
BACK_PORT="$(find_free_port "$BACK_START"  "$BACK_TRIES")"  || die "No free backend port near $BACK_START"
log "Ports selected → Frontend:${FRONT_PORT}  Backend:${BACK_PORT}"

# ---------- start services ----------
mkdir -p .nordri
BACK_LOG=".nordri/backend.log"
FRONT_LOG=".nordri/frontend.log"
: > "$BACK_LOG"; : > "$FRONT_LOG"

log "Starting backend: ${NODE_CMD} ${BACK_ENTRY} (PORT=${BACK_PORT})"
( PORT="${BACK_PORT}" NODE_ENV=development ${NODE_CMD} "${BACK_ENTRY}" >> "$BACK_LOG" 2>&1 ) &
PID_BACK=$!

log "Starting frontend: ${PYTHON_BIN} -m http.server -d ${FRONT_DIR} ${FRONT_PORT}"
( "${PYTHON_BIN}" -m http.server -d "${FRONT_DIR}" "${FRONT_PORT}" >> "$FRONT_LOG" 2>&1 ) &
PID_FRONT=$!

# ---------- traps ----------
cleanup() {
  log "Stopping (PIDs: front ${PID_FRONT}, back ${PID_BACK})"
  kill -TERM "${PID_FRONT}" 2>/dev/null || true
  kill -TERM "${PID_BACK}"  2>/dev/null || true
  sleep 0.6
  kill -KILL "${PID_FRONT}" 2>/dev/null || true
  kill -KILL "${PID_BACK}"  2>/dev/null || true
  log "Done."
}
trap cleanup INT TERM

# ---------- readiness ----------
BACK_HEALTH="http://localhost:${BACK_PORT}/health"
FRONT_ROOT="http://localhost:${FRONT_PORT}/"

log "Waiting for backend ${BACK_HEALTH}"
if wait_url "${BACK_HEALTH}"; then
  log "Backend ready: ${BACK_HEALTH}"
else
  log "Backend not responding yet; see ${BACK_LOG}"
fi

log "Checking frontend ${FRONT_ROOT}"
if curl -fsS "${FRONT_ROOT}" >/dev/null 2>&1; then
  log "Frontend ready: ${FRONT_ROOT}"
else
  log "Frontend not responding yet; see ${FRONT_LOG}"
fi

# ---------- summary ----------
echo
echo "────────────────────────────────────────────────────────"
echo "  ✅ Nordri up"
echo "  Frontend : ${FRONT_ROOT}"
echo "  Backend  : http://localhost:${BACK_PORT}    (/health, /api/version)"
echo "  Logs     : ${FRONT_LOG} , ${BACK_LOG}"
echo "  Stop     : Press Ctrl+C"
echo "────────────────────────────────────────────────────────"
echo

# ---------- open browser ----------
if (( OPEN_BROWSER )) && have xdg-open; then
  xdg-open "${FRONT_ROOT}" >/dev/null 2>&1 || true
fi

wait
