import fs from 'node:fs';
import path from 'node:path';

const SRC = path.resolve('src');
const exts = new Set(['.js', '.mjs', '.cjs', '.json']);

function needsJs(spec) {
  if (!spec.startsWith('./') && !spec.startsWith('../')) return false; // only touch relative
  const ext = path.extname(spec);
  return !ext || !exts.has(ext);
}

function addJs(spec) {
  if (spec === '../agents') return '../agents/index.js'; // example special-case if you import a folder
  return needsJs(spec) ? `${spec}.js` : spec;
}

function transform(code) {
  // import/export ... from '...'
  code = code.replace(
    /(import|export)\s+[^'"]*?from\s+['"]([^'"]+)['"]/g,
    (m, kw, spec) => m.replace(spec, addJs(spec))
  );
  // bare side-effect: import '...'
  code = code.replace(
    /(^|\n)\s*import\s+['"]([^'"]+)['"]/g,
    (m, pre, spec) => m.replace(spec, addJs(spec))
  );
  // dynamic import('...')
  code = code.replace(
    /import\(\s*['"]([^'"]+)['"]\s*\)/g,
    (m, spec) => m.replace(spec, addJs(spec))
  );
  return code;
}

function* walk(dir) {
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) yield* walk(p);
    else if (d.isFile() && (p.endsWith('.ts') || p.endsWith('.tsx'))) yield p;
  }
}

let changed = 0;
for (const file of walk(SRC)) {
  const before = fs.readFileSync(file, 'utf8');
  const after = transform(before);
  if (after !== before) {
    fs.writeFileSync(file, after, 'utf8');
    changed++;
  }
}
console.log(`Updated ${changed} files.`);
