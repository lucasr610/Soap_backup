#!/usr/bin/env bash
set -Eeuo pipefail

# Load secrets from ~/.config/nordri/secure.env if present
ENV_FILE="${NORDRI_ENV_FILE:-$HOME/.config/nordri/secure.env}"
if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  . "$ENV_FILE"
  set +a
fi

exec "$@"
