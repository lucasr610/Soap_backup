#!/usr/bin/env bash
set -euo pipefail

cd /home/reynolds-lucas/nordri-platform

# Start everything in background via your one-command starter
nohup npm start > .nordri/desktop-launch.log 2>&1 &

# Find the first responding frontend (3000..3010)
detect_frontend() {
  for p in $(seq 3000 3010); do
    if curl -fsS "http://localhost:${p}/" >/dev/null 2>&1; then
      echo "${p}"
      return 0
    fi
  done
  return 1
}

# Wait up to ~20s for the frontend to come up
for i in $(seq 1 80); do
  FP=$(detect_frontend) && break || true
  sleep 0.25
done

if [ -z "${FP:-}" ]; then
  # open logs if we failed
  xdg-open .nordri/desktop-launch.log >/dev/null 2>&1 || true
  exit 1
fi

# Open the dashboard (switch to / if your root page is correct)
URL="http://localhost:${FP}/dashboard.html"

open_url() {
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 || return 1
  elif command -v gio >/dev/null 2>&1; then
    gio open "$URL" >/dev/null 2>&1 || return 1
  elif command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "$URL" >/dev/null 2>&1 || return 1
  else
    python3 - <<PY >/dev/null 2>&1 || true
import webbrowser; webbrowser.open("$URL")
PY
  fi
}

open_url || open_url  # try twice
