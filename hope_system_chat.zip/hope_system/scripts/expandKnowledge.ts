import fs from 'node:fs';
import path from 'node:path';
import yaml from 'yaml';
import { indexDocuments } from '../src/services/vectorStore';

/**
 * Generate a mock embedding for a given text.  In production this should
 * call an embedding API such as OpenAI text-embedding-3-large or Gemini.
 * Here we return a random vector of length 1536 for demonstration purposes.
 */
function generateEmbedding(text: string): number[] {
  const length = 1536;
  const vec: number[] = [];
  for (let i = 0; i < length; i++) {
    vec.push(Math.random());
  }
  return vec;
}

/**
 * Recursively traverse a directory and return all file paths ending with .yaml or .yml
 */
function collectYamlFiles(dir: string): string[] {
  let files: string[] = [];
  for (const entry of fs.readdirSync(dir)) {
    const fullPath = path.join(dir, entry);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      files = files.concat(collectYamlFiles(fullPath));
    } else if (entry.endsWith('.yaml') || entry.endsWith('.yml')) {
      files.push(fullPath);
    }
  }
  return files;
}

/**
 * Flatten a parsed YAML task into a single string.  We concatenate all keys and
 * values so the embedding captures as much context as possible.  For real use
 * cases, you may want to be more selective and include only descriptions and
 * steps.
 */
function flattenYaml(obj: any): string {
  if (typeof obj === 'string' || typeof obj === 'number' || typeof obj === 'boolean') {
    return String(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(flattenYaml).join(' ');
  }
  if (typeof obj === 'object' && obj !== null) {
    return Object.entries(obj)
      .map(([k, v]) => `${k} ${flattenYaml(v)}`)
      .join(' ');
  }
  return '';
}

async function main() {
  const tasksRoot = path.join(__dirname, '../src/isc/tasks');
  const files = collectYamlFiles(tasksRoot);
  const points = [];
  let idCounter = 1;
  for (const file of files) {
    const content = fs.readFileSync(file, 'utf8');
    const data = yaml.parse(content);
    const text = flattenYaml(data);
    const vector = generateEmbedding(text);
    const id = `task-${idCounter++}`;
    points.push({ id, vector, payload: { file, text } });
  }
  console.log(`Indexing ${points.length} task documents...`);
  await indexDocuments(points);
  console.log('Done indexing task documents.');
}

main().catch((err) => {
  console.error(err);
});