#!/usr/bin/env bash
set -euo pipefail

export NODE_OPTIONS="${NODE_OPTIONS:-"--dns-result-order=ipv4first"}"
export NO_PROXY="${NO_PROXY:-api.openai.com}"

echo "[prestart] OpenAI embeddings health check…"
if ! node -e '
(async () => {
  try {
    const m = await import("openai");
    const client = new m.default({
      apiKey: process.env.OPENAI_API_KEY, maxRetries: 2, timeout: 10000
    });
    await client.embeddings.create({
      model: process.env.EMBED_MODEL || "text-embedding-3-small",
      input: "healthcheck"
    });
    console.log("OK");
  } catch (e) {
    console.error("FAIL", e?.status || e?.code || e?.message);
    process.exit(2);
  }
})();
'; then
  echo "⚠️  OpenAI check failed; will SKIP indexing and still boot."
  export SKIP_INDEX=1
fi

echo "[prestart] build…"
npm run -s build

if [[ "${SKIP_INDEX:-0}" != "1" ]]; then
  echo "[prestart] indexing knowledge…"
  # Use the ESM build of expandKnowledge.  In previous builds this file
  # was renamed to .cjs but remained an ES module, which caused Node to
  # throw a SyntaxError when executed.  Running the .js file ensures
  # Node treats it as an ES module in a package with "type": "module".
  node dist/expandKnowledge.js || {
    echo "⚠️  Indexing failed (likely transient). Continuing boot."
  }
else
  echo "[prestart] indexing skipped due to health check failure."
fi
