#!/usr/bin/env bash
set -euo pipefail
export PORT="${PORT:-5000}"

# Build first so Node has JS to run
npm run -s build

# Choose an emitted entry (prefer ESM)
ENTRY=""
for cand in dist/server.mjs dist/server.js dist/server.cjs; do
  if [ -f "$cand" ]; then ENTRY="$cand"; break; fi
done
if [ -z "$ENTRY" ]; then
  echo "[dev-backend] Could not find dist/server.(mjs|js|cjs). Check tsconfig outDir/rootDir."
  exit 1
fi
echo "[dev-backend] using $ENTRY (PORT=$PORT)"

# Watch TS and restart Node on new dist output
npx concurrently -k -s first -n TSC,NODE \
  "npx tsc -w --preserveWatchOutput" \
  "npx nodemon --delay 200ms --watch dist --ext js,mjs,cjs,json --exec \"node --enable-source-maps $ENTRY\""
