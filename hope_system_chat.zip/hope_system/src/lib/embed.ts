type OpenAIType = typeof import("openai").default;

let OpenAIClass: OpenAIType | null = null;
async function getClient() {
  if (!OpenAIClass) {
    const mod = await import("openai");
    OpenAIClass = (mod as any).default;
  }
  return new OpenAIClass!({
    apiKey: process.env.OPENAI_API_KEY,
    maxRetries: 6,
    timeout: 60_000,
  });
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function embedOne(
  text: string,
  model = process.env.EMBED_MODEL ?? "text-embedding-3-small"
): Promise<number[]> {
  const client = await getClient();
  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      const r = await client.embeddings.create({ model, input: text });
      return r.data[0].embedding as unknown as number[];
    } catch (err: any) {
      const status = err?.status ?? err?.response?.status;
      const transient =
        [408, 429, 500, 502, 503, 504].includes(status) ||
        err?.code === "ECONNRESET" ||
        err?.name?.includes("Abort");
      if (!transient || attempt === 5) throw err;
      const backoff = Math.min(32000, 1000 * 2 ** attempt) + Math.floor(Math.random() * 1000);
      console.warn(`embed retry ${attempt + 1}/6 (status ${status ?? "n/a"}) waiting ${backoff}ms`);
      await sleep(backoff);
    }
  }
  throw new Error("unreachable");
}
