// src/security/mongo.ts
import { MongoClient } from 'mongodb';

export function makeMongoClient(): MongoClient {
  const uri = process.env.MONGO_URI;
  if (!uri) throw new Error('MONGO_URI is not set');

  const opts: any = {
    tls: true,
    tlsCertificateKeyFile: process.env.MONGO_X509_CERT,
    // Only set tlsCAFile if you actually have a custom CA chain:
    // tlsCAFile: process.env.MONGO_CA,
    authMechanism: 'MONGODB-X509',
    authSource: '$external'
  };

  return new MongoClient(uri, opts);
}

export async function pingMongo(): Promise<boolean> {
  const client = makeMongoClient();
  try {
    await client.connect();
    await client.db(process.env.MONGO_DB ?? 'nordri').command({ ping: 1 });
    return true;
  } finally {
    await client.close().catch(() => void 0);
  }
}
