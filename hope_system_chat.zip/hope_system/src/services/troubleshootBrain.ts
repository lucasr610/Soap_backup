/**
 * Dynamic troubleshooting engine for Nordri.
 *
 * This module implements a simple in‑memory troubleshooting brain that guides
 * technicians through a diagnostic workflow based on probabilistic reasoning.
 * It defines a baseline set of causes, tests and rules (for a generic pump)
 * and exposes functions to start a session, answer a test outcome, and
 * retrieve an existing session.  Probabilities are updated using a
 * naive Bayes‑like mechanism and the next best test is selected based on
 * the expected information gain (approximated by summed rule weights).
 *
 * NOTE: This implementation is deliberately simple and does not persist
 * sessions or learned rules to a database.  It is intended as a proof
 * of concept for a more sophisticated system that could store sessions
 * and rules in MongoDB.
 */

import crypto from 'node:crypto';

// Types for our diagnostic model.
export interface Cause {
  id: string;
  label: string;
  prior: number;
  safetyCritical?: boolean;
}

export interface Test {
  id: string;
  label: string;
  expectedOutcomes: string[];
  cost?: number;
  step: string;
}

export interface Rule {
  testId: string;
  outcome: string;
  strengthen?: Record<string, number>;
  weaken?: Record<string, number>;
}

export interface Session {
  id: string;
  asset: string;
  symptom: string;
  probabilities: Record<string, number>;
  history: Array<{
    ts: string;
    testId: string;
    outcome: string;
    probabilities: Record<string, number>;
  }>;
  completed: boolean;
  suggestion?: { causeId: string; label: string };
}

// Baseline cause definitions for a generic pump that will not run.
const baselineCauses: Cause[] = [
  {
    id: 'no_power_supply',
    label: 'No power at motor terminals',
    prior: 0.35,
    safetyCritical: true,
  },
  {
    id: 'overload_tripped',
    label: 'Motor overload tripped',
    prior: 0.25,
  },
  {
    id: 'failed_starter',
    label: 'Starter or contactor failed',
    prior: 0.2,
  },
  {
    id: 'seized_pump',
    label: 'Pump seized (mechanical)',
    prior: 0.2,
  },
];

// Baseline diagnostic tests for a generic pump.
const baselineTests: Test[] = [
  {
    id: 'measure_voltage_at_motor',
    label: 'Measure voltage at motor terminals',
    expectedOutcomes: ['has_power', 'no_power'],
    cost: 1,
    step: 'Using a calibrated meter, measure the line voltage at the motor terminals (e.g. T1–T2–T3).',
  },
  {
    id: 'inspect_overload',
    label: 'Inspect and reset overload',
    expectedOutcomes: ['tripped', 'not_tripped'],
    cost: 0.5,
    step: 'Check the motor overload status and reset if it has tripped per the OEM procedure.',
  },
  {
    id: 'bump_test',
    label: 'Bump test motor (pulse start)',
    expectedOutcomes: ['spins', 'hums_no_spin', 'dead'],
    cost: 1.5,
    step: 'Momentarily energize the motor to observe rotation or humming using a safe bump test method.',
  },
];

// Diagnostic rules relate test outcomes to cause probabilities.
const baselineRules: Rule[] = [
  {
    testId: 'measure_voltage_at_motor',
    outcome: 'no_power',
    strengthen: { no_power_supply: 0.9 },
    weaken: { failed_starter: 0.2, overload_tripped: 0.2 },
  },
  {
    testId: 'measure_voltage_at_motor',
    outcome: 'has_power',
    weaken: { no_power_supply: 0.9 },
  },
  {
    testId: 'inspect_overload',
    outcome: 'tripped',
    strengthen: { overload_tripped: 0.8 },
  },
  {
    testId: 'bump_test',
    outcome: 'hums_no_spin',
    strengthen: { seized_pump: 0.6, failed_starter: 0.3 },
  },
];

/**
 * Normalize a list of numeric probabilities so that they sum to 1.
 */
function normalize(probs: number[]): number[] {
  const sum = probs.reduce((a, b) => a + b, 0);
  if (sum <= 0) return probs.map(() => 0);
  return probs.map((p) => p / sum);
}

/**
 * Select the next test to perform based on current belief state.  We score
 * each test by summing the absolute rule weights that affect the most
 * probable causes.  Tests with higher expected impact are preferred.
 */
function pickNextTest(probState: Record<string, number>): string | undefined {
  const sortedCauses = Object.entries(probState)
    .sort(([, a], [, b]) => b - a)
    .map(([id]) => id)
    .slice(0, 5);
  const testScores: Record<string, number> = {};
  for (const test of baselineTests) {
    testScores[test.id] = 0;
  }
  for (const rule of baselineRules) {
    const key = rule.testId;
    for (const causeId of sortedCauses) {
      if (rule.strengthen && rule.strengthen[causeId]) {
        testScores[key] += Math.abs(rule.strengthen[causeId]);
      }
      if (rule.weaken && rule.weaken[causeId]) {
        testScores[key] += Math.abs(rule.weaken[causeId]);
      }
    }
  }
  const entries = Object.entries(testScores);
  if (entries.length === 0) return undefined;
  entries.sort(([, a], [, b]) => b - a);
  return entries[0][0];
}

/**
 * Update the belief state after observing the outcome of a test.
 */
function updateProbabilities(
  probState: Record<string, number>,
  testId: string,
  outcome: string,
): Record<string, number> {
  const newState: Record<string, number> = { ...probState };
  for (const rule of baselineRules) {
    if (rule.testId === testId && rule.outcome === outcome) {
      if (rule.strengthen) {
        for (const c in rule.strengthen) {
          const w = rule.strengthen[c];
          newState[c] = (newState[c] ?? 1e-6) * (1 + w);
        }
      }
      if (rule.weaken) {
        for (const c in rule.weaken) {
          const w = rule.weaken[c];
          newState[c] = (newState[c] ?? 1e-6) * (1 - Math.min(0.9, w));
        }
      }
    }
  }
  const keys = Object.keys(newState);
  const values = normalize(keys.map((k) => newState[k]));
  const result: Record<string, number> = {};
  keys.forEach((k, i) => {
    result[k] = values[i];
  });
  return result;
}

// In‑memory store of active troubleshooting sessions.
const sessions: Map<string, Session> = new Map();

/**
 * Start a new troubleshooting session.
 */
export function startSession({ asset, symptom }: { asset: string; symptom: string }): Session {
  const id = crypto.randomUUID();
  const initial: Record<string, number> = {};
  for (const c of baselineCauses) {
    initial[c.id] = c.prior;
  }
  const keys = Object.keys(initial);
  const normalizedVals = normalize(keys.map((k) => initial[k]));
  const probState: Record<string, number> = {};
  keys.forEach((k, i) => {
    probState[k] = normalizedVals[i];
  });
  const session: Session = {
    id,
    asset,
    symptom,
    probabilities: probState,
    history: [],
    completed: false,
  };
  sessions.set(id, session);
  return session;
}

/**
 * Answer a test outcome within an existing session.
 */
export function answerStep({ sessionId, testId, outcome }: { sessionId: string; testId: string; outcome: string }): Session {
  const session = sessions.get(sessionId);
  if (!session || session.completed) {
    throw new Error('Session not found or already completed');
  }
  const test = baselineTests.find((t) => t.id === testId);
  if (!test) throw new Error(`Unknown test ${testId}`);
  if (!test.expectedOutcomes.includes(outcome)) {
    throw new Error(`Invalid outcome ${outcome} for test ${testId}`);
  }
  const updated = updateProbabilities(session.probabilities, testId, outcome);
  session.probabilities = updated;
  session.history.push({ ts: new Date().toISOString(), testId, outcome, probabilities: { ...updated } });
  // Determine if we can suggest a fix
  const sorted = Object.entries(updated).sort(([, a], [, b]) => b - a);
  const [topId, topProb] = sorted[0];
  const topCause = baselineCauses.find((c) => c.id === topId);
  if (topCause && topProb >= 0.7 && !topCause.safetyCritical) {
    session.completed = true;
    session.suggestion = { causeId: topCause.id, label: topCause.label };
    return session;
  }
  // Otherwise, continue without marking completed
  return session;
}

/**
 * Retrieve an existing session by ID.
 */
export function getSession(id: string): Session | undefined {
  return sessions.get(id);
}

// Export baseline tests and helper so the routes can suggest the next test.
export { baselineTests as baselineTestsExport, pickNextTest as pickNextTestExport };