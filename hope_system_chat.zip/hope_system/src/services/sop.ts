// src/services/sop.ts
import { loadTask } from './taskLoader.js';
import { queryDocs } from './rag.js';

// Agents
import WatsonAgent from '../agents/WatsonAgent.js';
import MotherAgent from '../agents/MotherAgent.js';
import FatherAgent from '../agents/FatherAgent.js';
import ArbiterAgent from '../agents/ArbiterAgent.js';

type GenInput = {
  task?: string;             // YAML task name (without extension)
  jobOrder?: string;
  manual?: string;           // direct free‑text
  query?: string;            // RAG query to pull passages
};

type SOPStructured = {
  jobOrder?: string;
  task?: string;
  ppe: string[];
  jsa: string[];
  tools: string[];
  steps: string[];
  qa: string[];
  closeout: string[];
};

function toArray(val: any): string[] {
  if (!val) return [];
  if (Array.isArray(val)) return val.map(String).filter(Boolean);
  return [String(val)];
}

function buildStructuredFromTask(taskName: string, jobOrder: string | undefined, taskObj: any): SOPStructured {
  return {
    jobOrder,
    task: taskObj?.name ?? taskName,
    ppe: toArray(taskObj?.ppe),
    jsa: toArray(taskObj?.jsa),
    tools: toArray(taskObj?.tools),
    steps: toArray(taskObj?.steps),
    qa: toArray(taskObj?.qa),
    closeout: toArray(taskObj?.closeout),
  };
}

function buildStructuredFromManual(jobOrder: string | undefined, manual: string): SOPStructured {
  const parts = manual
    .split(/\n\s*\n|\. +/g)
    .map((s) => s.trim())
    .filter(Boolean);

  return {
    jobOrder,
    task: 'Ad-hoc SOP',
    ppe: [],
    jsa: [],
    tools: [],
    steps: parts,
    qa: [],
    closeout: [],
  };
}

function toUnnumberedLines(s: SOPStructured): string[] {
  const out: string[] = [];
  if (s.jobOrder) out.push(`Job Order: ${s.jobOrder}`);
  if (s.task) out.push(`Task: ${s.task}`);

  const section = (title: string, items: string[]) => {
    if (!items.length) return;
    out.push(`${title}:`);
    for (const it of items) out.push(`- ${it}`);
  };

  section('PPE', s.ppe);
  section('JSA', s.jsa);
  section('Tools', s.tools);
  section('Steps', s.steps);
  section('QA', s.qa);
  section('Closeout', s.closeout);

  return out;
}

export async function generateSOP(input: GenInput) {
  const { task: taskName, jobOrder, manual, query } = input;

  let structured: SOPStructured | null = null;

  // 1) YAML task wins if present
  if (taskName) {
    const taskObj = loadTask(taskName);
    if (taskObj) {
      structured = buildStructuredFromTask(taskName, jobOrder, taskObj);
    }
  }

  // 2) Manual text fallback
  if (!structured && manual && manual.trim().length) {
    structured = buildStructuredFromManual(jobOrder, manual);
  }

  // 3) RAG fallback
  if (!structured && query && query.trim().length) {
    const res = await queryDocs(query, { limit: 8 });
    const merged = res.results.map((r: any) => r.text).join('\n');
    if (merged.trim().length) {
      structured = buildStructuredFromManual(jobOrder, merged);
    }
  }

  // 4) Last resort skeleton
  if (!structured) {
    structured = {
      jobOrder,
      task: taskName ?? 'unspecified',
      ppe: [],
      jsa: [],
      tools: [],
      steps: [],
      qa: [],
      closeout: [],
    };
  }

  // Build unnumbered lines for formatter
  const unnumbered = toUnnumberedLines(structured);

  // Run agents
  const mother = new MotherAgent();
  const father = new FatherAgent();
  const arbiter = new ArbiterAgent();
  const watson = new WatsonAgent();

  const safety = await mother.run({ sop: unnumbered });
  const logic = await father.run({ sop: unnumbered });
  const conflicts = await arbiter.run({ watson: unnumbered, mother: safety, father: logic });

  // formatting (Watson numbers headings/content cleanly)
  const formatting = await watson.run({ text: unnumbered.join('\n') });

  return {
    // pretty, numbered lines for display/printing
    sopFormatted: formatting?.steps ?? unnumbered,
    // machine-friendly sections for UI/export/integrations
    sopStructured: structured,
    safety,
    logic,
    conflicts,
    formatting,
  };
}
