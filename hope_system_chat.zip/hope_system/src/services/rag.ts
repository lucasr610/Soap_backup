// src/services/rag.ts
import { VectorStore, QdrantPoint } from './vectorStore.js';
import { textToVector } from './embedding.js';

// In‑memory fallback store.  This array holds all vectors indexed via
// indexDocuments() when an external vector store is unavailable.  It
// enables basic similarity search without requiring a running Qdrant
// instance.  Each entry mirrors the QdrantPoint type: { id, vector, payload }.
const memoryStore: QdrantPoint[] = [];

// Note: avoid capturing environment variables at module load time.  The
// values for Qdrant configuration may change at runtime via the secrets
// API.  Helper functions below will read from process.env when
// necessary.

function getCollection(): string {
  return process.env.QDRANT_COLLECTION || 'default';
}

function getQdrantUrl(): string {
  return process.env.QDRANT_URL || 'http://localhost:6333';
}

function getQdrantApiKey(): string | undefined {
  return process.env.QDRANT_API_KEY;
}

// Canonical APIs
export async function indexDocuments(
  docs: QdrantPoint[],
  options?: { collection?: string; vectorSize?: number }
) {
  if (!docs?.length) return { upserted: 0 };

  const collection = options?.collection || getCollection();
  const vectorSize = options?.vectorSize ?? docs[0].vector.length;

  const store = new VectorStore({ url: getQdrantUrl(), apiKey: getQdrantApiKey(), collection });
  // Always append to the in‑memory fallback store.  If a document
  // with the same id already exists remove it first to avoid
  // duplicates during search.
  docs.forEach((doc) => {
    const idx = memoryStore.findIndex((p) => p.id === doc.id);
    if (idx >= 0) memoryStore.splice(idx, 1);
    memoryStore.push({ ...doc });
  });

  // Attempt to upsert into the external vector store.  If the Qdrant
  // service is unavailable or misconfigured the error is swallowed so
  // that indexing still succeeds for the in‑memory store.  The
  // presence of the external store is optional.
  try {
    await store.ensureCollection(vectorSize, 'Cosine');
    await store.upsert(docs);
  } catch (err) {
    // Log but ignore external storage failures
    console.warn('Qdrant upsert failed:', (err as any)?.message ?? err);
  }
  return { upserted: docs.length };
}

export async function search(
  query: string | number[],
  options?: { collection?: string; limit?: number; filter?: any }
) {
  const collection = options?.collection || getCollection();
  const limit = options?.limit ?? 5;

  const vector = Array.isArray(query) ? query : textToVector(query);
  // First compute results using the in‑memory fallback store.  Use
  // cosine similarity (dot product of normalized vectors).  If no
  // documents have been indexed this will return an empty array.
  const localResults = memoryStore
    .map((point) => {
      // Compute dot product similarity
      const v = point.vector;
      let score = 0;
      const len = Math.min(v.length, vector.length);
      for (let i = 0; i < len; i++) {
        score += v[i] * (vector as number[])[i];
      }
      return { id: point.id, payload: point.payload, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  // If the local store has results return them.  Otherwise attempt to
  // query the external vector store.  Errors from the external store
  // cause an empty array to be returned.
  if (localResults.length > 0) {
    return localResults;
  }
  try {
    const store = new VectorStore({ url: getQdrantUrl(), apiKey: getQdrantApiKey(), collection });
    await store.ensureCollection(vector.length, 'Cosine');
    return await store.search(vector, limit, options?.filter);
  } catch (err) {
    console.warn('Qdrant search failed:', (err as any)?.message ?? err);
    return [];
  }
}

// Back-compat adapters expected by routes/services:

// old name: indexDocs
export { indexDocuments as indexDocs };

// old name: queryDocs
// Supports (query: string|number[], limit?: number) or (query, opts)
export async function queryDocs(
  query: string | number[],
  limitOrOpts?: number | { collection?: string; limit?: number; filter?: any }
) {
  let opts: { collection?: string; limit?: number; filter?: any } | undefined;
  if (typeof limitOrOpts === 'number') {
    opts = { limit: limitOrOpts };
  } else {
    opts = limitOrOpts;
  }

  const raw = await search(query, opts);
  // Normalize to array of { text, score, id } for callers that expect .text
  return raw.map((r: any) => ({
    id: r.id,
    score: r.score,
    text:
      (r.payload && (r.payload.text ?? r.payload.content ?? r.payload.body)) ??
      JSON.stringify(r.payload ?? {})
  }));
}
