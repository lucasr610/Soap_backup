// src/services/embedding.ts
// Lightweight deterministic text -> vector embedding (no external API).
export function textToVector(text: string, dim = 256): number[] {
  const v = new Array<number>(dim).fill(0);
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    const idx = c % dim;
    v[idx] += (c % 13) + 1;
  }
  // L2 normalize
  let sum = 0;
  for (let i = 0; i < dim; i++) sum += v[i] * v[i];
  const norm = Math.sqrt(sum) || 1;
  for (let i = 0; i < dim; i++) v[i] = v[i] / norm;
  return v;
}
