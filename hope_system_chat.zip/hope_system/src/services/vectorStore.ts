// src/services/vectorStore.ts
import { QdrantClient } from '@qdrant/js-client-rest';

// Minimal point type compatible with Qdrant REST client
export type QdrantPoint = {
  id: number | string;
  vector: number[];
  payload?: Record<string, any>;
};

export class VectorStore {
  private client: QdrantClient;
  private collection: string;

  constructor(opts: { url?: string; apiKey?: string; collection: string }) {
    this.client = new QdrantClient({
      url: opts.url ?? process.env.QDRANT_URL ?? 'http://localhost:6333',
      apiKey: opts.apiKey ?? process.env.QDRANT_API_KEY
    });
    this.collection = opts.collection;
  }

  async ensureCollection(vectorSize: number, distance: 'Cosine' | 'Euclid' | 'Dot' = 'Cosine') {
    const collections = await this.client.getCollections();
    const exists = collections.collections?.some(c => c.name === this.collection);
    if (!exists) {
      await this.client.createCollection(this.collection, {
        vectors: { size: vectorSize, distance }
      });
    }
  }

  async upsert(points: QdrantPoint[]) {
    await this.client.upsert(this.collection, { points });
  }

  async search(query: number[], limit = 5, filter?: any) {
    return this.client.search(this.collection, {
      vector: query,
      limit,
      filter
    });
  }

  async deleteByIds(ids: (string | number)[]) {
    await this.client.delete(this.collection, { points: ids });
  }
}
