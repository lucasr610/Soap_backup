// src/services/secretsStore.ts
// A simple secrets vault implementation for Nordri.
//
// This module persists key/value pairs to an encrypted JSON file on disk.
// The encryption key is supplied via the environment variable NORDRI_KMS_KEY
// as a base64 encoded 32‑byte key.  If no key is provided a zeroed key is
// used which still protects against casual inspection (but for real
// deployments a strong key must be configured).

import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';
import path from 'node:path';

export type Secrets = Record<string, string>;

// Define the path to the encrypted vault.  Use ~/.nordri/secrets.json.enc
const vaultDir = path.join(process.env.HOME ?? '.', '.nordri');
const vaultFile = path.join(vaultDir, 'secrets.json.enc');

// Load the encryption key from NORDRI_KMS_KEY (base64) or fallback to zeros.
function getKey(): Buffer {
  const keyB64 = process.env.NORDRI_KMS_KEY;
  if (keyB64) {
    try {
      const buf = Buffer.from(keyB64, 'base64');
      if (buf.length === 32) return buf;
    } catch {}
  }
  // Default to a zero key.  This is insecure but prevents crashes if no key is set.
  return Buffer.alloc(32, 0);
}

/**
 * Encrypt a secrets object into a Buffer using AES‑256‑GCM.  The output
 * contains the IV (12 bytes), authentication tag (16 bytes) and ciphertext.
 */
function encrypt(obj: Secrets, key: Buffer): Buffer {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const plaintext = Buffer.from(JSON.stringify(obj), 'utf8');
  const enc = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]);
}

/**
 * Decrypt a Buffer produced by encrypt().  Returns the parsed secrets
 * object.  If decryption fails the vault will be reset to an empty object.
 */
function decrypt(buf: Buffer, key: Buffer): Secrets {
  try {
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const data = buf.subarray(28);
    const decipher = createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const dec = Buffer.concat([decipher.update(data), decipher.final()]);
    return JSON.parse(dec.toString('utf8'));
  } catch {
    // If anything goes wrong return an empty vault.  The caller may choose
    // to overwrite the corrupt file by saving later.
    return {};
  }
}

/**
 * Load the secrets vault from disk using the configured key.  If the file
 * does not exist an empty vault is returned.  Corrupt or invalid data
 * silently resets the vault to an empty object.
 */
export function loadVault(): Secrets {
  const key = getKey();
  if (!existsSync(vaultFile)) return {};
  const blob = readFileSync(vaultFile);
  return decrypt(blob, key);
}

/**
 * Persist the given secrets object to disk using the configured key.
 */
export function saveVault(obj: Secrets): void {
  const key = getKey();
  mkdirSync(vaultDir, { recursive: true });
  writeFileSync(vaultFile, encrypt(obj, key));
}

/**
 * List all stored secret keys.  Values are not returned to avoid leaking
 * sensitive data.
 */
export function listKeys(): string[] {
  const secrets = loadVault();
  return Object.keys(secrets).sort();
}

/**
 * Store or update a secret value.  If the key already exists it will be
 * overwritten.  An empty or undefined value will delete the key instead.
 */
export function storeSecret(key: string, value: string): void {
  const secrets = loadVault();
  if (value === undefined || value === null || value === '') {
    delete secrets[key];
  } else {
    secrets[key] = value;
  }
  saveVault(secrets);
}

/**
 * Delete a secret key.  If the key does not exist this is a no‑op.
 */
export function deleteSecret(key: string): void {
  const secrets = loadVault();
  if (key in secrets) {
    delete secrets[key];
    saveVault(secrets);
  }
}