/*
 * services/tasks.ts
 *
 * Service layer for dynamically loading, storing and managing training
 * tasks.  Tasks are originally defined as YAML files under src/isc/tasks
 * and are converted into a normalised structure on first load.  Each
 * task comprises one or more atomic steps, and metadata such as
 * domain/trade, tags and versioning information.  Persisted tasks are
 * stored to a JSON file on disk by default; in a production
 * deployment this would be backed by MongoDB.  Consumers of this
 * module should treat the returned objects as immutable and avoid
 * mutating them directly.
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import yaml from 'yaml';

/**
 * Type definitions for a single step and a task.  Steps capture
 * individual instructions with optional prerequisites, expected
 * outcomes, safety notes and tags.  Each step and task carries a
 * version and timestamps to support auditing and future diffing.
 */
export interface TaskStep {
  id: string;
  description: string;
  prerequisites: string[];
  expectedOutcome?: string;
  safetyNotes?: string;
  tags: string[];
  version: number;
  createdAt: number;
  updatedAt: number;
  changelog: string[];
}

export interface TaskEntry {
  id: string;
  name: string;
  domain?: string;
  level?: number;
  tags: string[];
  steps: TaskStep[];
  version: number;
  createdAt: number;
  updatedAt: number;
  changelog: string[];
}

// Location of the persisted tasks JSON.  If NORDRI_TASKS_DB is
// provided the tasks will be read from and written to that file;
// otherwise a default file under the project root is used.  The
// directory is created on demand.  In a production environment this
// module should be replaced with a Mongo-backed implementation.
const DEFAULT_DB_PATH = path.resolve(process.cwd(), 'tasks_db.json');
const TASKS_DB_PATH = process.env.NORDRI_TASKS_DB || DEFAULT_DB_PATH;

/**
 * Internal in-memory cache of tasks.  Mutations through the
 * exported CRUD operations update this object and then persist to
 * disk.  Always treat this as read-only outside of this module.
 */
const tasks: Record<string, TaskEntry> = {};

/**
 * Generate a short deterministic ID from a string.  We use a SHA1
 * digest truncated to 8 characters to reduce collisions while
 * producing human-friendly identifiers.  If no input is provided
 * a random UUID v4 is returned.
 */
function genId(input?: string): string {
  if (input) {
    const hash = crypto.createHash('sha1').update(input).digest('hex');
    return hash.slice(0, 8);
  }
  return crypto.randomUUID().replace(/-/g, '').slice(0, 12);
}

/**
 * Load tasks from the persisted JSON file.  If the file does not
 * exist an empty object is returned.  This function runs at module
 * initialisation to populate the in-memory cache.  Errors during
 * parsing are logged and result in a fresh state.
 */
function loadTasksFromDb() {
  try {
    if (!fs.existsSync(TASKS_DB_PATH)) return;
    const raw = fs.readFileSync(TASKS_DB_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      for (const k of Object.keys(parsed)) {
        tasks[k] = parsed[k];
      }
    }
  } catch (err) {
    // Log and ignore; start with an empty cache
    // eslint-disable-next-line no-console
    console.warn('Failed to load tasks DB:', err);
  }
}

/**
 * Persist the current tasks cache to disk.  The parent directory
 * will be created on demand.  Synchronous writes are acceptable
 * here because tasks modifications are infrequent and small.  In a
 * production setting use an async DB client instead.
 */
function saveTasksToDb() {
  try {
    const dir = path.dirname(TASKS_DB_PATH);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(TASKS_DB_PATH, JSON.stringify(tasks, null, 2));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to persist tasks DB:', err);
  }
}

/**
 * Scan the project for YAML task definitions and convert them into
 * TaskEntry records.  This function is idempotent: existing tasks
 * will not be overwritten unless they differ in their source
 * content, in which case a new version will be created.  The search
 * roots mirror those used by the legacy taskLoader.ts: src/isc/tasks
 * when running in source and dist/isc/tasks after compilation.
 */
function importYamlTasks() {
  const projectRoot = path.resolve(__dirname, '..', '..');
  const candidateRoots = [
    path.join(projectRoot, 'src', 'isc', 'tasks'),
    path.join(projectRoot, 'isc', 'tasks'),
    path.join(__dirname, '..', 'isc', 'tasks'),
  ];

  const visited: string[] = [];
  const walkDir = (dir: string) => {
    try {
      for (const entry of fs.readdirSync(dir)) {
        const full = path.join(dir, entry);
        const stat = fs.statSync(full);
        if (stat.isDirectory()) {
          walkDir(full);
        } else if (stat.isFile()) {
          const lower = entry.toLowerCase();
          if (lower.endsWith('.yaml') || lower.endsWith('.yml')) {
            visited.push(full);
          }
        }
      }
    } catch {
      /* ignore */
    }
  };
  for (const root of candidateRoots) {
    if (fs.existsSync(root) && fs.statSync(root).isDirectory()) {
      walkDir(root);
    }
  }
  // Convert each YAML file into a TaskEntry if not already present
  for (const filePath of visited) {
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      const parsed: any = yaml.parse(raw);
      if (!parsed || typeof parsed !== 'object') continue;
      // Derive a stable ID from the relative path
      const rel = path.relative(process.cwd(), filePath);
      const id = genId(rel);
      const now = Date.now();
      if (!tasks[id]) {
        const name: string = parsed.name || parsed.title || path.basename(filePath, path.extname(filePath));
        const domain: string | undefined = parsed.domain || parsed.trade;
        const level: number | undefined = typeof parsed.level === 'number' ? parsed.level : undefined;
        const tags: string[] = [];
        if (parsed.tags && Array.isArray(parsed.tags)) {
          tags.push(...parsed.tags.map((t: any) => String(t)));
        }
        if (domain && !tags.includes(domain)) tags.push(domain);
        // Build steps from various YAML fields
        const steps: TaskStep[] = [];
        const pushStep = (desc: string) => {
          const sid = genId(`${id}:${steps.length}:${desc}`);
          steps.push({
            id: sid,
            description: desc,
            prerequisites: [],
            tags: [],
            version: 1,
            createdAt: now,
            updatedAt: now,
            changelog: ['initial import'],
          });
        };
        // Prechecks become a single aggregated step
        if (Array.isArray(parsed.prechecks) && parsed.prechecks.length) {
          pushStep(`Prechecks: ${parsed.prechecks.join('; ')}`);
        }
        // Steps list
        if (Array.isArray(parsed.steps)) {
          for (const s of parsed.steps) {
            if (typeof s === 'string') {
              pushStep(s);
            } else if (s && typeof s === 'object') {
              // If the step is an object with a description property
              const desc = s.description || s.step || JSON.stringify(s);
              pushStep(desc);
            }
          }
        }
        // HTN tasks: treat each as a sub-task call
        if (Array.isArray(parsed.htn)) {
          for (const sub of parsed.htn) {
            pushStep(`Execute sub-task: ${sub}`);
          }
        }
        // QA checks become a step
        if (Array.isArray(parsed.qa_checks) && parsed.qa_checks.length) {
          const qlist = parsed.qa_checks.map((q: any) => {
            if (typeof q === 'string') return q;
            if (q && typeof q === 'object' && q.check) return q.check;
            return JSON.stringify(q);
          });
          pushStep(`QA checks: ${qlist.join('; ')}`);
        }
        // Closeout
        if (Array.isArray(parsed.closeout) && parsed.closeout.length) {
          pushStep(`Closeout: ${parsed.closeout.join('; ')}`);
        }
        // If no steps detected, fallback to description
        if (!steps.length && typeof parsed.description === 'string') {
          pushStep(parsed.description);
        }
        tasks[id] = {
          id,
          name,
          domain,
          level,
          tags,
          steps,
          version: 1,
          createdAt: now,
          updatedAt: now,
          changelog: ['imported from YAML'],
        };
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.warn(`Failed to import YAML task ${filePath}:`, err);
    }
  }
  // Persist after import
  saveTasksToDb();
}

// Initialise the tasks cache on module load
loadTasksFromDb();
// Import YAML tasks only if the cache is empty – preventing duplicate
// imports on subsequent runs.  This allows the persisted DB to
// override YAML definitions until a manual refresh is triggered.
if (Object.keys(tasks).length === 0) {
  importYamlTasks();
}

/*
 * CRUD API exposed to route handlers.  Each operation persists
 * modifications to disk and updates timestamps and version numbers.
 */

export function listTasks(): TaskEntry[] {
  return Object.values(tasks);
}

export function getTask(id: string): TaskEntry | null {
  return tasks[id] ?? null;
}

export function createTask(input: Omit<TaskEntry, 'id' | 'version' | 'createdAt' | 'updatedAt' | 'changelog'>): TaskEntry {
  const id = genId(input.name + Date.now().toString());
  const now = Date.now();
  const entry: TaskEntry = {
    id,
    name: input.name,
    domain: input.domain,
    level: input.level,
    tags: input.tags || [],
    steps: input.steps,
    version: 1,
    createdAt: now,
    updatedAt: now,
    changelog: ['created'],
  };
  tasks[id] = entry;
  saveTasksToDb();
  return entry;
}

export function updateTask(id: string, updates: Partial<Omit<TaskEntry, 'id' | 'createdAt'>>): TaskEntry | null {
  const existing = tasks[id];
  if (!existing) return null;
  const now = Date.now();
  let updated = { ...existing };
  if (updates.name) updated.name = updates.name;
  if (updates.domain) updated.domain = updates.domain;
  if (typeof updates.level === 'number') updated.level = updates.level;
  if (Array.isArray(updates.tags)) updated.tags = updates.tags;
  if (Array.isArray(updates.steps)) updated.steps = updates.steps;
  updated.version = existing.version + 1;
  updated.updatedAt = now;
  updated.changelog = [...existing.changelog, 'updated'];
  tasks[id] = updated;
  saveTasksToDb();
  return updated;
}

export function deleteTask(id: string): boolean {
  if (!tasks[id]) return false;
  delete tasks[id];
  saveTasksToDb();
  return true;
}

/**
 * Build a job by combining tasks that match the provided filters.
 * At minimum the trade/Domain parameter should be provided.  Jobs
 * simply return an ordered list of step descriptions; a real
 * implementation might incorporate scheduling, dependencies and
 * validations.  Passing an explicit list of task IDs overrides the
 * filter logic.  When no tasks match an empty list is returned.
 */
export function buildJob(opts: { trade?: string; equipment?: string; symptom?: string; taskIds?: string[]; }): { steps: TaskStep[]; tasks: TaskEntry[] } {
  const matchedTasks: TaskEntry[] = [];
  if (opts.taskIds && Array.isArray(opts.taskIds) && opts.taskIds.length) {
    for (const tid of opts.taskIds) {
      const t = tasks[tid];
      if (t) matchedTasks.push(t);
    }
  } else {
    const trade = opts.trade?.toLowerCase();
    for (const t of Object.values(tasks)) {
      if (trade && t.domain && t.domain.toLowerCase() === trade) {
        matchedTasks.push(t);
      }
    }
  }
  // Concatenate steps in order of tasks; duplicates are preserved
  const steps: TaskStep[] = [];
  for (const task of matchedTasks) {
    steps.push(...task.steps);
  }
  return { steps, tasks: matchedTasks };
}