import fs from 'node:fs';
import path from 'node:path';
import yaml from 'yaml';

interface NodeDefinition {
  question?: string;
  yes?: string | { action: string };
  no?: string | { action: string };
  action?: string;
}

interface Procedure {
  name: string;
  start: string;
  nodes: Record<string, NodeDefinition>;
}

/**
 * Load an industrial service procedure from disk.  Procedures are stored
 * under ~/.nordri/isc/procedures and may be in JSON or YAML format.
 */
export function loadProcedure(fileName: string): Procedure {
  const homeDir = process.env.HOME ?? '.';
  const filePath = path.join(homeDir, '.nordri', 'isc', 'procedures', fileName);
  if (!fs.existsSync(filePath)) throw new Error(`Procedure ${fileName} not found`);
  const text = fs.readFileSync(filePath, 'utf8');
  if (fileName.endsWith('.yaml') || fileName.endsWith('.yml')) {
    return yaml.parse(text);
  }
  return JSON.parse(text);
}

/**
 * Run a decision tree troubleshooting procedure.  The function traverses
 * the procedure based on answers provided in the `answers` map.  It returns
 * the path taken and any recommended actions.
 */
export function runProcedure(proc: Procedure, answers: Record<string, boolean>) {
  const pathSteps: string[] = [];
  let current = proc.start;
  let action: string | undefined;

  while (current) {
    const node = proc.nodes[current];
    if (!node) throw new Error(`Unknown node ${current}`);
    pathSteps.push(current);
    // leaf with action
    if (node.action) {
      action = node.action;
      break;
    }
    // ask question and decide branch
    const answer = answers[current];
    if (answer === undefined) {
      break; // stop early if answer not provided
    }
    const branch = answer ? node.yes : node.no;
    if (typeof branch === 'string') {
      current = branch;
    } else if (branch && typeof branch === 'object' && 'action' in branch) {
      action = branch.action;
      break;
    } else {
      break;
    }
  }

  return { path: pathSteps, action };
}

/**
 * Suggest a baseline procedure for a given system.  This is a placeholder that
 * returns a minimal tree.  In production this would call an LLM to synthesise
 * a procedure.
 */
export function suggestProcedure(system: string): Procedure {
  return {
    name: `${system} Troubleshooting`,
    start: 'initial_check',
    nodes: {
      initial_check: {
        question: `Is the ${system} powered on?`,
        yes: { action: `Consult the ${system} manual for further diagnostics.` },
        no: { action: `Power on the ${system} and verify connections.` },
      },
    },
  };
}