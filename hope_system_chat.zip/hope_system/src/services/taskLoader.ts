// src/services/taskLoader.ts
import fs from 'node:fs';
import path from 'node:path';
import yaml from 'yaml';


/**
 * Load a YAML task definition named <task>.yaml or <task>.yml.
 * Searches these roots so it works in dev (src) and after build (dist):
 *   1) <project>/src/isc/tasks
 *   2) <project>/isc/tasks
 *   3) <dist>/isc/tasks
 * Returns parsed object, or null if not found.
 */
export function loadTask(taskName: string): any | null {
  if (!taskName || typeof taskName !== 'string') return null;

  // dist/services -> dist
  const distRoot = path.resolve(__dirname, '..');
  // project root (one level above dist)
  const projectRoot = path.resolve(distRoot, '..');

  const candidateRoots = [
    path.join(projectRoot, 'src', 'isc', 'tasks'),
    path.join(projectRoot, 'isc', 'tasks'),
    path.join(distRoot, 'isc', 'tasks'),
  ];

  const tryFind = (rootDir: string): string | null => {
    if (!fs.existsSync(rootDir) || !fs.statSync(rootDir).isDirectory()) return null;

    // BFS through subdirectories
    const queue: string[] = [rootDir];
    while (queue.length) {
      const dir = queue.shift()!;
      let entries: string[] = [];
      try {
        entries = fs.readdirSync(dir);
      } catch {
        continue;
      }
      for (const entry of entries) {
        const p = path.join(dir, entry);
        let st: fs.Stats;
        try {
          st = fs.statSync(p);
        } catch {
          continue;
        }
        if (st.isDirectory()) {
          queue.push(p);
          continue;
        }
        if (!st.isFile()) continue;

        const base = path.basename(p);
        const lower = base.toLowerCase();
        const isYaml = lower.endsWith('.yaml') || lower.endsWith('.yml');
        if (!isYaml) continue;

        const nameOnly = base.replace(/\.ya?ml$/i, '');
        if (nameOnly === taskName) {
          return p;
        }
      }
    }
    return null;
  };

  let found: string | null = null;
  for (const root of candidateRoots) {
    found = tryFind(root);
    if (found) break;
  }
  if (!found) return null;

  try {
    const raw = fs.readFileSync(found, 'utf8');
    const parsed = yaml.parse(raw);
    return parsed ?? null;
  } catch {
    return null;
  }
}
