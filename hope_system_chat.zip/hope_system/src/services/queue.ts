// src/services/queue.ts
import { EventEmitter } from 'node:events';

export type Task<T = unknown> = {
  id: string;
  payload: T;
  enqueuedAt: number;
  attempts: number;
  maxAttempts: number;
  name?: string;
};

export class QueueService<T = unknown> extends EventEmitter {
  private q: Task<T>[] = [];
  private processing = false;
  private concurrency: number;
  private inFlight = 0;

  constructor(concurrency = 1) {
    super();
    this.concurrency = Math.max(1, concurrency);
  }

  size() { return this.q.length; }
  busy() { return this.inFlight >= this.concurrency; }

  enqueue(task: Omit<Task<T>, 'enqueuedAt' | 'attempts'>) {
    const t: Task<T> = { ...task, enqueuedAt: Date.now(), attempts: 0 };
    this.q.push(t);
    this.emit('enqueued', t);
    this.kick();
    return t.id;
  }

  private async kick() {
    if (this.processing) return;
    this.processing = true;
    try {
      while (this.inFlight < this.concurrency && this.q.length > 0) {
        const next = this.q.shift()!;
        this.inFlight++;
        this.handle(next).finally(() => {
          this.inFlight--;
          this.kick();
        });
      }
    } finally {
      this.processing = false;
    }
  }

  private async handle(task: Task<T>) {
    try {
      this.emit('process', task);
      this.emit('completed', task);
    } catch (err) {
      task.attempts++;
      this.emit('failed', task, err);
      if (task.attempts < task.maxAttempts) {
        this.q.push(task); // retry
      } else {
        this.emit('dead', task, err);
      }
    }
  }
}

const queue = new QueueService<any>(2);

// Back-compat adapter:
// - enqueue(name, payload, { delay?, maxAttempts? })
// - enqueue(payload, { delay?, maxAttempts? })
// - enqueue(payload, maxAttempts?)
export async function enqueue(
  a: any,
  b?: any,
  c?: { delay?: number; maxAttempts?: number }
): Promise<string> {
  let name: string | undefined;
  let payload: any;
  let delay = 0;
  let maxAttempts = 3;

  if (typeof a === 'string') {
    name = a;
    if (b && typeof b === 'object' && !Array.isArray(b)) payload = b;
    if (c) {
      if (typeof c.delay === 'number') delay = c.delay;
      if (typeof c.maxAttempts === 'number') maxAttempts = c.maxAttempts;
    }
  } else {
    payload = a;
    if (typeof b === 'number') {
      maxAttempts = b;
    } else if (b && typeof b === 'object') {
      if (typeof b.delay === 'number') delay = b.delay;
      if (typeof b.maxAttempts === 'number') maxAttempts = b.maxAttempts;
    }
  }

  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  if (delay > 0) {
    setTimeout(() => queue.enqueue({ id, payload, maxAttempts, name }), delay);
  } else {
    queue.enqueue({ id, payload, maxAttempts, name });
  }
  return id;
}

export default queue;
