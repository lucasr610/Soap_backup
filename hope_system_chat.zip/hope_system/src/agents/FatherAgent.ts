import { logicRules } from '../utils/rules.js';

export class FatherAgent {
  /**
   * Perform logical dependency checks on a SOP.  Returns warnings along with
   * HITL/AIITL metadata.  Human review is required when any warnings are
   * generated.  AI summarises its findings for the human.
   */
  async run({ sop }: { sop: string[] }): Promise<{
    warnings: string[];
    hitlRequired: boolean;
    aiitlCheck: string;
  }> {
    const warnings: string[] = [];
    const text = Array.isArray(sop) ? sop.join('\n') : String(sop);
    for (const rule of logicRules) {
      if (
        rule.prerequisite.test(text) &&
        rule.dependent.test(text) &&
        text.indexOf(text.match(rule.dependent)?.[0] ?? '') <
          text.indexOf(text.match(rule.prerequisite)?.[0] ?? '')
      ) {
        warnings.push(rule.message);
      }
    }
    const hitlRequired = warnings.length > 0;
    const aiitlCheck = hitlRequired
      ? 'AI flags potential logical dependency issues; human review required.'
      : 'AI did not detect dependency issues.';
    return { warnings, hitlRequired, aiitlCheck };
  }
}

export default FatherAgent;