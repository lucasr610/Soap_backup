/**
 * DocumentParserAgent breaks a large document into smaller passages.  This
 * implementation simply splits on blank lines or paragraph boundaries.
 */
export class DocumentParserAgent {
  /**
   * Break a document into passages.  Includes HITL/AIITL metadata.  No
   * human review is required because parsing is deterministic.
   */
  async run({ text }: { text: string }): Promise<{
    passages: string[];
    hitlRequired: boolean;
    aiitlCheck: string;
  }> {
    if (typeof text !== 'string') {
      return { passages: [], hitlRequired: false, aiitlCheck: 'No text provided.' };
    }
    const passages = text
      .split(/\n\s*\n/)
      .map((p) => p.trim())
      .filter((p) => p.length > 0);
    return {
      passages,
      hitlRequired: false,
      aiitlCheck: 'AI parsed the document into passages successfully.',
    };
  }
}

export default DocumentParserAgent;