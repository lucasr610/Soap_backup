import { suggestProcedure } from '../services/troubleshoot.js';

/**
 * MasterTroubleshooterAgent suggests baseline procedures for given systems.
 */
export class MasterTroubleshooterAgent {
  async run({ system }: { system: string }): Promise<any> {
    const proc = suggestProcedure(system);
    // For baseline procedures we always require human validation because they
    // are generated suggestions.  The AI invites the human to adapt the
    // baseline to the specific environment.
    return {
      procedure: proc,
      hitlRequired: true,
      aiitlCheck: 'AI suggests a baseline procedure; human should adapt and approve.',
    };
  }
}

export default MasterTroubleshooterAgent;