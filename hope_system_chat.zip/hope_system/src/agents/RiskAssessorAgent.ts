/**
 * RiskAssessorAgent analyses a job order and highlights hazards, PPE
 * requirements and other safety considerations.  It uses simple pattern
 * matching to extract risk factors.  For production use, integrate with a
 * proper risk assessment library or knowledge base.
 */

export interface RiskAssessment {
  hazards: string[];
  ppe: string[];
  notes: string;
}

export class RiskAssessorAgent {
  private hazardKeywords: Record<string, string>;
  private ppeKeywords: Record<string, string>;
  constructor() {
    this.hazardKeywords = {
      voltage: 'Electrical shock',
      chemical: 'Chemical exposure',
      heat: 'Burn hazard',
      confined: 'Confined space'
    };
    this.ppeKeywords = {
      gloves: 'Insulated gloves',
      helmet: 'Hard hat',
      respirator: 'Respirator',
      goggles: 'Safety goggles'
    };
  }
  assess(description: string): RiskAssessment {
    const hazards: string[] = [];
    const ppe: string[] = [];
    const lower = description.toLowerCase();
    for (const key in this.hazardKeywords) {
      if (lower.includes(key)) hazards.push(this.hazardKeywords[key]);
    }
    for (const key in this.ppeKeywords) {
      if (lower.includes(key)) ppe.push(this.ppeKeywords[key]);
    }
    const notes = hazards.length || ppe.length
      ? 'Review hazards and ensure proper PPE is available.'
      : 'No significant hazards detected.';
    return { hazards, ppe, notes };
  }
}