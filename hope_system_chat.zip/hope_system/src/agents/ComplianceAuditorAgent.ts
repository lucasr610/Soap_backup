/**
 * ComplianceAuditorAgent verifies that a generated SOP meets the required
 * regulatory standards.  Given an SOP as text, it returns a list of
 * compliance issues.  This basic implementation checks for required
 * sections and keywords; you can extend it to interface with external
 * compliance databases or rule engines.
 */

export interface ComplianceIssue {
  message: string;
}

export class ComplianceAuditorAgent {
  private requiredSections: string[];
  constructor() {
    this.requiredSections = ['preparation', 'safety', 'procedure', 'verification'];
  }
  audit(sop: string): ComplianceIssue[] {
    const issues: ComplianceIssue[] = [];
    const lower = sop.toLowerCase();
    for (const section of this.requiredSections) {
      if (!lower.includes(section)) {
        issues.push({ message: `Missing required section: ${section}` });
      }
    }
    return issues;
  }
}