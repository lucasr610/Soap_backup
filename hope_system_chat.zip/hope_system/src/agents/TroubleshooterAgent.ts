import { loadProcedure, runProcedure } from '../services/troubleshoot.js';

/**
 * TroubleshooterAgent wraps the decision tree runner.  It accepts a procedure
 * file name and an answers map, and returns the path and action recommended.
 */
export class TroubleshooterAgent {
  async run({
    procedure,
    answers,
  }: {
    procedure: string;
    answers: Record<string, boolean>;
  }): Promise<{
    path: string[];
    action?: string;
    hitlRequired: boolean;
    aiitlCheck: string;
  }> {
    const proc = loadProcedure(procedure);
    const result = runProcedure(proc, answers ?? {});
    // Determine whether human review is required.  If no action is returned
    // (i.e. the procedure is incomplete) then a human should validate next steps.
    const hitlRequired = result.action === undefined;
    const aiitlCheck = hitlRequired
      ? 'AI reached a decision point without a final action; human input needed to proceed.'
      : 'AI produced a recommended action; human should verify and execute.';
    return {
      path: result.path,
      action: result.action,
      hitlRequired,
      aiitlCheck,
    };
  }
}

export default TroubleshooterAgent;