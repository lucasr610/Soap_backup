import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';


export interface AgentMeta {
  id: string;
  name: string;
  description: string;
  modulePath: string; // relative to dist/ root, e.g. "./agents/WatsonAgent.js"
}

export interface AgentInstance {
  meta: AgentMeta;
  run(input: any): Promise<any>;
}

const agents: AgentInstance[] = [];

/**
 * Load agents defined in agents.manifest.json.
 * modulePath entries should be relative to dist/ after build.
 */
export async function loadAgents() {
  if (agents.length > 0) return agents;

  // dist/agents -> dist/
  const distRoot = path.resolve(__dirname, '..');

  // project root is one level above dist/
  const manifestPath = path.resolve(distRoot, '..', 'agents.manifest.json');
  const manifest: AgentMeta[] = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

  for (const entry of manifest) {
    let modPath = entry.modulePath;

    // make relative paths resolve from distRoot
    if (!path.isAbsolute(modPath)) {
      modPath = path.resolve(distRoot, modPath);
    }

    // ensure .js extension for compiled files
    if (!/\.(mjs|cjs|js|ts)$/.test(modPath)) {
      modPath += '.js';
    }

    const imported = await import(pathToFileURL(modPath).href);
    const AgentClass = (imported.default ?? imported) as any;

    const instance: AgentInstance = {
      meta: entry,
      run: async (input: any) => {
        const agent = new AgentClass();
        return agent.run(input);
      },
    };
    agents.push(instance);
  }
  return agents;
}

export function getAgents() {
  return agents;
}

export async function runAgent(id: string, input: any) {
  const agent = agents.find((a) => a.meta.id === id);
  if (!agent) throw new Error(`Agent ${id} not found`);
  return agent.run(input);
}
