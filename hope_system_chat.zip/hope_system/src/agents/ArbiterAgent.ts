/**
 * ArbiterAgent detects conflicts between the outputs of other agents.  For this
 * simple implementation a conflict is defined as any safety issue that also
 * appears as a logic warning.  The Arbiter returns all such conflicts for
 * human review.
 */
export class ArbiterAgent {
  /**
   * Detect conflicts between the outputs of Mother and Father agents.  A
   * conflict occurs when a safety issue also appears as a logic warning.  In
   * addition to conflicts, this method returns HITL/AIITL metadata.  Human
   * review is required when any conflicts are detected.
   */
  async run({
    watson,
    mother,
    father,
  }: {
    watson: string[] | any;
    mother: { issues: string[] };
    father: { warnings: string[] };
  }): Promise<{ conflicts: string[]; hitlRequired: boolean; aiitlCheck: string }> {
    const conflicts: string[] = [];
    // Compare safety issues to logic warnings for overlap
    for (const issue of mother.issues) {
      if ((father.warnings ?? []).includes(issue)) {
        conflicts.push(issue);
      }
    }
    const hitlRequired = conflicts.length > 0;
    const aiitlCheck = hitlRequired
      ? 'AI detected conflicting safety and logic warnings; human arbitration needed.'
      : 'AI sees no conflicts between agent outputs.';
    return { conflicts, hitlRequired, aiitlCheck };
  }
}

export default ArbiterAgent;