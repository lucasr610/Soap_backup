/**
 * ClassifierAgent identifies the trade and subdomain from an incoming job order.
 * It is designed to be used within the Nordri multi‑agent pipeline.  Given a
 * job description, it returns a classification label and confidence score.
 * You can implement your own classification logic using keywords, machine
 * learning models or external services.  The default implementation uses a
 * simple keyword map as a placeholder.
 */

export interface ClassificationResult {
  trade: string;
  subdomain: string;
  confidence: number;
}

export class ClassifierAgent {
  private keywordMap: Record<string, { trade: string; subdomain: string }>; 
  constructor() {
    this.keywordMap = {
      hvac: { trade: 'HVAC', subdomain: 'heating' },
      pump: { trade: 'Pumps', subdomain: 'centrifugal' },
      boiler: { trade: 'Boilers', subdomain: 'steam' },
      electrical: { trade: 'Electrical', subdomain: 'panels' },
    };
  }
  classify(description: string): ClassificationResult {
    const lower = description.toLowerCase();
    for (const key of Object.keys(this.keywordMap)) {
      if (lower.includes(key)) {
        const { trade, subdomain } = this.keywordMap[key];
        return { trade, subdomain, confidence: 0.6 };
      }
    }
    return { trade: 'Unknown', subdomain: 'Unknown', confidence: 0.0 };
  }
}