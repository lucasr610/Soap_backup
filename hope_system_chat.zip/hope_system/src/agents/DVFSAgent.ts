import os from 'node:os';

/**
 * DVFSAgent monitors system load and would throttle job concurrency in a
 * production deployment.  This implementation simply reports the current
 * 1‑minute load average relative to the number of CPU cores.
 */
export class DVFSAgent {
  async run(): Promise<{ load: number; status: string; hitlRequired: boolean; aiitlCheck: string }> {
    const cores = os.cpus().length;
    const load = os.loadavg()[0] / cores;
    const status = load > 0.8 ? 'throttle' : 'normal';
    // When load is high and status is 'throttle', a human should review the
    // system health to ensure continued safe operation.  Otherwise, no
    // immediate human intervention is needed.
    const hitlRequired = status === 'throttle';
    const aiitlCheck = hitlRequired
      ? 'AI detected high load; human should evaluate system health and adjust concurrency.'
      : 'AI monitored system load and found it within normal operating range.';
    return { load, status, hitlRequired, aiitlCheck };
  }
}

export default DVFSAgent;