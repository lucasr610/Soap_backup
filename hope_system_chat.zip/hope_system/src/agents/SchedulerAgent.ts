import { enqueue } from '../services/queue.js';

/**
 * SchedulerAgent schedules tasks on the BullMQ queue.  It accepts a job name,
 * payload and optional delay.
 */
export class SchedulerAgent {
  async run({
    name,
    payload,
    delayMs,
  }: {
    name: string;
    payload?: any;
    delayMs?: number;
  }): Promise<{ ok: boolean; hitlRequired: boolean; aiitlCheck: string }> {
    await enqueue(name, payload ?? {}, { delay: delayMs ?? 0 });
    // Scheduling tasks does not typically require immediate human review, but
    // the AI notes the operation and indicates that no human intervention is
    // needed unless tasks are safety critical.
    return {
      ok: true,
      hitlRequired: false,
      aiitlCheck: 'AI scheduled the task successfully; no human oversight required.',
    };
  }
}

export default SchedulerAgent;