// src/agents/WatsonAgent.ts
// Deterministic formatter: keeps section headers (ending with ':') unnumbered,
// numbers only content lines, and indents bullets for readability.

export default class WatsonAgent {
  async run(input: { text: string }) {
    const raw = (input?.text ?? '').toString();

    // Split on newlines; tolerate mixed input (joined by sop.ts)
    const lines = raw
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);

    const out: string[] = [];
    let stepNo = 1;

    const isHeader = (s: string) => s.endsWith(':');
    const isBullet = (s: string) => /^- /.test(s);

    for (const line of lines) {
      if (isHeader(line)) {
        // keep headers as-is (not numbered)
        out.push(line);
        continue;
      }

      if (isBullet(line)) {
        // indent bullets; no numbering
        out.push(`  ${line}`);
        continue;
      }

      // normal content line -> numbered
      out.push(`${stepNo}. ${line}`);
      stepNo += 1;
    }

    return {
      steps: out,
      hitlRequired: false,
      aiitlCheck: 'Formatted with section-aware numbering.',
    };
  }
}
