import { fileURLToPath } from "node:url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import fs from 'node:fs';
import path from 'node:path';
import yaml from 'yaml';

/**
 * TrainerAgent generates a simple curriculum for a given trade and skill level.
 * It reads task definitions from the `src/isc/tasks/{trade}` directory.  Tasks
 * are YAML files whose filename (without extension) denotes the task name.  For
 * simplicity, levels are implemented by slicing the list of tasks: level 1
 * returns the first 20% of tasks, level 2 returns 40%, up to level 5 which
 * returns all tasks.  If no tasks are found for the requested trade an
 * empty array is returned.
 */
export default class TrainerAgent {
  async run(input: { trade: string; level?: number }): Promise<{
    trade: string;
    level: number;
    tasks: string[];
    hitlRequired: boolean;
    aiitlCheck: string;
  }> {
    const { trade } = input;
    const level = Math.max(1, Math.min(5, input.level ?? 1));
    // Determine the tasks directory relative to this file
    const tasksDir = path.join(__dirname, '../../isc/tasks', trade.toLowerCase());
    let taskNames: string[] = [];
    if (fs.existsSync(tasksDir) && fs.statSync(tasksDir).isDirectory()) {
      const files = fs
        .readdirSync(tasksDir)
        .filter((f) => f.endsWith('.yaml') || f.endsWith('.yml'));
      // Remove extensions to get task names
      taskNames = files.map((f) => f.replace(/\.ya?ml$/, ''));
      // Sort alphabetically to provide a deterministic order
      taskNames.sort((a, b) => a.localeCompare(b));
    }
    // Slice tasks based on level (20% increments)
    const sliceIndex = Math.ceil((taskNames.length * level) / 5);
    const selected = taskNames.slice(0, sliceIndex);
    return {
      trade,
      level,
      tasks: selected,
      hitlRequired: false,
      aiitlCheck: 'AI generated a curriculum outline; human can adjust as needed.',
    };
  }
}