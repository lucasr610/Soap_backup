import { safetyRules } from '../utils/rules.js';

export class MotherAgent {
  /**
   * Evaluate a SOP against safety and compliance rules.  Returns the list of
   * issues found as well as HITL/AIITL metadata.  Human review is required
   * whenever issues are present.  AI also provides a note summarizing its
   * findings.
   */
  async run({ sop }: { sop: string[] }): Promise<{
    issues: string[];
    hitlRequired: boolean;
    aiitlCheck: string;
  }> {
    const issues: string[] = [];
    const text = Array.isArray(sop) ? sop.join('\n') : String(sop);
    for (const rule of safetyRules) {
      if (rule.pattern.test(text)) {
        issues.push(rule.description);
      }
    }
    const hitlRequired = issues.length > 0;
    const aiitlCheck = hitlRequired
      ? 'AI flags potential safety or compliance issues; human review required.'
      : 'AI reviewed compliance and found no issues.';
    return { issues, hitlRequired, aiitlCheck };
  }
}

export default MotherAgent;