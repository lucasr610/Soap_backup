// src/server.ts
//
// The main Fastify server for the Nordri platform.  This implementation
// replaces the previous Express stub with a fully featured Fastify
// instance that registers all available API routes and exposes a
// configuration endpoint for health and version information.  The
// server loads any persisted secrets on startup and applies them to
// process.env so that downstream services (e.g. the vector store,
// embedding provider or database clients) can pick up keys and URLs
// dynamically.  Environment variables can also be updated at runtime
// via the /secrets API which writes to disk and mutates process.env.

import fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import ssePlugin from 'fastify-sse-v2';

import agentsRoutes from './routes/agents.js';
import ragRoutes from './routes/rag.js';
import sopRoutes from './routes/sop.js';
import sopExportRoutes from './routes/sopExport.js';
import troubleshootRoutes from './routes/troubleshoot.js';
import scheduleRoutes from './routes/schedule.js';
import secretsRoutes from './routes/secrets.js';
import telemetryRoutes from './routes/telemetry.js';
import regsRoutes from './routes/regs.js';
// Chat route for conversational UI
import chatRoutes from './routes/chat.js';

// Newly added dynamic task and job routes
import tasksRoutes from './routes/tasks.js';
import jobsRoutes from './routes/jobs.js';

import { loadVault } from './services/secretsStore.js';

// Create the Fastify instance with logging enabled.  Logging
// configuration can be customised via FASTIFY_LOG_LEVEL if desired.
const app = fastify({ logger: true });

// Apply CORS for all routes.  In a production environment you may
// restrict the allowed origins via environment variables.
app.register(cors, { origin: true });

// Register WebSocket and Server Sent Events plugins.  Telemetry and
// potential future features can leverage these for real‑time updates.
app.register(websocket);
app.register(ssePlugin);

// Load any persisted secrets from the vault.  Each key/value pair is
// applied to process.env if not already set.  This allows the server
// to start with previously configured API keys and connection strings.
try {
  const secrets = loadVault();
  for (const key of Object.keys(secrets)) {
    if (!process.env[key]) {
      process.env[key] = secrets[key];
      app.log.info({ key }, 'Loaded secret from vault');
    }
  }
} catch (err: any) {
  app.log.error({ err }, 'Failed to load secrets vault');
}

// Simple health and version endpoints outside of plugin scope.  These
// respond immediately and can be used for readiness and liveness checks.
app.get('/health', async () => ({ ok: true }));
app.get('/api/version', async () => ({ version: '1.0.0' }));

// Register all route plugins with appropriate prefixes.  The order of
// registration does not matter but grouping them here clarifies the
// available API surface.  Each plugin exposes subpaths relative to
// its prefix (e.g. /sop/generate, /sop/export).  Additional modules
// can be added here without modifying the core server logic.
app.register(agentsRoutes, { prefix: '/agents' });
app.register(ragRoutes, { prefix: '/rag' });
app.register(sopRoutes, { prefix: '/sop' });
app.register(sopExportRoutes, { prefix: '/sop' });
app.register(troubleshootRoutes, { prefix: '/troubleshoot' });
app.register(scheduleRoutes, { prefix: '/schedule' });
app.register(secretsRoutes, { prefix: '/secrets' });
app.register(telemetryRoutes, { prefix: '/telemetry' });

// Expose a proxy for regulatory validations to the Python sidecar
app.register(regsRoutes, { prefix: '/regs' });

// Register new endpoints for tasks and jobs.  These enable CRUD
// operations on training tasks and dynamic job assembly based on
// trade/equipment filters or explicit task IDs.
app.register(tasksRoutes, { prefix: '/tasks' });
app.register(jobsRoutes, { prefix: '/jobs' });

// Register chat endpoint.  It is mounted at /chat and accepts
// messages or file uploads from the front‑end chat UI.  The route
// returns formatted SOP responses.
app.register(chatRoutes, { prefix: '/chat' });

// Default 404 handler.  If no route matches, respond with a JSON
// object containing the path and a not found message.  This avoids
// leaking internal Fastify errors to clients.
app.setNotFoundHandler((req, reply) => {
  reply.code(404).send({ error: 'Not Found', path: req.raw.url });
});

// Centralised error handler.  Any uncaught exception within a route
// will be passed here.  The status code defaults to 500 and the
// error message is returned in the response body.  Fastify logs the
// details automatically based on the logger configuration.
app.setErrorHandler((err, _req, reply) => {
  const status = (err as any)?.statusCode ?? 500;
  reply.code(status).send({ error: (err as any)?.message ?? String(err) });
});

// Determine the port and listen.  Use 0.0.0.0 to accept connections
// from within Docker containers or across networks.  If the port is
// already in use Fastify will log an error.  The awaited promise
// ensures that startup errors are caught instead of silently ignored.
const port = Number(process.env.PORT) || 5000;
app.listen({ port, host: '0.0.0.0' }).catch((err) => {
  app.log.error({ err }, 'Failed to start server');
  process.exit(1);
});

export default app;