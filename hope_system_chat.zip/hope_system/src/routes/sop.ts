import { FastifyPluginCallback } from 'fastify';
import { generateSOP } from '../services/sop.js';

const sopRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Generate a SOP for a given task and job order
  app.post('/generate', async (req, res) => {
    const body = req.body as any;
    const task = body?.task;
    const jobOrder = body?.jobOrder;
    if (typeof task !== 'string' || typeof jobOrder !== 'string') {
      return res.code(400).send({ error: 'task and jobOrder strings required' });
    }
    const result = await generateSOP({ task, jobOrder });
    return result;
  });
  done();
};

export default sopRoutes;