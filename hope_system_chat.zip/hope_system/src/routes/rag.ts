import { FastifyPluginCallback } from 'fastify';
import { indexDocs, queryDocs } from '../services/rag.js';

const ragRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Index documents: expects an array of {id, text, metadata}
  app.post('/index', async (req, res) => {
    const body = req.body as any;
    const docs = Array.isArray(body) ? body : body?.documents;
    if (!Array.isArray(docs)) {
      return res.code(400).send({ error: 'Array of documents required' });
    }
    await indexDocs(docs);
    return { ok: true, count: docs.length };
  });

  // Query documents: expects { query: string, limit?: number }
  app.post('/query', async (req, res) => {
    const body = req.body as any;
    const query = body?.query;
    if (typeof query !== 'string') {
      return res.code(400).send({ error: 'query string required' });
    }
    const limit = body?.limit ?? 5;
    const results = await queryDocs(query, limit);
    return { results };
  });

  done();
};

export default ragRoutes;