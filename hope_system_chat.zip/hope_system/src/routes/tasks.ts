// src/routes/tasks.ts
//
// Fastify plugin providing CRUD endpoints for dynamic training tasks.
// Tasks are stored via the tasks service which loads YAML
// definitions on first use and persists updates to a JSON file.
//
import { FastifyPluginCallback } from 'fastify';
import {
  listTasks,
  getTask,
  createTask,
  updateTask,
  deleteTask,
  TaskEntry,
} from '../services/tasks.js';

const tasksRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // List all tasks
  app.get('/', async () => {
    const tasks = listTasks();
    return { tasks };
  });

  // Fetch a single task by ID
  app.get('/:id', async (req, res) => {
    const id = (req.params as any).id as string;
    const task = getTask(id);
    if (!task) {
      return res.code(404).send({ error: 'task not found' });
    }
    return { task };
  });

  // Create a new task.  The request body should conform to TaskEntry
  // minus id, version and timestamps.  Steps must be provided with
  // at least a description.
  app.post('/', async (req, res) => {
    const body = req.body as Partial<TaskEntry>;
    if (!body || typeof body.name !== 'string' || !Array.isArray(body.steps)) {
      return res.code(400).send({ error: 'name (string) and steps (array) are required' });
    }
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const entry = createTask({
        name: body.name,
        domain: body.domain,
        level: body.level,
        tags: body.tags || [],
        // Accept user-supplied steps verbatim; rely on service to assign IDs
        steps: body.steps as any,
      });
      return { task: entry };
    } catch (err: any) {
      return res.code(500).send({ error: err.message || String(err) });
    }
  });

  // Update an existing task by ID
  app.patch('/:id', async (req, res) => {
    const id = (req.params as any).id as string;
    const body = req.body as Partial<TaskEntry>;
    const existing = getTask(id);
    if (!existing) {
      return res.code(404).send({ error: 'task not found' });
    }
    try {
      const updated = updateTask(id, body);
      if (!updated) return res.code(500).send({ error: 'failed to update task' });
      return { task: updated };
    } catch (err: any) {
      return res.code(500).send({ error: err.message || String(err) });
    }
  });

  // Delete a task by ID
  app.delete('/:id', async (req, res) => {
    const id = (req.params as any).id as string;
    const ok = deleteTask(id);
    if (!ok) {
      return res.code(404).send({ error: 'task not found' });
    }
    return { ok: true };
  });

  done();
};

export default tasksRoutes;