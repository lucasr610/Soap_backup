// src/routes/telemetry.ts
//
// Fastify plugin providing basic health and system telemetry endpoints.
//
// The original implementation exported an Express router which could not be
// registered in the Fastify server.  This version adapts the handlers to
// Fastify's plugin API so that the `/telemetry/health` and `/telemetry/metrics`
// paths work as expected when registered with a prefix.  The endpoints
// return lightweight JSON objects suitable for real‑time monitoring in
// the frontend dashboard.

import { FastifyPluginCallback } from 'fastify';
import os from 'node:os';

const telemetryRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Simple health check returning service name and current timestamp.
  app.get('/health', async () => {
    return { ok: true, service: 'nordri-platform', ts: Date.now() };
  });

  // System metrics including load averages and memory utilisation.  The
  // response mirrors the shape of the previous Express implementation but
  // wrapped in an async function to satisfy Fastify.
  app.get('/metrics', async () => {
    const load = os.loadavg();
    const memFree = os.freemem();
    const memTotal = os.totalmem();
    return {
      load1: load[0],
      load5: load[1],
      load15: load[2],
      memFree,
      memTotal,
      memUsed: memTotal - memFree,
      uptime: os.uptime(),
    };
  });

  done();
};

export default telemetryRoutes;