/*
 * src/routes/chat.ts
 *
 * Fastify plugin that exposes a simple chat endpoint for the Nordri
 * platform.  Messages can be plain text or file uploads.  Text
 * messages are passed directly to the SOP generator as ad‑hoc manual
 * content.  Uploaded files are read into memory and treated as
 * manual text for the purposes of this demo.  The response
 * contains the formatted SOP steps that can be rendered in the chat
 * UI.  In a future iteration this route could fan out to
 * ingestion, RAG, troubleshooting or other agents based on
 * conversational context.
 */

import type { FastifyPluginCallback } from 'fastify';
import { generateSOP } from '../services/sop.js';

const chatRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Register the multipart plugin if not already registered.  Fastify
  // ignores duplicate registrations so it is safe to call here.
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const multipart = require('@fastify/multipart');
  app.register(multipart);

  // POST /chat
  // Accepts either a JSON body with a `message` field or a
  // multipart/form‑data request with a single file.  The handler
  // extracts the content and invokes the SOP generator.  The
  // response payload contains an array of numbered steps returned
  // from WatsonAgent or falls back to the unnumbered lines when
  // the formatter is not available.
  // Note: omit generic type parameters here because Fastify's post()
  // method signature does not support explicit type arguments under the
  // current compiler configuration.  Omitting the type allows TypeScript
  // to infer `req.body` as any.
  app.post('/', async (req, reply) => {
    // Detect multipart file uploads
    const contentType = req.headers['content-type'] || '';
    let manualText = '';

    if (contentType.includes('multipart/form-data')) {
      // Use the streams API provided by fastify-multipart to read the
      // first file.  We ignore additional files for now.
      const parts = req.parts();
      for await (const part of parts) {
        if (part.file) {
          const chunks: Buffer[] = [];
          for await (const chunk of part.file) {
            chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
          }
          manualText = Buffer.concat(chunks).toString('utf8');
          break;
        }
      }
      if (!manualText) {
        reply.code(400).send({ error: 'No file content provided' });
        return;
      }
    } else {
      // Assume JSON body with a `message` field
      const body = req.body ?? {};
      const message = (body.message ?? '').toString();
      if (!message.trim()) {
        reply.code(400).send({ error: 'Empty message' });
        return;
      }
      manualText = message;
    }

    // Generate an SOP using the manual text.  We treat the text as
    // a free‑form manual; the SOP generator will number the lines and
    // apply safety/logic agents as appropriate.  In the future the
    // message could be routed to other services based on intent.
    try {
      const result = await generateSOP({ manual: manualText });
      const steps: string[] = result?.sopFormatted || result?.sopStructured?.steps || [];
      reply.send({ response: steps });
    } catch (err: any) {
      req.log.error({ err }, 'Chat handler failed');
      reply.code(500).send({ error: 'Failed to generate response' });
    }
  });

  done();
};

export default chatRoutes;