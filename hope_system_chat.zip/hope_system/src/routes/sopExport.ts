// src/routes/sopExport.ts
//
// Fastify plugin for exporting generated SOPs in various formats.  The
// previous implementation relied on Express routers and mutating the
// response object directly.  This version adapts the logic for Fastify
// by writing headers on the raw response and using reply.send() only
// when appropriate.  It supports PDF, CSV and DOCX exports and falls
// back to a 400 error for unsupported formats.

import { FastifyPluginCallback } from 'fastify';
import { generateSOP } from '../services/sop.js';
import PDFDocument from 'pdfkit';
import { stringify as csvStringify } from 'csv-stringify/sync';

const sopExportRoutes: FastifyPluginCallback = (app, _opts, done) => {
  app.post('/export', async (req, reply) => {
    try {
      const body = (req.body ?? {}) as any;
      const { format = 'pdf', ...sopInput } = body;

      // Generate the SOP using the same service as the /generate endpoint.
      const result = await generateSOP(sopInput);
      const { sopFormatted, sopStructured } = result;

      if (format === 'pdf') {
        // Set response headers on the raw response.  We use reply.raw
        // because pdfkit expects a writable stream.  Once piped, we return
        // without calling reply.send() so Fastify does not attempt to
        // serialise the stream automatically.
        reply.raw.setHeader('Content-Type', 'application/pdf');
        reply.raw.setHeader('Content-Disposition', 'attachment; filename="sop.pdf"');
        const doc = new PDFDocument();
        doc.pipe(reply.raw);

        doc.fontSize(20).text('Standard Operating Procedure', { underline: true });
        doc.moveDown();

        doc.fontSize(14).text(`Job Order: ${sopStructured.jobOrder ?? ''}`);
        doc.text(`Task: ${sopStructured.task ?? ''}`);
        doc.moveDown();

        const addSection = (title: string, items: string[] = []) => {
          if (!items?.length) return;
          doc.fontSize(14).text(title, { underline: true });
          doc.moveDown(0.2);
          items.forEach((it) => doc.fontSize(12).text(`- ${it}`));
          doc.moveDown();
        };

        addSection('PPE', sopStructured.ppe);
        addSection('JSA', sopStructured.jsa);
        addSection('Tools', sopStructured.tools);
        addSection('Steps', sopStructured.steps);
        addSection('QA', sopStructured.qa);
        addSection('Closeout', sopStructured.closeout);

        doc.end();
        return;
      }

      if (format === 'csv') {
        reply.raw.setHeader('Content-Type', 'text/csv');
        reply.raw.setHeader('Content-Disposition', 'attachment; filename="sop.csv"');
        const csv = csvStringify((sopFormatted ?? []).map((line: string) => [line]), { header: false });
        reply.send(csv);
        return;
      }

      if (format === 'docx') {
        reply.raw.setHeader(
          'Content-Type',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        );
        reply.raw.setHeader('Content-Disposition', 'attachment; filename="sop.docx"');
        const content = (sopFormatted ?? []).join('\n');
        reply.send(Buffer.from(content, 'utf8'));
        return;
      }

      reply.code(400).send({ error: 'Unsupported format. Use pdf, csv, or docx.' });
    } catch (err: any) {
      app.log.error({ err }, 'Export error');
      const status = (err as any)?.statusCode ?? 500;
      reply.code(status).send({ error: (err as any)?.message ?? String(err) });
    }
  });
  done();
};

export default sopExportRoutes;