import { FastifyPluginCallback } from 'fastify';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';
import path from 'node:path';

// Store the secrets vault under ~/.nordri instead of ~/.oracle.  This avoids
// clashing with the old Oracle engine and clearly names the product.
const vaultDir = path.join(process.env.HOME ?? '.', '.nordri');
const vaultFile = path.join(vaultDir, 'secrets.json.enc');

// The encryption key is provided via NORDRI_KMS_KEY (base64).  Use this to
// rotate keys when migrating from the previous Oracle implementation.  Older
// ORACLE_KMS_KEY variables are no longer used.
const keyB64 = process.env.NORDRI_KMS_KEY;

type Secrets = Record<string, string>;

function encrypt(obj: Secrets, key: Buffer): Buffer {
  // AES‑256‑GCM with a 12‑byte IV and 16‑byte tag
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const plaintext = Buffer.from(JSON.stringify(obj), 'utf8');
  const enc = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]);
}

function decrypt(buf: Buffer, key: Buffer): Secrets {
  const iv = buf.subarray(0, 12);
  const tag = buf.subarray(12, 28);
  const data = buf.subarray(28);
  const decipher = createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const dec = Buffer.concat([decipher.update(data), decipher.final()]);
  return JSON.parse(dec.toString('utf8'));
}

function loadVault(key: Buffer): Secrets {
  if (!existsSync(vaultFile)) return {};
  const blob = readFileSync(vaultFile);
  return decrypt(blob, key);
}

function saveVault(obj: Secrets, key: Buffer) {
  mkdirSync(vaultDir, { recursive: true });
  writeFileSync(vaultFile, encrypt(obj, key));
}

const secretsRoutes: FastifyPluginCallback = (app, _opts, done) => {
  const key = keyB64 ? Buffer.from(keyB64, 'base64') : Buffer.alloc(32, 0);

  // List keys without revealing values
  app.get('/', async () => {
    const secrets = loadVault(key);
    return { keys: Object.keys(secrets).sort() };
  });

  // Store or update a secret value
  app.post('/', async (req, res) => {
    const body = (req.body ?? {}) as { key?: string; value?: string };
    if (!body.key || typeof body.value !== 'string') {
      return res.code(400).send({ error: 'key and value required' });
    }
    const secrets = loadVault(key);
    secrets[body.key] = body.value;
    saveVault(secrets, key);

    // Apply the secret immediately to process.env so that downstream
    // services pick up the change without requiring a restart.  In
    // production deployments you may prefer to reload specific
    // components instead of globally mutating process.env.
    process.env[body.key] = body.value;
    return { ok: true };
  });

  // Delete a secret
  app.delete('/:key', async (req, res) => {
    const keyName = (req.params as any).key as string;
    const secrets = loadVault(key);
    if (!(keyName in secrets)) {
      return res.code(404).send({ error: 'not found' });
    }
    delete secrets[keyName];
    saveVault(secrets, key);

    // Remove the key from the current environment.  This does not
    // retroactively clear values already loaded by clients but will
    // prevent new operations from using the deleted secret.
    delete (process.env as any)[keyName];
    return { ok: true };
  });

  done();
};

export default secretsRoutes;