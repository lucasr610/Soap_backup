import { FastifyPluginCallback } from 'fastify';
import { enqueue } from '../services/queue.js';

const scheduleRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // List jobs is not implemented; returns stub
  app.get('/', async () => {
    return { ok: true, note: 'Listing scheduled jobs is not implemented in this demo.' };
  });

  // Create a scheduled job
  app.post('/', async (req, res) => {
    const body = req.body as any;
    const name = body?.name;
    const data = body?.data ?? {};
    const delayMs = body?.delayMs ?? 0;
    if (typeof name !== 'string') {
      return res.code(400).send({ error: 'name required' });
    }
    await enqueue(name, data, { delay: delayMs });
    return { ok: true };
  });

  done();
};

export default scheduleRoutes;