import { FastifyPluginCallback } from 'fastify';
import { loadProcedure, runProcedure, suggestProcedure } from '../services/troubleshoot.js';

const troubleshootRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Run a troubleshooting procedure
  app.post('/run', async (req, res) => {
    const body = req.body as any;
    const fileName = body?.procedure;
    const answers = body?.answers ?? {};
    if (typeof fileName !== 'string') {
      return res.code(400).send({ error: 'procedure file name required' });
    }
    try {
      const proc = loadProcedure(fileName);
      const result = runProcedure(proc, answers);
      return result;
    } catch (err: any) {
      return res.code(500).send({ error: err.message });
    }
  });

  // Suggest a baseline procedure for a given system
  app.post('/suggest', async (req, res) => {
    const body = req.body as any;
    const system = body?.system;
    if (typeof system !== 'string') {
      return res.code(400).send({ error: 'system string required' });
    }
    const proc = suggestProcedure(system);
    return proc;
  });

  done();
};

export default troubleshootRoutes;