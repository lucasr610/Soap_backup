import { FastifyPluginCallback } from 'fastify';
import { getAgents, runAgent, loadAgents } from '../agents/index.js';

const agentsRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Ensure agents are loaded before any requests are handled.  loadAgents()
  // returns a promise; we trigger it here but do not await because Fastify
  // plugins cannot be async.  The agents list will populate in the
  // background and subsequent requests will see the loaded agents.
  // Any errors during loading will be logged via loadAgents() itself.
  loadAgents().catch((err) => {
    app.log.error({ err }, 'Failed to load agents');
  });

  // List all loaded agents with their metadata
  app.get('/', async () => {
    return { agents: getAgents().map((a) => a.meta) };
  });

  // Run a specific agent by id
  app.post('/:id/run', async (req, res) => {
    const id = (req.params as any).id as string;
    const body = req.body as any;
    try {
      const output = await runAgent(id, body ?? {});
      return { output };
    } catch (err: any) {
      return res.code(404).send({ error: err.message });
    }
  });
  done();
};

export default agentsRoutes;