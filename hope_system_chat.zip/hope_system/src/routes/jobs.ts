// src/routes/jobs.ts
//
// Fastify plugin for assembling dynamic job flows from stored tasks.
// Clients can specify a trade/domain, equipment or symptom filter or
// explicitly provide a list of task IDs.  The assembled job is a
// concatenated list of steps from the matched tasks.  Additional
// metadata about the tasks is included for UI rendering.

import { FastifyPluginCallback } from 'fastify';
import { buildJob } from '../services/tasks.js';

const jobsRoutes: FastifyPluginCallback = (app, _opts, done) => {
  // Build a job on demand.  Accepts a JSON body with either
  // { trade: string, equipment?: string, symptom?: string } or
  // { taskIds: string[] }.  The response returns the ordered
  // steps and the underlying tasks.
  app.post('/build', async (req, res) => {
    const body = (req.body ?? {}) as any;
    const { trade, equipment, symptom, taskIds } = body;
    if (!trade && (!Array.isArray(taskIds) || taskIds.length === 0)) {
      return res.code(400).send({ error: 'trade or taskIds must be provided' });
    }
    try {
      const job = buildJob({ trade, equipment, symptom, taskIds });
      return { job };
    } catch (err: any) {
      return res.code(500).send({ error: err.message || String(err) });
    }
  });
  done();
};

export default jobsRoutes;