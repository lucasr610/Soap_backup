// src/routes/regs.ts
//
// Fastify plugin to proxy regulatory validation requests to the
// Python sidecar service.  The Node platform constructs an
// aggregated_data object from prior department outputs and forwards
// it along with the project identifier and username.  The sidecar
// returns the compliance report which is relayed verbatim back to
// the client.  In case of network or protocol errors a 500
// response is returned.

import { FastifyPluginCallback } from 'fastify';

const PYTHON_BASE_URL = process.env.PYTHON_SERVICE_URL || 'http://localhost:7001';

const regsRoutes: FastifyPluginCallback = (app, _opts, done) => {
  app.post('/validate', async (req, res) => {
    const body = req.body as any;
    try {
      const url = `${PYTHON_BASE_URL}/regulatory/validate`;
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body ?? {}),
      });
      if (!resp.ok) {
        const text = await resp.text();
        return res.code(resp.status).send({ error: `Python service responded with ${resp.status}: ${text}` });
      }
      const data = await resp.json();
      return data;
    } catch (err: any) {
      return res.code(500).send({ error: err.message || String(err) });
    }
  });
  done();
};

export default regsRoutes;