/**
 * A set of sample safety and compliance rules.  Each rule has a pattern and a
 * description.  The MotherAgent scans the SOP text for these patterns and
 * reports any matches as potential safety issues.
 *
 * NOTE: These are illustrative examples and not definitive.  Real rules should
 * reference authoritative OSHA/EPA/DOT regulations.
 */
export interface SafetyRule {
  pattern: RegExp;
  description: string;
}

export const safetyRules: SafetyRule[] = [
  {
    pattern: /bypass/i,
    description: 'Bypassing safety interlocks is prohibited.',
  },
  {
    pattern: /disable.*alarm/i,
    description: 'Disabling safety alarms may violate OSHA requirements.',
  },
  {
    pattern: /remove.*guard/i,
    description: 'Removing machine guards can be unsafe.',
  },
  // Additional safety rules covering hazardous materials and spill response
  {
    pattern: /hazardous|biohazard|toxic/i,
    description: 'Ensure proper handling and disposal of hazardous or biohazard materials.',
  },
  {
    pattern: /spill|leak/i,
    description: 'Spills or leaks should be contained and cleaned using approved procedures.',
  },
  {
    pattern: /mop gear/i,
    description: 'Full MOP gear is required when dealing with biological hazards.',
  },
];

/**
 * A set of logical rules for dependency checking.  These are used by the
 * FatherAgent to ensure steps are ordered correctly.
 */
export interface LogicRule {
  prerequisite: RegExp;
  dependent: RegExp;
  message: string;
}

export const logicRules: LogicRule[] = [
  {
    prerequisite: /lockout/i,
    dependent: /perform maintenance/i,
    message: 'Lockout/tagout should occur before performing maintenance.',
  },
  {
    prerequisite: /turn off/i,
    dependent: /inspect/i,
    message: 'Equipment should be turned off before inspection.',
  },
];