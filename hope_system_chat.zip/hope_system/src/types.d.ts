// src/types.d.ts
// Stub type declarations for modules that lack TypeScript definitions.  These
// declarations allow the project to compile without strict type checking.

declare module 'fastify' {
  const fastify: any;
  export default fastify;
  export type FastifyPluginCallback = any;
}

declare module '@fastify/websocket' {
  const any: any;
  export default any;
}

declare module 'fastify-sse-v2' {
  const any: any;
  export default any;
}

declare module 'yaml' {
  const YAML: any;
  export default YAML;
}

declare module '@qdrant/js-client-rest' {
  export class QdrantClient {
    constructor(opts: any);
    getCollections(...args: any[]): any;
    createCollection(...args: any[]): any;
    upsert(...args: any[]): any;
    search(...args: any[]): any;
    delete(...args: any[]): any;
  }
}

// Stub declarations for optional dependencies that may not ship with
// TypeScript definitions in this environment.  Declaring them as
// `any` allows the project to compile without additional @types
// packages.  These modules are used at runtime via CommonJS or ESM
// imports and their actual typings are not critical for the build.

declare module '@fastify/cors' {
  const any: any;
  export default any;
}

declare module 'pdfkit' {
  const any: any;
  export default any;
}

declare module 'csv-stringify/sync' {
  export function stringify(data: any, opts?: any): string;
}

declare module 'dotenv' {
  const any: any;
  export default any;
}

declare module 'openai' {
  const any: any;
  export default any;
}

// Stub for optional dotenv config import.  Some environments may lack
// type definitions for this module; declare it as any to avoid compile
// errors when using dynamic import('dotenv/config').
declare module 'dotenv/config' {
  const any: any;
  export default any;
}

declare module 'mongodb' {
  export const MongoClient: any;
  export type MongoClient = any;
  export const ObjectId: any;
}

// Express and cors are used as CommonJS modules but may lack type
// declarations in our environment.  Provide loose types to satisfy the
// compiler without pulling in @types/express or @types/cors.
declare module 'express' {
  const any: any;
  export default any;
  export const Router: any;
}

declare module 'cors' {
  const any: any;
  export default any;
}